﻿using DbAccount.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DbAccount.Services.Repository
{
    public class UserRepository : IAccount
    {

        private AccountDataEntities db;

        public LUserARM_Result Authorization(string login, string password)
        {
            using (db = new AccountDataEntities())
            {
                return db.LUserARM(login, password, "0000", 3, new ObjectParameter("ErrorCode", typeof(int))).ToList().FirstOrDefault();
            }
        }
    }
}
