﻿using AdminWebCore.Services.Models.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Components
{
    public class PaginatorViewComponent : ViewComponent
    {
        public PaginatorViewComponent()
        {

        }
        public IViewComponentResult Invoke()
        {
            string PageNumber = "1";
            string PageSize = "10";
            string TotalItems = "0";
            string TotalPages = "0";
            var pageinfo = new PageInfo();

            try
            {
                PageNumber = HttpContext.Session.GetString("PageNumber") ?? "1";
                PageSize = HttpContext.Session.GetString("PageSize") ?? "10";
                TotalItems = HttpContext.Session.GetString("TotalItems") ?? "0";
                TotalPages = HttpContext.Session.GetString("TotalPages") ?? "0";
            }
            catch (Exception ex)
            {


            }
            finally
            {
                pageinfo = new PageInfo() { PageNumber = int.Parse(PageNumber), PageSize = int.Parse(PageSize), TotalItems = int.Parse(TotalItems) };
            }
            return View(pageinfo);

        }
    }
}
