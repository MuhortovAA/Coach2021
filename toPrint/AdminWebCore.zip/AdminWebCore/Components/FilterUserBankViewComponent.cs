﻿using AdminWebCore.Services.Models.UserBank;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Components
{
    public class FilterUserBankViewComponent:ViewComponent
    {
        public FilterUserBankViewComponent()
        {

        }
        public IViewComponentResult Invoke()
        {
            var result = new FilterUserBankViewModel();


            return View(result);
        }
    }
}
