﻿using AdminWebCore.Services.Models.Customer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Components
{
    public class FilterCustomersViewComponent : ViewComponent
    {
        public FilterCustomersViewComponent()
        {

        }
        public IViewComponentResult Invoke()
        {
            var result = new FilterCustomerViewModel();
            string UNP = "";
            string NameCustomer = "";
            string idcl = "";

            try
            {
                UNP = HttpContext.Session.GetString("UNP") ?? "";
                NameCustomer = HttpContext.Session.GetString("NameCustomer") ?? "";
                idcl = HttpContext.Session.GetString("idcl") ?? "";
            }
            catch (Exception ex)
            {


            }
            finally
            {
                result = new FilterCustomerViewModel() { idcl = idcl, NameCustomer = NameCustomer, UNP = UNP };
            }

            return View(result);
        }
    }
}
