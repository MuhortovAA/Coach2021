﻿$("#btnFilter").click((e) => {
    //alert('FilterOn');
    let customer = $("#iCustomer").val();
    let unp = $("#iUNP").val();
    let idcl = $("#iIDCL").val();
    let result = "";
    if (customer.length > 0) {
        result = `<span class="badge badge-info">Название: ${customer} </span>`;
    }
    if (unp.length > 0) {
        result = `${result}<span class="badge badge-info">УНП: ${unp} </span>`;
    }
    if (idcl.length > 0) {
        result = `${result}<span class="badge badge-info">Код клиента: ${idcl} </span>`;
    }
    $("#filterOn").html(result);

    var filterdata = { UNP: unp, NameCustomer: customer, idcl: idcl };
    s_url = `/Customer/FilterOn/`;
    GetFilteredCustomers(s_url, filterdata);
});

function GetFilteredCustomers(url, filterdata) {
    $.ajax({
        url: url,
        type: 'POST',
        data: filterdata,
        dataType: "json",
        success: (data) => {
            readJson2(data);
        }
    });
};
function readJson2(json) {
    let inner = `<table class="table table-striped table-hover table-sm table-bordered m-0"><thead><tr><th class="text-center">№</th><th class="text-center">Код клиента</th><th class="text-center">Название</th><th class="text-center">УНП</th></tr></thead>`;
    json.forEach(element => {
        inner += `<tr><td class="text-center">${element.myNumber}</td>
                          <td class="text-center">${element.idcl}</td>
                          <td style="width:100em;">${element.name}</td>
                          <td class="text-center">${element.UNP}</td>
                          <td class="text-center">
                                <div class="btn-group">
                                    <a class="btn btn-light" data-toggle="tooltip" data-placement="top" title="Edit" href="/Customer/Edit/${element.id}"><i class="fa fa-edit"></i></a>
                                    <a class="btn btn-light" data-toggle="tooltip" data-placement="top" title="Details" href="/Customer/Edit/${element.id}"><i class="fa fa-info"></i></a>
                                    <a class="btn btn-light" data-toggle="tooltip" data-placement="top" title="Delete" href="/Customer/Edit/${element.id}"><i class="fa fa-trash"></i></a>
                                </div>
                          </td></tr>`;
    });
    $('#dataitems').html(inner + "</table>");
};