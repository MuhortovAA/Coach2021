﻿

$("#btnStart").click(() => {
    NavigationOn(1);
});
$("#btnEnd").click(() => {
    var result = $("#btnSelect").html().replace("из ", "");
    NavigationOn(result);
});
$("#btnForward").click(() => {
    var result = parseInt($("#pageNumber").val()) + 1;
    var max_result = $("#btnSelect").html().replace("из ", "");
    result = result > max_result ? max_result : result;
    NavigationOn(result);
});
$("#btnBackword").click(() => {
    var result = parseInt($("#pageNumber").val()) - 1;
    result = result < 1 ? 1 : result;
    NavigationOn(result);
});

$("#pageNumber").on("keyup", (event) => {
    if (event.keyCode === 13) {
        event.preventDefault();
        var result = $("#pageNumber").val();
        GetCustomers(`/Customer/Select/${result}`);
    };
});

function NavigationOn(data) {
    GetCustomers(`/Customer/Select/${data}`);
    $("#pageNumber").val(data);
};

function GetCustomers(url) {
    $.ajax({
        url: url,
        dataType: "json",
        success: (data) => {
            readJson(data);
        }
    });
};

function readJson(json) {
    let inner = `<table class="table table-striped table-hover table-sm table-bordered m-0"><thead><tr><th class="text-center">№</th><th class="text-center">Код клиента</th><th class="text-center">Название</th><th class="text-center">УНП</th></tr></thead>`;
    json.forEach(element => {
        inner += `<tr><td class="text-center">${element.myNumber}</td>
                          <td class="text-center">${element.idcl}</td>
                          <td style="width:100em;">${element.name}</td>
                          <td class="text-center">${element.UNP}</td>
                          <td class="text-center">
                                <div class="btn-group">
                                    <a class="btn btn-light" data-toggle="tooltip" data-placement="top" title="Edit" href="/Customer/Edit/${element.id}"><i class="fa fa-edit"></i></a>
                                    <a class="btn btn-light" data-toggle="tooltip" data-placement="top" title="Details" href="/Customer/Edit/${element.id}"><i class="fa fa-info"></i></a>
                                    <a class="btn btn-light" data-toggle="tooltip" data-placement="top" title="Users" onclick="reply_click(${element.id})"><div class="row"><i class="fa fa-user-circle col-2"></i><span class="badge badge-pill col-3">${element.CountUsers}</span></div></a>
                                </div>
                          </td></tr>`;
    });
    $('#dataitems').html(inner + "</table>");
};
