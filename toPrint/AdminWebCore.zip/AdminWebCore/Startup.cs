using Asb.Bank.Administration.DataBase.Interfaces;
using Asb.Bank.Administration.DataBase.Repository;
using Asb.Bank.Authorization.DataBase.Repository;
using Asb.Bank.Authorization.Entity;
using Asb.Bank.Authorization.Interfaces;
using Asb.Bank.DataBase.Abstraction;
using Asb.Bank.DataBase.Interfaces;
using Asb.Bank.Directories.DataBase.Repository;
using Asb.Bank.Directories.Interfaces;
using Asb.Bank.Protocol.Entity;
using Asb.Bank.Protocol.Repository;
using Asb.Bank.Utilite.Abstraction;
using DBAccountCore.Services.Models;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using System;

namespace AdminWebCore
{
    public class Startup
    {
        public IConfiguration Configuration { get; }
        public Startup(IConfiguration configuration) => Configuration = configuration;
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDistributedMemoryCache();
            services.AddSession(options =>
            {
                options.IdleTimeout = TimeSpan.FromMinutes(1);//You can set Time   
            });

            services.AddDbContext<AccountDbContext>(options => { options.UseSqlServer(Configuration["Data:CustomerDataEntities:ConnectionString"]); });

            services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(options =>
            {
                options.LoginPath = new Microsoft.AspNetCore.Http.PathString("/Account/Login");
            });

            var settingConnection = Configuration.GetSection("ConnectionStrings").Get<SettingConnectionString>();
            var settingApplication = Configuration.GetSection("SettingApplication").Get<SettingApplication>();

            services.AddSingleton(settingConnection);
            services.AddSingleton(settingApplication);
            services.AddSingleton<IActionContextAccessor, ActionContextAccessor>();
            services.AddTransient<IAuthorizationRepository<UserBank>, BankModuleAuthorizationRepository>();
            services.AddTransient<IAdminRepository, AdminRepository>();
            services.AddTransient<IAdministrationRepository, AdministrationRepository>();
            services.AddTransient<IStoreProcedureRepository<LoginUserBank>, StoreProcedureRepositoryBank>();
            services.AddTransient<IProtocolRepository, ProtocolRepository>();
            services.AddTransient<IStoreProcedureRepository<EtalonProtocol>, Asb.Bank.Protocol.Repository.StoreProcedureRepository>();
            services.AddTransient<IDirectoryRepository, DirectoryRepository>();
            services.AddTransient<IDirectoriesDataBase, DirectoriesDataBase>();
            //services.AddTransient<IAccount, UserRepository>();
            //services.AddTransient<ITypeDocument, TypeDocumentRepository>();

            services.AddMvc();
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env, ILoggerFactory loggerFactory)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }

            app.UseStatusCodePages();
            app.UseDefaultFiles();
            app.UseStaticFiles();
            app.UseSession();
            app.UseRouting();
            app.UseAuthentication();
            app.UseAuthorization();
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");
            });
            loggerFactory.AddFile("Logs/{Date}.log");

        }
    }
}
