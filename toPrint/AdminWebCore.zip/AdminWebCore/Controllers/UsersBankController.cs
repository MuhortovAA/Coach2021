﻿using AdminWebCore.Services.Models.UserBank;
using AdminWebCore.Services.Models.ViewModels;
using Asb.Bank.Administration.DataBase.Interfaces;
using Asb.Bank.Administration.Entity;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Controllers
{
    public class UsersBankController : Controller
    {
        private readonly IAdminRepository _repo;
        private myUserBankRepository myrepo;
        public UsersBankController(IAdminRepository repo, IAdministrationRepository repository)
        {
            _repo = repo;
            myrepo = new myUserBankRepository(repo, repository);
        }
        public IActionResult Index()
        {
            ViewBag.SelectedMenu = "userbank";
            var result = myrepo.GetAll();
            SetPager(result.PageInfo);
            //var result = myrepo.GetTenItems();
            //var result = new UserBankViewModel()
            //{
            //    //PagingInfo = new PageInfo { CurrentPage = 2, ItemPerPage = 5, TotalItems = 10 },
            //    usersbank = myrepo.GetTenItems()
            //};

            //var users = new List<UsersBank>();
            //for (int i = 0; i < 10; i++)
            //{
            //    users.Add(_repo.UserBank.FindLogin("admin"));
            //}
            return View(result);
        }
        [HttpPost]
        public IActionResult Filter(FilterUserBankViewModel filter) => View("Index", myrepo.GetFiltered(filter));

        public IActionResult Start() => View();
        private void SetPager(PageInfo pageinfo)
        {
            HttpContext.Session.SetString("PageNumber", pageinfo.PageNumber.ToString());
            HttpContext.Session.SetString("PageSize", pageinfo.PageSize.ToString());
            HttpContext.Session.SetString("TotalItems", pageinfo.TotalItems.ToString());
            HttpContext.Session.SetString("TotalPages", pageinfo.TotalPages.ToString());
        }
    }
}
