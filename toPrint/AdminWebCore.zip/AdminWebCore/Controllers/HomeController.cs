﻿using AdminWebCore.Services.Models.Implemented;
using Asb.Bank.Administration.DataBase.Interfaces;
using DBAccountCore.Services.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace AdminWebCore.Controllers
{
    public class HomeController : Controller
    {
        private readonly IAdminRepository _repo;
        private myImplementedRepository myrepo;
        private readonly ILogger logger;


        public HomeController(IAdminRepository repo, IAdministrationRepository repository, ILogger<HomeController> _logger)
        {
            _repo = repo;
            myrepo = new myImplementedRepository(repository);
            logger = _logger;
            logger.LogInformation($"Старт HomeController");


        }
        public IActionResult Index() => View(myrepo.GetItems());

        public string GetItem(string id)
        {
            return myrepo.GetImplemented(int.Parse(id ?? "0")).ToString();
            //return "Success";
        }


    }
}
