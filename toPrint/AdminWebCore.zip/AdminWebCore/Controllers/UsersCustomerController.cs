﻿using AdminWebCore.Services.Models.UsersCustomer;
using Asb.Bank.Administration.DataBase.Interfaces;
using Asb.Bank.Administration.Entity;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace AdminWebCore.Controllers
{
    [Authorize]
    public class UsersCustomerController : Controller
    {
        private myUsersCustomerRepository myrepo;
        public UsersCustomerController(IAdminRepository repo, IAdministrationRepository repository)
        {
            myrepo = new myUsersCustomerRepository(repo, repository);
        }
        public IActionResult Index()
        {
            return View();
        }
        public string GetUsers(string id) => JsonSerializer.Serialize(myrepo.GetAll(id));
    }
}
