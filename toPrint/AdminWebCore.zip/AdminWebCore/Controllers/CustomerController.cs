﻿using AdminWebCore.Filters;
using AdminWebCore.Services.Models.Customer;
using AdminWebCore.Services.Models.Customer.TypeDocument;
using AdminWebCore.Services.Models.ViewModels;
using Asb.Bank.Administration.DataBase.Interfaces;
using Asb.Bank.Administration.Entity;
using Asb.Bank.Directories.Interfaces;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Text.Json;

namespace AdminWebCore.Controllers
{
    [Authorize]
    [LastVisitResourceFilter]

    public class CustomerController : Controller
    {
        private readonly IAdminRepository _repo;
        private myCustomerRepository myrepo;
        private myTypeDocumentsRepository reptd;
        private readonly ILogger logger;

        //private myTypeDocumentsRepository myrepoTypeDocument;
        //private ITypeDocument _repoTypeDoc;

        public CustomerController(IAdminRepository repo, IAdministrationRepository repository, IDirectoryRepository repodir, ILogger<HomeController> _logger)
        {
            _repo = repo;
            myrepo = new myCustomerRepository(repo, repository, repodir);
            reptd = new myTypeDocumentsRepository();
            logger = _logger;

            logger.LogInformation($"Старт CustomerController");



            //myrepoTypeDocument = new myTypeDocumentsRepository(repod);
            //_repoTypeDoc = repoTypeDoc;

        }
        public IActionResult Index()
        {
            logger.LogInformation($"{HttpContext.Session.GetString("user") ?? "нет данных"} Старт Index");

            ViewBag.SelectedMenu = "customer";
            var result = myrepo.GetAll();

            SetPager(result.PageInfo);


            return View(result);
        }
        [HttpPost]
        public IActionResult Filter(FilterCustomerViewModel filter)
        {
            HttpContext.Session.SetString("UNP", filter.UNP?.ToString() ?? "");
            HttpContext.Session.SetString("NameCustomer", filter.NameCustomer?.ToString() ?? "");
            HttpContext.Session.SetString("idcl", filter.idcl?.ToString() ?? "");


            var result = myrepo.GetFiltered(filter);

            SetPager(result.PageInfo);

            return View("Index", result);
        }

        public IActionResult Navigation()
        {
            var result = myrepo.GetAll();
            return View("Index", result);
        }

        public IActionResult Edit(string id)
        {

            return View(new ViewCustomer());
        }

        public IActionResult Create(string id)
        {

            switch (id)
            {
                case "0":
                    return View("CreateUr", new CreateModelUr() { prUrPI = byte.Parse(id) });
                case "1":
                    return View("CreateFiz", new CreateModelFiz() { prUrPI = byte.Parse(id), typedocs = new TypeDocumnetListViewModel() { Current = "1", List = reptd.GetAll() } });

            }
            return Redirect("Index");
        }

        public IActionResult CreateFiz(string id) => View(new CreateModelFiz() { prUrPI = byte.Parse(id), typedocs = new TypeDocumnetListViewModel() { Current = "1" } });


        public IActionResult ViewNewCustomer(string id) => View(myrepo.GetByID(id));

        [HttpPost]
        public IActionResult CreateFiz(CreateModelFiz customer)
        {

            if (ModelState.IsValid)
            {
                var result = myrepo.Save((ViewCustomer)customer, customer.UsersList);
                TempData["message"] = $"Клиент сохранен успешно.";
                logger.LogInformation($"Клиент сохранен успешно. Данные:{customer.UsersList}");


                return RedirectToAction("ViewNewCustomer", "Customer", new { id = result.id });
            }
            else
            {
                var createcustomer = customer;
                createcustomer.typedocs = new TypeDocumnetListViewModel() { Current = customer.typedocs.Current, List = reptd.GetAll() };
                return View(createcustomer);
            }
        }
        public IActionResult CreateUr(string id) => View(new CreateModelUr() { prUrPI = byte.Parse(id) });


        [HttpPost]
        public IActionResult Create2(string id)
        {
            var result = new CustomerCreateModel();
            return Redirect("Create");
        }
        [HttpPost]
        public IActionResult Create(CustomerCreateModel customer)
        {
            if (ModelState.IsValid)
            {
                return RedirectToAction("Index", "Customer");
            }
            else
            {

                return View();
            }
        }
        public string Select(string id)
        {

            var PageNumber = id;
            var PageSize = HttpContext.Session.GetString("PageSize");

            var customers = myrepo.GetPageNumber(PageNumber, PageSize, GetPager());
            var result = JsonSerializer.Serialize<List<myViewCustomer>>(customers);

            return result;
        }
        public string GetIDCL()
        {
            return "W005";
        }
        private FilterCustomerViewModel GetPager()
        {
            return new FilterCustomerViewModel()
            {

                UNP = HttpContext.Session.GetString("UNP") ?? "",
                NameCustomer = HttpContext.Session.GetString("NameCustomer") ?? "",
                idcl = HttpContext.Session.GetString("idcl") ?? ""
            };

        }
        private void SetPager(PageInfo pageinfo)
        {
            HttpContext.Session.SetString("PageNumber", pageinfo.PageNumber.ToString());
            HttpContext.Session.SetString("PageSize", pageinfo.PageSize.ToString());
            HttpContext.Session.SetString("TotalItems", pageinfo.TotalItems.ToString());
            HttpContext.Session.SetString("TotalPages", pageinfo.TotalPages.ToString());
        }
    }
}
