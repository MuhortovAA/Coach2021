﻿using AdminWebCore.Filters;
using Asb.Bank.Authorization.Entity;
using Asb.Bank.Authorization.Interfaces;
using DBAccountCore.Services.Interfaces;
using DBAccountCore.Services.Models.ViewModel.Account;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace AdminWebCore.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        private readonly IAuthorizationRepository<UserBank> _authorizationRepository;
        private readonly ILogger logger;

        //private IAccount repo;

        public AccountController(IAuthorizationRepository<UserBank> authorizationRepository, ILogger<AccountController> _logger)
        {
            //repo = _repo;
            _authorizationRepository = authorizationRepository;
            logger = _logger;

            logger.LogInformation($"Старт AccountController");

        }

        [AllowAnonymous]
        public IActionResult Login(string returnUrl) => View(new LoginModel());

        //[HttpPost]
        //[AllowAnonymous]
        //[ValidateAntiForgeryToken]
        //public async Task<IActionResult> Login(LoginModel dataUser)
        //{
        //    if (ModelState.IsValid)
        //    {
        //        var user = repo.Authorization(dataUser);
        //        if (user != null)
        //        {
        //            await Authenticate(dataUser);
        //            TempData["message"] = $"Добро пожаловать: {user.LastName} {user.FirstName} {user.MiddleName}.";

        //            return RedirectToAction("Index", "Home");
        //        }
        //    }
        //    ModelState.AddModelError("", "Неверное имя пользователя или пароль");
        //    return View(dataUser);
        //}

        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginModel dataUser)
        {
            if (ModelState.IsValid)
            {
                var user = _authorizationRepository.Authorization(dataUser.Name, dataUser.Password, "", Asb.Bank.Utilite.Enums.TypeApplications.BankModuleSystemAdmin, HttpContext.Request.Headers?.FirstOrDefault(s => s.Key.ToLower() == "user-agent").Value);
                if (user != null)
                {
                    await Authenticate(dataUser);
                    HttpContext.Session.SetString("user", user.FIOUser ?? "нет данных");
                    var lastvisit = HttpContext.Request.Cookies["LastVisit"] ?? "нет данных";
                    TempData["message"] = $"Добро пожаловать: {user.FIOUser}. Последний вход: {lastvisit}";
                    logger.LogInformation($"Успешный вход пользователя {user.FIOUser}. Последний вход: {lastvisit}");

                    return RedirectToAction("Index", "Home");
                }
            }
            logger.LogInformation($"Ошибка авторизации {dataUser.Name}");

            ModelState.AddModelError("", "Неверное имя пользователя или пароль");
            return View(dataUser);
        }

        private async Task Authenticate(LoginModel model)
        {
            // создаем один claim
            var claims = new List<Claim>
            {
                new Claim(ClaimsIdentity.DefaultNameClaimType, model.Name)
            };
            // создаем объект ClaimsIdentity
            ClaimsIdentity id = new ClaimsIdentity(claims, "ApplicationCookie", ClaimsIdentity.DefaultNameClaimType, ClaimsIdentity.DefaultRoleClaimType);
            // установка аутентификационных куки
            await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, new ClaimsPrincipal(id));
        }

        public async Task<IActionResult> Logout()
        {
            await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login", "Account");
        }
    }
}