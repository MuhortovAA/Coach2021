﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.UserBank
{
    public class FilterUserBankViewModel
    {
        //[Required(ErrorMessage = "Введите текст для поиска в поле {0}")]
        [Display(Name = "Фамилия")]
        [StringLength(25, ErrorMessage = "Минимальная длина текста 1 символа максимальна 25", MinimumLength = 3)]
        public string LastName { get; set; }
        //[Required(ErrorMessage = "Введите текст для поиска в поле {0}")]
        [Display(Name = "Пользователь")]
        [StringLength(25, ErrorMessage = "Минимальная длина текста 3 символа максимальна 25", MinimumLength = 3)]
        public string Login { get; set; }
        [Display(Name = "АРМ")]
        [StringLength(25, ErrorMessage = "Минимальная длина текста 1 символа максимальна 25", MinimumLength = 1)]
        public string Application { get; set; }


    }
}
