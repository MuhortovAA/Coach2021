﻿using AdminWebCore.Services.Models.ViewModels;
using Asb.Bank.Administration.DataBase.Interfaces;
using Asb.Bank.Administration.DataBase.Repository;
using Asb.Bank.Administration.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.UserBank
{
    public class myUserBankRepository : Repositories
    {
        private readonly IAdminRepository _repo;

        public myUserBankRepository(IAdminRepository repo, IAdministrationRepository repository) : base(repository)
        {
            _repo = repo;
        }
        public UserBankViewModel GetAll()
        {
            var count = Repository.FindAll<UsersBank>().Count();
            var users = Repository.FindAll<UsersBank>().Take(10).ToList();
            var result = new UserBankViewModel() { usersbank=users, PageInfo = new PageInfo() { PageNumber = 1, PageSize = 10, TotalItems = (int)count } };
            return result;
        }
        public List<UsersBank> GetTenItems() => Repository.FindAll<UsersBank>().Take(10).ToList();
        public List<UsersBank> GetFiltered(FilterUserBankViewModel filter) => Repository.FindAll<UsersBank>().Where(user => user.LastName.StartsWith(filter.LastName ?? "")).Where(user => user.Login.Contains(filter.Login ?? "")).Take(10).ToList();
    }
}
