﻿using Asb.Bank.Administration.DataBase.Interfaces;
using Asb.Bank.Administration.DataBase.Repository;
using Asb.Bank.Administration.Entity;
using System.Collections.Generic;
using System.Linq;

namespace AdminWebCore.Services.Models.UsersCustomer
{
    public class myUsersCustomerRepository : Repositories
    {
        private readonly IAdminRepository _repo;

        public myUsersCustomerRepository(IAdminRepository repo, IAdministrationRepository repository) : base(repository)
        {
            _repo = repo;

        }

        public void Save(ViewUserCustomers user) => _repo.UserCustomers.Insert(user);

        public List<myViewUserCustomers> GetAll(string idcl) => ConvertTomyViewUserCustomers(_repo.UserCustomers.FindAllUserCustomer(int.Parse(idcl)).OrderBy(u => u.LastName).ToList());
        public int CountUsers(int id) => _repo.UserCustomers.FindAllUserCustomer(id).Count();
        private List<myViewUserCustomers> ConvertTomyViewUserCustomers(List<ViewUserCustomers> collection)
        {
            var users = new List<myViewUserCustomers>();
            var number = 1;
            foreach (var user in collection)
            {
                users.Add(new myViewUserCustomers() { myNumber = number++, id = user.id, FirstName = user.FirstName, MiddleName = user.MiddleName, LastName = user.LastName, Login = user.Login });
            }
            return users;
        }
        private bool CheckLogin(string login)
        {
            var result = _repo.UserCustomers.FindAllLogin(login);
            return false;
        }

    }
}
