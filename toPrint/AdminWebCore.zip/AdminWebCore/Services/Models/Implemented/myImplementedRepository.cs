﻿using Asb.Bank.Administration.DataBase.Interfaces;
using Asb.Bank.Administration.Entity;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.Implemented
{
    public class myImplementedRepository
    {
        private IAdministrationRepository _rep;
        public myImplementedRepository(IAdministrationRepository rep)
        {
            _rep = rep;
        }
        public List<Implemented> GetItems()
        {
            var result = new List<Implemented>();
            
            for (int i = 0; i < 10; i++)
            {
                var version = new Implemented()
                {
                    Id = i,
                    ImplementedDate = DateTime.Now,
                    ImplementedVersion = "1.30.39",
                    Information = "Разработан функционал: - ограничен доступ к полю VIP расположенное Главное окно-клиенты- выбрать клиента-поле VIP. Доступ к полю управляется через обьект доступа «Группы зачисления».",
                    InformationEng = "",
                    NoView = true,
                    TypeArm = 3
                };
                result.Add(version);
            }
            //var result = _rep.FromSql<Implemented>("SELECT * FROM [webclient].[Bank].[Implemented] where TypeArm = 3").ToList();
            //var result = _rep.FromSql<UsersBank>("SELECT TOP 1 * FROM [webclient].[Bank].[vUsersBank]").ToList();
            return result;
        }

        public string GetImplemented(int id)
        {
            var version = new Implemented()
            {
                Id = id,
                ImplementedDate = DateTime.Now,
                ImplementedVersion = "1.30.39",
                Information = "Разработан функционал: - ограничен доступ к полю VIP расположенное Главное окно-клиенты- выбрать клиента-поле VIP. Доступ к полю управляется через обьект доступа «Группы зачисления».",
                InformationEng = "",
                NoView = true,
                TypeArm = 3
            };
            var result = JsonSerializer.Serialize<Implemented>(version);
            return result;
        }

    }
    public class Implemented
    {
        public int Id { get; set; }
        [DisplayFormat(DataFormatString = "{0:dd.MM.yyyy}")]
        public System.DateTime ImplementedDate { get; set; }
        public string ImplementedVersion { get; set; }
        public string Information { get; set; }
        public int TypeArm { get; set; }
        public Nullable<bool> NoView { get; set; }
        public string InformationEng { get; set; }
    }
}
