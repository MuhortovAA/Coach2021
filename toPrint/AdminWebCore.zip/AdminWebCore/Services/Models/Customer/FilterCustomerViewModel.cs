﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.Customer
{
    public class FilterCustomerViewModel
    {
        //[Required(ErrorMessage = "Введите текст для поиска в поле {0}")]
        [Display(Name ="УНП")]
        [StringLength(9, ErrorMessage = "Минимальная длина текста 1 символ максимальна 9", MinimumLength = 1)]
        public string UNP { get; set; }
        //[Required(ErrorMessage = "Введите текст для поиска в поле {0}")]
        [Display(Name = "Название")]
        [StringLength(20, ErrorMessage = "Минимальная длина текста 3 символа максимальна 20", MinimumLength = 3)]
        public string NameCustomer { get; set; }
        //[Required(ErrorMessage = "Введите текст для поиска в поле Код клиента")]
        [Display(Name = "Код клиента")]
        [StringLength(4, ErrorMessage = "Минимальная длина текста 1 символ максимальна 4", MinimumLength = 1)]
        public string idcl { get; set; }
    }
}
