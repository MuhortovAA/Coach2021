﻿using Asb.Bank.Administration.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.Customer
{
    public class myViewCustomer : ViewCustomer
    {
        public int myNumber{ get; set; }
        public int CountUsers { get; set; }
    }
}
