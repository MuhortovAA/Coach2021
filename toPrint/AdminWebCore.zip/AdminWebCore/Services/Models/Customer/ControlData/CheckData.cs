﻿using AdminWebCore.Services.Models.Customer.ReservationsCustomer;
using AdminWebCore.Services.Models.UsersCustomer;
using Asb.Bank.Administration.DataBase.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.Customer.ControlData
{
    public class CheckData
    {
        //private static readonly myUsersCustomerRepository repo;
        //public CheckData(IAdminRepository repo, IAdministrationRepository repository)
        //{
        //    repo = new myUsersCustomerRepository(repo, repository);
        //}
        public static ValidationResult ValidationIDCL(string idcl)
        {

            var repo = new myReservationsCustomerIdRepository();

            var result = repo.GetAll().Where(cus => cus.Idcl == idcl).Count();

            if (result != 0) return new ValidationResult("Код клиента: Код клиента уже существует!");

            return ValidationResult.Success;
        }
        public static ValidationResult ValidationTypeDocument(string data)
        {

            if (data == null || data.Length == 0) return new ValidationResult("Тип документа: Не выбран тип документа");


            return ValidationResult.Success;
        }
        public static ValidationResult ValidationUserLogin(List<string> list)
        {


            if (list == null)

                return new ValidationResult("Пользователь: Не прошел контроль!");


            //return ValidationResult.Success;
            return new ValidationResult("Пользователь: Не прошел контроль!");
        }
    }
}
