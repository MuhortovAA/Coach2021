﻿using DBCustomer.Services.Models;
using System.Collections.Generic;
using System.Linq;


namespace AdminWebCore.Services.Models.Customer.ReservationsCustomer

{
    public class myReservationsCustomerIdRepository
    {
        private CustomerDbContext ctx;

        public myReservationsCustomerIdRepository()
        {
            ctx = new CustomerDbContext();
        }
        public List<ReservationsCustomerId> GetAll() => ctx.ReservCutomer.ToList();
    }
}
