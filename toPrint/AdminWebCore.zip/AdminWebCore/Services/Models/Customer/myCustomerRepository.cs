﻿using AdminWebCore.Services.Models.Customer.TypeDocument;
using AdminWebCore.Services.Models.UsersCustomer;
using AdminWebCore.Services.Models.ViewModels;
using Asb.Bank.Administration.DataBase.Interfaces;
using Asb.Bank.Administration.DataBase.Repository;
using Asb.Bank.Administration.Entity;
using Asb.Bank.Directories.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.Customer
{

    public class myCustomerRepository : Repositories
    {
        private readonly IAdminRepository _repo;
        private readonly myUsersCustomerRepository repoUsersCustomer;
        private readonly IDirectoryRepository _repodir;

        public myCustomerRepository(IAdminRepository repo, IAdministrationRepository repository, IDirectoryRepository repodir) : base(repository)
        {
            _repo = repo;
            repoUsersCustomer = new myUsersCustomerRepository(repo, repository);
            _repodir = repodir;
        }
        public CustomerViewModel GetAll() => new CustomerViewModel()
        {
            Customers = ConvertTomyViewCustomer(_repo.Customer.FindAll("idcl", 0, 10).ToList()),
            PageInfo = new PageInfo() { PageNumber = 1, PageSize = 10, TotalItems = (int)_repo.Customer.Count() }
        };

        public List<myViewCustomer> GetPageNumber(string PageNumber, string PageSize, FilterCustomerViewModel filter)
        {
            Expression<Func<ViewCustomer, bool>> bind = c => c.idcl.Contains(filter.idcl ?? "") && c.name.Contains(filter.NameCustomer ?? "") && c.UNP.Contains(filter.UNP ?? "");

            var count = _repo.Customer.Count(bind);
            var skipNumber = int.Parse(PageNumber) == 1 ? 0 : (int.Parse(PageNumber) - 1) * int.Parse(PageSize);
            var collection = _repo.Customer.FindAll(bind, "idcl", skipNumber, 10).ToList();
            //

            //
            var customers = new List<myViewCustomer>();
            var number = skipNumber == 0 ? 1 : skipNumber + 1;
            foreach (var customer in collection)
            {
                customers.Add(new myViewCustomer() { myNumber = number++, idcl = customer.idcl, name = customer.name, UNP = customer.UNP, id = customer.id, CountUsers = repoUsersCustomer.CountUsers(customer.id) });
            }

            return customers;
        }
        public List<myViewCustomer> GetPageNumber2(string PageNumber, string PageSize)
        {
            var count = _repo.Customer.Count();
            var skipNumber = int.Parse(PageNumber) == 1 ? 0 : (int.Parse(PageNumber) - 1) * int.Parse(PageSize);
            var collection = _repo.Customer.FindAll("idcl", skipNumber, 10).ToList();
            var customers = new List<myViewCustomer>();
            var number = skipNumber == 0 ? 1 : skipNumber + 1;
            foreach (var customer in collection)
            {
                customers.Add(new myViewCustomer() { myNumber = number++, idcl = customer.idcl, name = customer.name, UNP = customer.UNP });
            }

            return customers;
        }
        public ViewCustomer GetByID(string id)
        {
            Expression<Func<ViewCustomer, bool>> bind = c => c.id == Int32.Parse(id);
            var result = _repo.Customer.FindAll(bind, "idcl", 0, 10).First();
            return result;

        }

        public ViewCustomer Save(ViewCustomer customer, string users)
        {
            //
            Expression<Func<ViewCustomer, bool>> bind = c => c.idcl == customer.idcl && c.name == customer.name && c.UNP == customer.UNP;
            var result = _repo.Customer.FindAll(bind, "idcl", 0, 10).First();
            //
            var listusers = users.Split('|');
            var count = 0;
            var itemId = 9;
            foreach (var item in listusers)
            {
                if (count == itemId && item.Trim() != "")
                {
                    var user = new ViewUserCustomers()
                    {
                        LastName = item.Trim().Split(" ")[0],
                        FirstName = item.Trim().Split(" ")[2],
                        MiddleName = item.Trim().Split(" ")[1],
                        NameRoli = listusers[itemId + 1],
                        Phones = listusers[itemId + 2],
                        Login = $"{result.idcl}_{item.Trim().Split(" ")[0]}-{item.Trim().Split(" ")[2].Substring(0, 1)}{item.Trim().Split(" ")[1].Substring(0, 1)}",
                        ClientID = result.id,
                        Password = "12345678",
                        IDKey = "",
                        KeySN = "",
                    };
                    repoUsersCustomer.Save(user);

                    itemId = itemId + 3;
                }
                count++;
            }
            //
            _repo.Customer.Insert(customer);
            //
            return result;

        }

        //public async void SaveAsync(ViewCustomer customer)
        //{
        //    await Task.Run(() => _repo.Customer.Insert(customer));
        //}

        public CustomerViewModel GetFiltered(FilterCustomerViewModel filter)
        {

            //
            Expression<Func<ViewCustomer, bool>> bind = c => c.idcl.Contains(filter.idcl ?? "") && c.name.Contains(filter.NameCustomer ?? "") && c.UNP.Contains(filter.UNP ?? "");

            //var customers = new List<myViewCustomer>();
            //var number = 1;

            //foreach (var customer in _repo.Customer.FindAll(bind, "idcl", 0, 10).ToList())
            //{
            //    customers.Add(new myViewCustomer() { myNumber = number++, idcl = customer.idcl, name = customer.name, UNP = customer.UNP });
            //}

            //var customers = this.ConvertTomyViewCustomer(_repo.Customer.FindAll(bind, "idcl", 0, 10).ToList());

            return new CustomerViewModel()
            {
                Customers = ConvertTomyViewCustomer(_repo.Customer.FindAll(bind, "idcl", 0, 10).ToList()),
                PageInfo = new PageInfo()
                {
                    PageNumber = 1,
                    PageSize = 10,
                    TotalItems = (int)_repo.Customer.Count(bind)
                }
            };
        }

        public List<myViewCustomer> GetFiltered3(FilterCustomerViewModel filter)
        {
            var count = _repo.Customer.Count(c => c.idcl.Contains(filter.idcl ?? "") &&
                                                  c.name.Contains(filter.NameCustomer ?? "") &&
                                                  c.UNP.Contains(filter.UNP ?? ""));

            var collection = _repo.Customer.FindAll(c => c.idcl.Contains(filter.idcl ?? "") &&
                                                         c.name.Contains(filter.NameCustomer ?? "") &&
                                                         c.UNP.Contains(filter.UNP ?? ""), "idcl", 0, 10).ToList();

            var customers = new List<myViewCustomer>();
            var number = 1;
            foreach (var customer in collection)
            {
                customers.Add(new myViewCustomer() { myNumber = number++, idcl = customer.idcl, name = customer.name, UNP = customer.UNP });
            }

            return customers;
        }
        public List<ViewCustomer> GetFiltered2(FilterCustomerViewModel filter)
        {
            var result = _repo.Customer.FindAll(
                c => c.idcl.Contains(filter.idcl ?? "")
                && c.name.Contains(filter.NameCustomer ?? "")
                && c.UNP.Contains(filter.UNP ?? ""), "idcl", 0, 10).ToList();
            return result;
        }
        public CustomerViewModel Forward() => new CustomerViewModel() { Customers = ConvertTomyViewCustomer(_repo.Customer.FindAll("idcl", 10, 10).ToList()), PageInfo = new PageInfo() };
        public List<ViewCustomer> myGetTenItems() => Repository.FindAll<ViewCustomer>().Take(10).ToList();
        public List<ViewCustomer> myGetFiltered(FilterCustomerViewModel filter) => Repository.FindAll<ViewCustomer>().Where(cus => cus.UNP.StartsWith(filter.UNP ?? "")).Where(cus => cus.name.Contains(filter.NameCustomer ?? "")).Where(cus => cus.idcl.Contains(filter.idcl ?? "")).Take(10).ToList();

        private List<myViewCustomer> ConvertTomyViewCustomer(List<ViewCustomer> collection)
        {
            var customers = new List<myViewCustomer>();
            var number = 1;

            foreach (var customer in collection)
            {
                customers.Add(new myViewCustomer() { myNumber = number++, idcl = customer.idcl, name = customer.name, UNP = customer.UNP, CountUsers = repoUsersCustomer.CountUsers(customer.id), id = customer.id });
            }
            return customers;
        }

    }
}
