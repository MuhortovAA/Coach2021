﻿using DBCustomer.Services.Models;
using System.Collections.Generic;
using System.Linq;


namespace AdminWebCore.Services.Models.Customer.TypeDocument
{
    public class myTypeDocumentsRepository
    {
        private CustomerDbContext ctx;
        public myTypeDocumentsRepository()
        {
            ctx = new CustomerDbContext();
        }

        public List<TypeDocument> GetAll()
        {
            var collection = ctx.Viddok.ToList().OrderBy(s => s.Naimdok);
            var result = new List<TypeDocument>();
            foreach (var item in collection)
            {
                result.Add((TypeDocument)item);
            }
            return result;
        }
    }
}
