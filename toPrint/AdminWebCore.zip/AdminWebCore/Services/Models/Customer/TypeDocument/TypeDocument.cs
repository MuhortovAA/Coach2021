﻿using DBCustomer.Services.Models;

namespace AdminWebCore.Services.Models.Customer.TypeDocument
{
    public class TypeDocument
    {
        public static explicit operator TypeDocument(Viddok vc)
        {
            var sc = new TypeDocument()
            {
                Id = vc.Koddok, 
                DocName=vc.Naimdok
             
            };
            return sc;

        }
        public string Id { get; set; }
        public string DocName { get; set; }
    }
}
