﻿using System.Collections.Generic;

namespace AdminWebCore.Services.Models.Customer.TypeDocument
{
    public class TypeDocumnetListViewModel
    {
        public List<TypeDocument> List { get; set; }
        public string Current { get; set; }
    }
}
