﻿using AdminWebCore.Services.Models.ViewModels;
using Asb.Bank.Administration.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.Customer
{
    public class CustomerViewModel
    {
        public List<myViewCustomer> Customers { get; set; }
        public PageInfo PageInfo { get; set; }
    }
}
