﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace AdminWebCore.Services.Models.Customer
{
    public class CreateModelUr
    {
        //Название организации
        [Required(ErrorMessage = "{0}: Поле обязательно для заполнения")]
        [StringLength(105, ErrorMessage = "{0}: длина поля 105-ть знаков!")]
        [RegularExpression(@"[^-|:]{1}[^~!@#$^&_|<>[\]`{}№\\№«»]+", ErrorMessage = "{0}: Укажите допустимые знаки!")]
        [Display(Name = "Название", Description = "Укажите название организации. Допускается до 105 знаков")]

        public string name { get; set; }

        //Название организации (Latin)
        [StringLength(105, ErrorMessage = "{0}: длина поля 105-ть знаков!")]
        [RegularExpression(@"[^-|:]{1}[^~!@#$^&_|<>[\]`{}№\\№«»]+", ErrorMessage = "{0}: Укажите допустимые знаки!")]
        [Display(Name = "Название (Latin)", Description = "Укажите название организации. Допускается до 105 знаков")]
        public string NameCustomerLatin { get; set; }

        //Адрес платильщика (Latin)
        [StringLength(255, ErrorMessage = "{0}: длина поля 255-ть знаков!")]
        [Display(Name = "Адрес плательщика Latin", Description = "Укажите Адрес плательщика Latin")]
        public string AddressLatin { get; set; }

        //Адрес платильщика
        [Required(ErrorMessage = "{0}: Поле обязательно для заполнения")]
        [StringLength(255, ErrorMessage = "{0}: длина поля 255-ть знаков!")]
        [Display(Name = "Адрес плательщика", Description = "Укажите Адрес плательщика")]
        public string Address { get; set; }

        //ФИО
        [Required(ErrorMessage = "{0}: Поле обязательно для заполнения")]
        [StringLength(105, ErrorMessage = "{0}: длина поля 105-ть знаков!")]
        [Display(Name = "ФИО", Description = "Укажите ФИО руководителя")]
        public string FIOBoss { get; set; }

        //Телефон
        [Required(ErrorMessage = "{0}: Поле обязательно для заполнения")]
        [StringLength(50, ErrorMessage = "{0}: длина поля 50-т знаков!")]
        [Display(Name = "Телефон", Description = "Укажите телефон организации")]
        public string Phones { get; set; }

        //код клиента
        [Required(ErrorMessage = "{0}: Поле обязательно для заполнения")]
        [Display(Name = "код клиента", Description = "Укажите уникальный код клиента в системе")]
        [RegularExpression(@"[a-zA-Z0-9][a-zA-Z0-9][a-zA-Z0-9][a-zA-Z0-9]", ErrorMessage = "{0}: Укажите допустимые знаки: буквы верхнего, нижнего регистров и цифры!")]
        [StringLength(4, ErrorMessage = "{0}: длина поля 4-и символа!", MinimumLength = 4)]
        public string idcl { get; set; }

        //E-mail
        [StringLength(50, ErrorMessage = "{0}: длина поля 50-т знаков!")]
        [Required(ErrorMessage = "{0}: Поле обязательно для заполнения")]
        [Display(Name = "Email", Description = "Укажите Email клиента")]
        public string Email { get; set; }

        //УНП
        [Required(ErrorMessage = "{0}: Поле обязательно для заполнения")]
        [Display(Name = "УНП", Description = "Укажите учетный номер платильщика")]
        [StringLength(10, ErrorMessage = "{0}: длина поля 9-ть символов!", MinimumLength = 9)]
        public string UNP { get; set; }

        //Удаленная поддержка
        [Display(Name = "Удаленная поддержка клиента", Description = "Укажите удаленную поддержку клиента")]
        public bool PrRemoteSupport { get; set; }
        //тип клиента 0-юрлицо 1- ИП
        public byte? prUrPI { get; set; }
    }
}
