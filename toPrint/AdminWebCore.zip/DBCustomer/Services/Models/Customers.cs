﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBCustomer.Services.Models
{
    public class Customers
    {
        public int id { get; set; }
        public string idcl { get; set; }
        public string name { get; set; }
        public string AddresInstal { get; set; }
        public string address { get; set; }
        public string FIOBoss { get; set; }
        public string Phones { get; set; }
        public string Email { get; set; }
        public Nullable<System.DateTime> DateOn { get; set; }
        public Nullable<System.DateTime> DateOff { get; set; }
        public string UNP { get; set; }
        public Nullable<bool> bWork { get; set; }
        public Nullable<int> IDFilial { get; set; }
        public Nullable<byte> TypeArm { get; set; }
        public Nullable<byte> Kanal { get; set; }
        public Nullable<bool> PrAcc { get; set; }
        public Nullable<bool> prRate { get; set; }
        public Nullable<bool> prECIK { get; set; }
        public Nullable<bool> prHtamp { get; set; }
        public Nullable<bool> prBXDoc { get; set; }
        public Nullable<bool> prObrTXT { get; set; }
        public Nullable<bool> prVipKart { get; set; }
        public Nullable<bool> bDelete { get; set; }
        public Nullable<bool> prCentr { get; set; }
        public Nullable<byte> prUrPI { get; set; }
        public Nullable<byte> TypeDocument { get; set; }
        public string SeriesAndNumderDoc { get; set; }
        public string IdentificationNumber { get; set; }
        public Nullable<System.DateTime> DateOfIssueOfTheDocument { get; set; }
        public string AuthorityIssuingTheDocument { get; set; }
        public Nullable<bool> AutoExtraction { get; set; }
        public Nullable<int> TemplateExtractionID { get; set; }
        public Nullable<System.TimeSpan> FirstTimeExtraction { get; set; }
        public Nullable<System.TimeSpan> LastTimeExtraction { get; set; }
        public Nullable<System.TimeSpan> IntervalExtraction { get; set; }
        public Nullable<bool> WorkPackage { get; set; }
        public Nullable<int> CustomerStopWorkId { get; set; }
        public Nullable<System.DateTime> FirstDateStopWork { get; set; }
        public Nullable<System.DateTime> LastDateStopWork { get; set; }
        public string CodeCustomerODB { get; set; }
        public Nullable<bool> TestCustomer { get; set; }
        public Nullable<bool> PrRemoteSupport { get; set; }
        public string NumberContractRemoteSupport { get; set; }
        public Nullable<System.DateTime> DataContractRemoteSupport { get; set; }
        public string CodeCustomerSap { get; set; }
        public string NameCustomerEng { get; set; }
        public string AddressEng { get; set; }
        public string TypeSettlementEng { get; set; }
        public string NameSettlementEng { get; set; }
        public string NameSettlementRus { get; set; }
        public Nullable<bool> PrNotResident { get; set; }
        public Nullable<bool> PrQueryInformationListEnlistment { get; set; }
        public string CodeCustomerOdbScOracle { get; set; }
        public string CodeCustomerOdbScOracleOld { get; set; }
        public string NameCustomerLatin { get; set; }
        public string AddressLatin { get; set; }
        public string CodeCustomerDepositary { get; set; }
        public Nullable<bool> IsVip { get; set; }
        public string RetailId { get; set; }
        public string AgreementNumber { get; set; }
    }
}