﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBCustomer.Services.Models
{
    public class Viddok
    {
        public string Prkor { get; set; }
        public string Koddok { get; set; }
        public string Naimdok { get; set; }
    }
}
