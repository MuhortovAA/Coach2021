﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBCustomer.Services.Models
{
    public class ReservationsCustomerId
    {
        public int ReservationsId { get; set; }
        public int UserCreateId { get; set; }
        public string Idcl { get; set; }
        public System.DateTime DateCreate { get; set; }
    }
}
