﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBCustomer.Services.Interfaces
{
    public interface IBase<T>
    {
        public T GetAll();
    }
}
