﻿using DBCustomer.Services.Interfaces;
using DBCustomer.Services.Models;
using System.Collections.Generic;
using System.Linq;


namespace DBCustomer.Services.Repository
{
    public class ReservationsCustomerRepository : IBase<List<ReservationsCustomerId>>
    {
        private CustomerDbContext context;

        public ReservationsCustomerRepository(CustomerDbContext ctx)
        {
            context = ctx;
        }
        public List<ReservationsCustomerId> GetAll() => context.ReservCutomer.ToList();

    }
}
