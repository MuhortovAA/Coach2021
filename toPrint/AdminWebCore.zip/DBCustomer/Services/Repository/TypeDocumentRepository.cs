﻿using DBCustomer.Services.Interfaces;
using DBCustomer.Services.Models;
using System.Collections.Generic;
using System.Linq;

namespace DBCustomer.Services.Repository
{
    public class TypeDocumentRepository : IBase<List<Viddok>>
    {
        private CustomerDbContext context;
        public TypeDocumentRepository(CustomerDbContext ctx)
        {
            context = ctx;
        }
        public List<Viddok> GetAll() => context.Viddok.ToList();
    }
}
