﻿using System;

namespace DBTypeDocumentCore
{
    public class Class1
    {
    }
}
