﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBTypeDocumentCore.Services.Interfaces
{
    public interface ITypeDocument
    {
        public List<Viddok> GetAll();
    }
}
