﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBTypeDocumentCore.Services.Interfaces
{
    public interface IBase<T>
    {
        public T GetAll();
    }
}
