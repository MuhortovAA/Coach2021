﻿using DBTypeDocumentCore.Services.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTypeDocumentCore.Services.Context
{
    public class ApplicationDbContext : DbContext
    {
        //public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<Viddok> Viddok { get; set; }
        public DbSet<ReservationsCustomerId> ReservCutomer { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=sca-orporas-t;Initial Catalog=webclient;Persist Security Info=True;User ID=userwebclient;Password=795525;");
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ReservationsCustomerId>().ToTable(nameof(ReservationsCustomerId), nameof(ShemaTables.Bank)).HasKey(k => k.ReservationsId);
            modelBuilder.Entity<Viddok>().ToTable(nameof(Viddok), nameof(ShemaTables.Referencies)).HasNoKey();
            //modelBuilder.Entity<Viddok>(eb => { eb.HasNoKey(); } );
            //modelBuilder.Entity<Viddok>().ToTable(nameof(Viddok), nameof(ShemaTables.Referencies)).HasKey(x => new { x.Prkor, x.Koddok });
        }
        public enum ShemaTables
        {
            Referencies,
            Client,
            Bank,
            Document,
            Sign,
            Derivative,
            PostedDocumend,
            dbo,
            Depositary,
            Access
        }
    }
}
