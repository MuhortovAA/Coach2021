﻿using DBCustomer.Services.Interfaces;
using DBCustomer.Services.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace DBTypeDocumentCore.Services.Repository
{
    public class ReservationsCustomerRepository : IBase<List<ReservationsCustomerId>>
    {
        public List<ReservationsCustomerId> GetAll()
        {
            throw new NotImplementedException();
        }
    }
}
