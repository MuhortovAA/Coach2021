﻿using DBTypeDocumentCore.Services.Context;
using DBTypeDocumentCore.Services.Interfaces;
using System.Collections.Generic;
using System.Linq;


namespace DBTypeDocumentCore.Services.Repository
{
    public class TypeDocumentRepository : ITypeDocument
    {
        private ApplicationDbContext context;
        public TypeDocumentRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public List<Viddok> GetAll()
        {
            var result = context.Viddok.ToList();
            return result;
        }
    }
}
