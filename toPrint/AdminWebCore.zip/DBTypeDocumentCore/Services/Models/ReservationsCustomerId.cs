﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBTypeDocumentCore.Services.Models
{
    public class ReservationsCustomerId
    {
        public int ReservationsId { get; set; }
        public int UserCreateId { get; set; }
        public string Idcl { get; set; }
        public System.DateTime DateCreate { get; set; }
    }
}
