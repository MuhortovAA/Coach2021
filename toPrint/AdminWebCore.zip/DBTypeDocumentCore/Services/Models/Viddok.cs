﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBTypeDocumentCore
{
    public class Viddok
    {
        public string Prkor { get; set; }
        public string Koddok { get; set; }
        public string Naimdok { get; set; }
    }
}
