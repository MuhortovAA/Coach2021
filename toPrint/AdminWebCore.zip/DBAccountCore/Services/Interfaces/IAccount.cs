﻿using DBAccountCore.Services.Models;
using DBAccountCore.Services.Models.ViewModel.Account;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DBAccountCore.Services.Interfaces
{
    public interface IAccount
    {
        LUserARM_Result Authorization(LoginModel loginModel);
    }
}
