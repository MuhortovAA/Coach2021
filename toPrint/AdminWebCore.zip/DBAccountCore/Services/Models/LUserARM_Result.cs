﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBAccountCore.Services.Models
{
    public partial class LUserARM_Result
    {
        public string Name { get; set; }
        public int ClientID { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string IDKey { get; set; }
        public string KeySN { get; set; }
        public Nullable<int> LoginNo { get; set; }
        public Nullable<byte> bLogin { get; set; }
        public Nullable<byte> CodeARM { get; set; }
        public Nullable<byte> LevelAccess { get; set; }
        public int id { get; set; }
        public string LastName { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public Nullable<int> DayOper { get; set; }
        public Nullable<System.DateTime> DateChangePassword { get; set; }
        public Nullable<byte> PeriodChangePassword { get; set; }
        public Nullable<bool> FlagChangePassword { get; set; }
        public Nullable<byte> CountChangePassword { get; set; }
        public Nullable<System.DateTime> DateNewChangePassword { get; set; }
        public Nullable<bool> bWork { get; set; }
        public System.DateTime DateCreation { get; set; }
        public Nullable<byte> ExitNoChangePassword { get; set; }
        public Nullable<System.DateTime> DateBlock { get; set; }
        public Nullable<int> ErrorLoginNo { get; set; }
        public Nullable<System.DateTime> DateErrorLoginNo { get; set; }
        public Nullable<int> DayBlockErrorLogin { get; set; }
        public Nullable<int> CountDayBlockErrorLogin { get; set; }
        public Nullable<System.DateTime> DateBlockLogin { get; set; }
        public Nullable<bool> UserTechnical { get; set; }
        public string UserCodeSAPDM { get; set; }
        public string Mfo { get; set; }
        public Nullable<int> OrgunitCode { get; set; }
        public Nullable<int> TypeODB { get; set; }
        public int IDRoli { get; set; }
        public string Email { get; set; }
        public string NameRoli { get; set; }
        public string BikIban { get; set; }
        public Nullable<System.DateTime> LastBlockDate { get; set; }
        public Nullable<bool> PrSaleManager { get; set; }
        public Nullable<bool> PrExecuteDeposit { get; set; }
        public string UserCodeCSRUB { get; set; }
        public Nullable<bool> PrRecvdoca { get; set; }
    }
}
