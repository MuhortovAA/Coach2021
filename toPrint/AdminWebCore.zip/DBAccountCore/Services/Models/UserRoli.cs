﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DBAccountCore.Services.Models
{
    public partial class UserRoli
    {
        public int ID { get; set; }
        public int UserBankID { get; set; }
        public int CodeRoliID { get; set; }
    }
}
