﻿using DBAccountCore.Services.Interfaces;
using DBAccountCore.Services.Models;
using DBAccountCore.Services.Models.ViewModel.Account;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;

namespace DBAccountCore.Services.Repository
{
    public class UserRepository : IAccount
    {

        private AccountDbContext context;
        public UserRepository(AccountDbContext ctx)
        {
            context = ctx;
        }

        public LUserARM_Result Authorization(LoginModel user)
        {

            var p_key = "0000";
            var p_arm = 3;
            var p_err = 0;
            
            var result = context.userarm.FromSqlRaw($"exec [Bank].[LUserARM] @Login={user.Name}, @Password={user.Password}, @KeySN={p_key}, @TypeArmID={p_arm}, @ErrorCode={p_err}").ToList().FirstOrDefault();

            return result;

        }
    }
}
