﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NineCSharpApp
{
    class Program
    {
        //public record Person(string FirstName, string LastName);
        static void Main(string[] args)
        {
        }
    }
}
