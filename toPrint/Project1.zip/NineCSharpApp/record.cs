﻿namespace NineCSharpApp
{
    public class record
    {
    }
}