﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EqualApp
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;
            for (int j = 0; j < 9; j++)
            {

            }
            for (; i < 9;)
            {
                Console.WriteLine($"Квадрат числа {++i} равен {i * i}");
            }
            Console.ReadLine();
        }
    }
}
