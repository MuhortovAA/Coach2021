﻿namespace StrategyApp
{
    internal interface IJob
    {
        void ToDoJob();
    }
}