﻿namespace ClassApp
{
    partial class myBase
    {
        public struct Person { };
    }
}
