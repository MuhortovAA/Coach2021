WITH myTable 
AS (
	SELECT        
		c.Login, 
		r.Name,
		r.CodeARM
    FROM Bank.user_client as c 
	INNER JOIN Referencies.roli as r ON c.IDRoli = r.ID
	where c.bWork = '1'
	UNION ALL
    SELECT        
		b.Login, 
		r1.Name,
		r1.CodeARM
    FROM            Bank.UsersBank as b 
	INNER JOIN Referencies.roli AS r1 ON b.IDRoli = r1.ID
	where b.bWork = '1'
		)
    SELECT        
		a.name,
		COUNT(*) as CountUser
     FROM            myTable AS t
	 INNER JOIN [Access].[Arm] as a ON t.CodeARM = a.id
	 Group by a.name
	 Order by name