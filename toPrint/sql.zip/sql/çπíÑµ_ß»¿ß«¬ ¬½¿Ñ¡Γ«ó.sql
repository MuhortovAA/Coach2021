select 
c.[id]
, c.[idcl]
, c.[name]
, c.[bWork]
, gc.[GroupID]
, gc.[CustomerID]
from [webclient].[Bank].[Customers] as c
JOIN webclient.Bank.Branches AS b ON c.IDFilial = b.ID
LEFT JOIN webclient.Access.GroupCustomer as gc ON gc.[CustomerID] = c.[id] AND gc.GroupID='4817' 
where c.[bWork]=1
--and b.[Filial] in ('700') 
AND 
b.[cby] in ('601','605','606','611','619','624','625','626','627','632')
--b.[CBY] in ('700','701','706','711','715','723','725','726','728','703','707','709','722','708','710','712','713','714','721','724','727') 
--AND gc.[GroupID] is not null
ORDER BY id asc

