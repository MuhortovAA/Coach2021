with mytable as (
select top (2000) 
*
 from 
[webclient].[Bank].[UsersBank] as u
--where u.DateChangePassword='2019.07.26'
order by id desc)
select * from mytable as m
where m.Email is null
--group by m.[OrgunitCode]


group by u.OrgunitCode, id



select top (1000) 
*
 from 
[webclient].[Bank].[UsersBank] as u
order by id desc
where u.email is null
--u.[DateCreation]='1900.01.01'
--u.DateChangePassword='2019.07.26'
--OrgunitCode in ('50006755','50008285','50008294','50010629','50010634','50012937')