USE [webclient]
GO
DECLARE @mydatetime DATETIME = '2017-01-01';  
DECLARE @strdate VARCHAR(8);
DECLARE @myresult TABLE (res1 varchar(255),res2 varchar(255),res3 varchar(255) );
while @mydatetime <= '2017-31-03'
begin
set @strdate = replace(convert(NVARCHAR, @mydatetime, 112), '-', '')
INSERT INTO @myresult (res1,res2,res3) EXEC [webclient].[dbo].[Dynamic_SP] @strdate
set @mydatetime = DATEADD(DAY,1,@mydatetime)
end;

--WITH mytable as (

--SELECT b.[Name] as brname, count(b.[Name]) as countcus, 'all' as mytype FROM [webclient].[Bank].[Customers] as c
--RIGHT JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial] 
--WHERE c.[bWork]=1
--GROUP BY b.[Name]
--UNION ALL
select t.[res1] as branches, count(distinct t.[res2]) as activcustomers from @myresult as t
group by t.[res1]

--)
--SELECT * FROM mytable
--PIVOT(sum([activcustomers]) for [mytype] in ([activ], [all])) as pvt

