SELECT * 
FROM  [webclient].[Bank].[Branches] as b
WHERE b.[Filial] = '527'

update [webclient].[Bank].[Branches] 
set [bDelete]=0
where [ID]='2625'