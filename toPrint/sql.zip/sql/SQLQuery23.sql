SELECT        
	ROW_NUMBER() OVER (ORDER BY [DateOn] DESC) AS Row
	, c.[name]
	, c.[idcl]
	, c.[DateOn]
	, c.[dateoff]
	, DATEPART(yy, [DateOn]) AS Expr1
	, CASE c.[bWork] WHEN 1 THEN '��������' WHEN '0' THEN '��������' END
	, b.[Name] AS brname
	, c.[Email] AS email
	, c.[UNP]
	, CASE c.[prUrPI] WHEN 1 THEN '��' WHEN 0 THEN '������' END 'Person'
	, CASE c.[Kanal] WHEN 1 THEN 'OFFLINE' WHEN 2 THEN 'ONLINE' END 'Kanal'
	, c.[TestCustomer]
	FROM [webclient].[Bank].[Customers] AS c 
	INNER JOIN [webclient].[Bank].[Branches] AS b ON c.[IDFilial] = b.[ID]
WHERE        YEAR(c.[DateOn]) IN ('2018') 
ORDER BY c.[DateOn] DESC