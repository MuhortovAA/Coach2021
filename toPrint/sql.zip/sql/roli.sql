WITH myTable AS (
				SELECT 
				r.[Name] as rname
				,count(c.[IDRoli]) as ucount
				,r.[codearm] as coderam
				,a.[id] as aid
				FROM [webclient].[Referencies].[roli] AS r 
				LEFT JOIN [webclient].[Bank].[user_client] AS c  ON c.[IDRoli] = r.[ID] 
				LEFT JOIN [webclient].[Access].[Arm] as a ON r.[CodeARM] = a.[id]
				where [codearm] = '1'
				group by r.[name], r.[codearm],a.[id]
				UNION ALL
				SELECT 
				r.[Name] as rname
				,count(b.[IDRoli]) as ucount
				,r.[codearm] as coderam
				,a.[id] as aid
				FROM [webclient].[Referencies].[roli] AS r 
				LEFT JOIN [webclient].[Bank].[UsersBank] b ON b.[IDRoli] = r.[ID]
				LEFT JOIN [webclient].[Access].[Arm] as a ON r.[CodeARM] = a.[id]
				where [codearm] = '2'
				group by r.[name], r.[codearm],a.[id]

					--right JOIN [webclient].Bank.user_client AS c  ON c.IDRoli = r.ID 
					--INNER JOIN [webclient].Bank.Customers AS cu ON c.ClientID = cu.id 
					--INNER JOIN [webclient].Bank.Branches AS br ON cu.IDFilial = br.ID
					--INNER join [webclient].[Access].[Arm] as a ON r.CodeARM = a.id
	--SELECT c.Login, r.Name, c.bWork, br.Name AS brname, '������' AS cl, a.id as aid
	--FROM [webclient].Bank.user_client AS c 
	--right JOIN [webclient].Referencies.roli AS r ON c.IDRoli = r.ID 
	--INNER JOIN [webclient].Bank.Customers AS cu ON c.ClientID = cu.id 
	--INNER JOIN [webclient].Bank.Branches AS br ON cu.IDFilial = br.ID
	--INNER join [webclient].[Access].[Arm] as a ON r.CodeARM = a.id
	--UNION ALL
	--SELECT b.Login, r.Name, b.bWork, br.Name AS brname, '����' AS cl, a.id as aid
	--FROM            Referencies.roli as r 
	--		LEFT JOIN [webclient].[Bank].[UserRoli] ur ON r.[id] = ur.[CodeRoliID]
	--		LEFT JOIN [webclient].[Bank].[UsersBank] b ON ur.[UserBankID] = b.[id]
	--		LEFT JOIN Bank.Branches AS br ON b.ClientID = br.ID 
	--		LEFT JOIN Access.Arm AS a ON r.CodeARM = a.id
			)
	SELECT ROW_NUMBER() OVER (ORDER BY rname) AS myRow, rname, ucount, aid FROM myTable 
	--WHERE brname in (@Branches) and aid in (@arm) 
	--select * from myTable 
	--GROUP BY Name


	--select * from [webclient].[Bank].[UsersBank]
	--select * FROM [webclient].[Referencies].[roli]
	--select * FROM [webclient].[Access].[Arm]