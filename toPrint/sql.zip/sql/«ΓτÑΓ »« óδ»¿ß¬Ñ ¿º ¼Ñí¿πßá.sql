 --SELECT 
 --b.[Name]
 --,c.idcl
 --,c.[Kanal]
 --, a.AccountIban
 --,s.QueryDateTime
 ----webclient.[Bank].[CP866ToNVarChar](s.BodyStatementAccount)
 ----b.[Filial], b.[Mfo], count(*) as '���'
 --FROM [StatementAccount2017].[dbo].[Statement20170714] as s /*YYYYMMDD*/
 --JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID]
 --JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
 --JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
 --WHERE DAY(s.[QueryDateTime]) = 14 AND b.[Filial]='000' -- AND c.[Kanal] = 1
 ----GROUP BY  b.[Mfo], b.[Filial]
 ----HAVING  Count(*)<500
 
 --ORDER BY s.[QueryDateTime] desc

SELECT        
	ROW_NUMBER() OVER (ORDER BY bal.QueryTimeStatement DESC) AS myRow
	, br.name AS fil
	, br.filial
	, cus.name AS cus
	, acc.AccountIban
	, bracc.name AS nameacc
	, acc.ISO
	, bal.QueryDateTime
	, bal.QueryTimeStatement
	, bal.QueryStatement
	FROM [webclient].[Bank].BalanceAccount AS bal 
	INNER JOIN [webclient].[Bank].AccountCustomers AS acc ON acc.ID = bal.AccountID 
	INNER JOIN [webclient].[Bank].Customers AS cus ON cus.id = acc.CustomersID 
	INNER JOIN [webclient].[Bank].[Branches] AS br ON cus.idfilial = br.id 
	INNER JOIN [webclient].[Bank].[Branches] AS bracc ON bracc.id = acc.BranchID
WHERE bal.QueryTimeStatement IS NOT NULL AND bracc.name IN ('��� "��� �����������"', '��� � 524') --AND cus.name IN (@Customers)
ORDER BY bal.QueryTimeStatement DESC