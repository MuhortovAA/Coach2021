 SELECT        
				b.[id]
				,b.[Login]
				--,r.[ID]
				--,ur.[ID] as urid
				,COUNT (b.[Login] + ' ' + r.[Name]) as cur
				--, r.[Name]
				--, b.bWork
				--, br.[Name] AS brname
				--, '����' AS cl
				--, b.[DateCreation]
			FROM  [webclient].Referencies.roli as r 
				LEFT JOIN [webclient].[Bank].[UserRoli] ur ON r.[id] = ur.[CodeRoliID]
				LEFT JOIN [webclient].[Bank].[UsersBank] b ON ur.[UserBankID] = b.[id]
				LEFT JOIN Bank.Branches AS br ON b.ClientID = br.ID 
				LEFT JOIN Access.Arm AS a ON r.CodeARM = a.id
			--WHERE b.[bWork] = 0 --and b.id = 4053
			GROUP BY (b.[Login] + ' ' + r.[Name]), b.[Login], b.[id]
			HAVING COUNT(b.[Login] + ' ' + r.[Name]) > 1


		--DELETE  FROM [webclient].[Bank].[UserRoli]
		----WHERE [UserBankID] ='4072'
		----SELECT * FROM [webclient].[Bank].[UserRoli]
		--WHERE [UserBankID] IN 
		--(
		--		  SELECT        
		--		b.[id]
		--	FROM  [webclient].Referencies.roli as r 
		--		LEFT JOIN [webclient].[Bank].[UserRoli] ur ON r.[id] = ur.[CodeRoliID]
		--		LEFT JOIN [webclient].[Bank].[UsersBank] b ON ur.[UserBankID] = b.[id]
		--		LEFT JOIN Bank.Branches AS br ON b.ClientID = br.ID 
		--		LEFT JOIN Access.Arm AS a ON r.CodeARM = a.id
		--	WHERE b.[bWork] = 0 --and b.id = 4053
		--	GROUP BY (b.[Login] + ' ' + r.[Name]), b.[Login], b.[id]
		--	HAVING COUNT(b.[Login] + ' ' + r.[Name]) > 1				
		--)


  --where [ClientID] = '157'

			