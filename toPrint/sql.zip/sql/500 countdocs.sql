WITH myunion(mydate, bname, cname, tdoc) AS (
				SELECT '2015.06.01' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150601 AS txt JOIN Bank.Customers AS c ON txt.ClientID = c.id JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.01' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150601 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.02' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150602 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.02' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150602 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.03' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150603 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.03' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150603 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.04' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150604 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.04' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150604 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.05' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150605 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.05' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150605 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.06' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150606 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				--UNION ALL
				--SELECT '2015.06.06' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150606 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.07' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150607 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.07' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150607 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.08' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150608 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.08' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150608 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.09' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150609 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.09' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150609 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.10' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150610 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.10' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150610 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.11' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150611 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.11' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150611 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.12' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150612 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.12' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150612 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.13' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150613 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				--UNION ALL
				--SELECT '2015.06.13' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150613 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.14' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150614 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.14' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150614 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.15' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150615 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.15' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150615 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.16' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150616 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.16' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150616 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.17' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150617 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.17' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150617 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.18' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150618 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.18' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150618 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.19' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150619 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.19' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150619 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.20' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150620 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.20' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150620 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.21' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150621 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.21' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150621 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.22' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150622 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.22' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150622 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.23' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150623 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.23' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150623 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.24' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150624 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.24' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150624 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.25' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150625 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.25' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150625 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.26' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150626 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.26' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150626 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.27' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150627 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.27' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150627 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.28' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150628 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.28' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150628 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.29' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150629 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.29' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150629 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.30' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150630 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				UNION ALL
				SELECT '2015.06.30' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150630 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				--UNION ALL
				--SELECT '2015.06.31' AS mydate, b.[name] as bname, c.[name] as cname, 'TXT' as tdoc FROM [Document].txt20150631 AS txt INNER JOIN Bank.Customers AS c ON txt.ClientID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				--UNION ALL
				--SELECT '2015.06.31' AS mydate, b.[name] as bname, c.[name] as cname, 'PP' as tdoc FROM [Document].pp20150631 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id  JOIN [Bank].[Branches] as b ON b.id = c.idfilial
				)
select bname, cname, tdoc, count(tdoc) from myunion
--where bname = '������ � 500 � ������� ����������'
group by bname, cname, tdoc
order by bname, cname



	 --select * from Bank.Customers
