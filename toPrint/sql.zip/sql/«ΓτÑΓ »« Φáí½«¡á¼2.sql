/****** Script for SelectTopNRows command from SSMS  ******/
/****** Script for SelectTopNRows command from SSMS  ******/
USE [webclient]
GO
   --���� �
DECLARE @datefrom DATETIME = '2018-01-01'; -- YYYY-DD-MM
--���� ��
DECLARE @dateto DATETIME = '2018-31-12'--GETDATE();--'2017-30-09'--  -- YYYY-DD-MM GETDATE()
--
DECLARE @strdate VARCHAR(8);
--���� �� ����
DECLARE @sDAY VARCHAR(2); 
---
DECLARE @DynamicSQL nvarchar(4000) ='';
--
DECLARE @myresult TABLE ([typeTT] varchar(max), [item1] varchar(max));
--����
while @datefrom <= @dateto
---
begin

set @strdate = convert(varchar(8), @datefrom, 112)

DECLARE @tableSt VARCHAR(17) = concat('txt',@strdate);

	IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Document' AND  TABLE_NAME = @tableSt))
	BEGIN
	set @sDAY = convert(varchar(2),DAY(@datefrom))
	--
	SET @DynamicSQL=N'SELECT td.[NameTemplate] 
	, CASE c.[kanal] WHEN ''2'' THEN ''ONLINE'' WHEN ''1'' THEN ''OFFLINE'' END
	FROM [webclient].[Document].[txt'+ @strdate + '] as t
	join [webclient].[Bank].[Customers] as c ON c.[id]=t.[ClientID] 
	join [webclient].[Referencies].[TemplateDocuments] as td On td.[ID] = t.[TemplateID]'
	END
    --print @DynamicSQL
	INSERT INTO @myresult ([typeTT],[item1]) 
	EXECUTE sp_executesql @DynamicSQL
	SET @DynamicSQL=''
	---
set @datefrom = DATEADD(DAY,1,@datefrom)
end

select * from @myresult as r
pivot(count(r.[item1]) for r.[item1] in ([ONLINE], [OFFLINE])) p
