SELECT g.[nameAllOTS], c.[MID], CONVERT(varchar(10), c.[TransDateTime], 121), c.[TransSum], g.[unn], g.[procentNonAcq], g.[email], '205_226' 
FROM [dbo].[CMS20170817] AS c 
JOIN dbo.[GTRM] AS g ON c.[MID] = g.[MID] 
WHERE (c.[TransType] IN ('205', '226')) AND c.[TransDateTime] >= g.[dateDownloadGTRM] AND (g.[dateDeleteInGTRM] is null OR c.[TransDateTime] < g.[dateDeleteInGTRM]) AND g.[acquiring] = 0
SELECT g.[nameAllOTS], c.[MID], CONVERT(varchar(10), c.[TransDateTime], 121), c.[TransSum], g.[unn], g.[procentNonAcq], g.[email], '206_225' 
FROM [dbo].[CMS20170817] AS c 
JOIN dbo.[GTRM] AS g ON c.[MID] = g.[MID] 
WHERE (c.[TransType] IN ('206', '225')) AND c.[TransDateTime] >= g.[dateDownloadGTRM] AND (g.[dateDeleteInGTRM] is null OR c.[TransDateTime] < g.[dateDeleteInGTRM]) AND g.[acquiring] = 0