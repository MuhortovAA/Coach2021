/*2.3 ������������ */ 
/*205-226*/
  SELECT g.[nameAllOTS], g.[rangeCodes],   c.[MID], c.[CMSDate] ,'205-226' as '����', SUM(c.[TransSum]) as '�����'
  /*SELECT c.[MID], c.[TransType], c.[CMSDate], SUM(c.[TransSum])*/
  FROM [PartnerPayment].[dbo].[CMS] as c
  LEFT JOIN  [PartnerPayment].[dbo].[GTRM] as g ON g.[MID] = c.[MID]
  WHERE c.[TransType] in ('205', '226') AND g.[nameAllOTS] is not null
  GROUP BY g.[nameAllOTS], g.[rangeCodes], c.[MID], c.[CMSDate]
  /* 206-225*/
  UNION ALL
  SELECT g.[nameAllOTS], g.[rangeCodes],   c.[MID], c.[CMSDate], '206-225', SUM(c.[TransSum])
  /*SELECT c.[MID], c.[TransType], c.[CMSDate], SUM(c.[TransSum])*/
  FROM [PartnerPayment].[dbo].[CMS] as c
  LEFT JOIN  [PartnerPayment].[dbo].[GTRM] as g ON g.[MID] = c.[MID]
  WHERE c.[TransType] in ('206', '225') AND g.[nameAllOTS] is not null
  GROUP BY g.[nameAllOTS], g.[rangeCodes], c.[MID], c.[CMSDate]
