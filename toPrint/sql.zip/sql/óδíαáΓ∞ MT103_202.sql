/****** Script for SelectTopNRows command from SSMS  ******/
--���� �
DECLARE @datefrom DATETIME = '2017-01-10'; -- YYYY-DD-MM
--���� ��
DECLARE @dateto DATETIME = GETDATE();/*'2017-30-09'--  -- YYYY-DD-MM GETDATE()*/
--
DECLARE @strdate VARCHAR(8);
--���� �� ����
DECLARE @sDAY VARCHAR(2); 
---
DECLARE @DynamicSQL nvarchar(4000) ='';
--
DECLARE @myresult TABLE (cou int, typeMT varchar(255)/*, yesiban varchar(255)*/);
--����
while @datefrom <= @dateto
---
begin

set @strdate = convert(varchar(8), @datefrom, 112)

   DECLARE @tableMT103 VARCHAR(17) = concat('MT103',@strdate);
   DECLARE @tableMT202 VARCHAR(17) = concat('MT202',@strdate);
	--MT103
	IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Document' AND  TABLE_NAME = @tableMT103))
	BEGIN
	set @sDAY = convert(varchar(2),DAY(@datefrom))
	SET @DynamicSQL =N'SELECT Count(*), ''MT103'' FROM [webclient].[Document].[MT103'+ @strdate + '] as t ' 
	END
    --print @DynamicSQL
	INSERT INTO @myresult ([cou], [typeMT]) 
	EXECUTE sp_executesql @DynamicSQL
	SET @DynamicSQL=''
	--MT202
	IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Document' AND  TABLE_NAME = @tableMT202))
	BEGIN
	set @sDAY = convert(varchar(2),DAY(@datefrom))
	SET @DynamicSQL =N'SELECT Count(*), ''MT202'' FROM [webclient].[Document].[MT202'+ @strdate + '] as t ' 
	END
	INSERT INTO @myresult ([cou], [typeMT]) 
	EXECUTE sp_executesql @DynamicSQL
	SET @DynamicSQL=''
	--
	set @datefrom = DATEADD(DAY,1,@datefrom)
end
--print @DynamicSQL
	SELECT * FROM @myresult as r 
	--�������� �������
	PIVOT (SUM([cou]) FOR [typeMT] IN ([MT103], [MT202]))p
    --PIVOT (SUM([cou]) FOR [yesiban] IN ([������ ����], [IBAN]))p
