

	/****** Script for SelectTopNRows command from SSMS  ******/
/****** Script for SelectTopNRows command from SSMS  ******/
USE [webclient]
GO
   --���� �
DECLARE @datefrom DATETIME = '2018-01-01'; -- YYYY-DD-MM
--���� ��
DECLARE @dateto DATETIME = '2018-31-12'--GETDATE();--'2017-30-09'--  -- YYYY-DD-MM GETDATE()
--
DECLARE @strdate VARCHAR(8);
--���� �� ����
DECLARE @sDAY VARCHAR(2); 
---
DECLARE @DynamicSQL nvarchar(4000) ='';
--
DECLARE @myresult TABLE ([typeTT] varchar(max), [item1] varchar(max), [item2] varchar(max));
--����
while @datefrom <= @dateto
---
begin

set @strdate = convert(varchar(8), @datefrom, 112)

DECLARE @tableSt VARCHAR(17) = concat('txt',@strdate);

	IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Document' AND  TABLE_NAME = @tableSt))
	BEGIN
	set @sDAY = convert(varchar(2),DAY(@datefrom))
	--
	SET @DynamicSQL=N'SELECT td.[NameTemplate] 
	, c.[UNP]
	, count(*)
	FROM [webclient].[Document].[txt'+ @strdate + '] as t
	join [webclient].[Bank].[Customers] as c ON c.[id]=t.[ClientID] 
	join [webclient].[Referencies].[TemplateDocuments] as td On td.[ID] = t.[TemplateID]
	WHERE c.[Kanal] = 1
	GROUP BY td.[NameTemplate] , c.[UNP]'

	END
    --print @DynamicSQL
	INSERT INTO @myresult ([typeTT],[item1], [item2]) 
	EXECUTE sp_executesql @DynamicSQL
	SET @DynamicSQL=''
	---
set @datefrom = DATEADD(DAY,1,@datefrom)
end

select r.[typeTT], r.[item1], SUM(CAST(r.[item2] as int)) from @myresult as r
group by r.[typeTT], r.[item1]
order by r.typeTT
--pivot(count(r.[item1]) for r.[item1] in ([ONLINE], [OFFLINE])) p
