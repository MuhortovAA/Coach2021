SELECT TOP (1000) [ID]
      ,[Account]
      ,[ISO]
      ,[CustomersID]
      ,[prKazn]
      ,[prSAPDM]
      ,[AccountFiz]
      ,[Error]
      ,[BranchID]
      ,[TypeAccountID]
      ,[NameAccount]
      ,[UNP]
      ,[DefaultCashPooling]
      ,[AutoExtraction]
      ,[Destination]
      ,[AutoPayment]
      ,[IsoOld]
      ,[FlagNoOperation]
      ,[AccountIban]
      ,[CodeCustomerODB]
  FROM [webclient].[Bank].[AccountCustomers]
  WHERE [Account] like '%3012999000001%' 
  --WHERE [DefaultCashPooling] is null

	--	update [webclient].[Bank].[AccountCustomers]
	--	set [DefaultCashPooling] = '1'
	--WHERE [id] = 1239