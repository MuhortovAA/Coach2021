use [StatementAccount2019]
go

--���� �
--DECLARE @datefrom DATETIME = '2017-01-12'; -- YYYY-DD-MM
DECLARE @datefrom DATETIME = '2019-01-01' --GETDATE(); -- YYYY-DD-MM
--���� ��
--DECLARE @dateto DATETIME = '2017-31-12'; --GETDATE();--'2017-30-09'--  -- YYYY-DD-MM GETDATE()
DECLARE @dateto DATETIME =/*'2018-31-12'GETDATE()*/'2019-31-07'--  --'2018-31-12'--GETDATE();--''2018-31-01'; --GETDATE();--'2017-30-09'--  -- YYYY-DD-MM GETDATE()
--
DECLARE @strdate VARCHAR(8);
--���� �� ����
DECLARE @sDAY VARCHAR(2); 

DECLARE @sYEAR VARCHAR(4);
---
DECLARE @DynamicSQL nvarchar(4000) ='';
--
DECLARE @myresult TABLE (p1 varchar(max), p2 varchar(max), p3 varchar(max), p4 varchar(max));
--����
while @datefrom <= @dateto
---
begin
set @strdate = convert(varchar(8), @datefrom, 112)
DECLARE @tableSt VARCHAR(17) = concat('Statement',@strdate);

	IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'dbo' AND  TABLE_NAME = @tableSt))
	BEGIN
	set @sDAY = convert(varchar(2),DAY(@datefrom))
	set @sYEAR = convert(varchar(4),YEAR(@datefrom))
	SET @DynamicSQL =N' with myTable as (
	SELECT ''����� ������'' as mytype, ''1'' as myres, '+@strdate+' as mydate
	FROM [webclient].[Bank].[AccountCustomers] as a
	JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
	WHERE 
	--b.[TypeODB] = 2
	--AND 
	c.[bWork]=1 
	AND a.[prSAPDM] = 0 
	AND a.[AccountIban]!='''' 
	--AND b.[Filial] = ''612''
	--AND b.[CBY]=''524''
	AND a.[AccountIban] is not null 
    AND a.[DateCloseAccount] is null
    AND (a.[AccountIban] not like (''%AKBB38%'') OR a.[AccountIban] not like (''%AKBB2%'') )
	UNION ALL
	SELECT 
	CASE WHEN s.[AccountID] is NULL THEN ''��� �������'' ELSE ''� ��������'' END
	,''1'' 
	, '+@strdate+'
	FROM [StatementAccount'+@sYEAR+'].[dbo].['+@tableSt+'] as s
	RIGHT JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID] 
	RIGHT JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
	WHERE 
	b.[TypeODB] = 2
	AND c.[bWork] = 1
	--AND b.[Filial] = ''612''
	--AND b.[CBY]=''524''
	AND (a.[AccountIban] not like (''%AKBB38%'') OR a.[AccountIban] not like (''%AKBB2%''))
    AND a.[DateCloseAccount] is null)
	SELECT * FROM myTable as m
	PIVOT (COUNT([myres]) FOR [mytype] IN ([��� �������],[� ��������],[����� ������]))p'
		END
	    --print @DynamicSQL
	INSERT INTO @myresult ([p1],[p2],[p3],[p4]) 
	EXECUTE sp_executesql @DynamicSQL
	SET @DynamicSQL ='';

set @datefrom = DATEADD(DAY,1,@datefrom)
end
SELECT 
r.[p1] as '����' 
, r.[p2] as '��� �������'
, r.[p3] as '� ��������'
, r.[p4] as '����� ������'
FROM @myresult as r









--with myTable as (
--	SELECT '����� ������' as mytype, '1' as myres
--	FROM [webclient].[Bank].[AccountCustomers] as a
--	JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
--	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
--	WHERE 
--	b.[TypeODB] = 2
--	AND c.[bWork]=1 
--	AND a.[prSAPDM] = 0 
--	AND a.[AccountIban]!='' 
--	AND a.[AccountIban] is not null 
--    AND a.[DateCloseAccount] is null
--    AND (a.[AccountIban] not like ('%AKBB38%') OR a.[AccountIban] not like ('%AKBB2%') )
--	AND b.[Filial] = '510'
--	UNION ALL
--	SELECT 
--	CASE WHEN s.[AccountID] is NULL THEN '��� �������' ELSE '� ��������' END
--	,'1'
--	FROM [StatementAccount2018].[dbo].[Statement20181204] as s
--	RIGHT JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID] 
--	RIGHT JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
--	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
--	WHERE 
--	b.[TypeODB] = 2 
--	AND c.[bWork] = 1
--	AND b.[Filial] = '510'
--    AND a.[DateCloseAccount] is null)
--	SELECT * FROM myTable as m
--PIVOT (COUNT([myres]) FOR [mytype] IN ([��� �������],[� ��������],[����� ������]))p	
	
	
	
