select 
gc.[GroupID]
--g.[Name]
, COUNT(*) as 'count'

from [webclient].[Bank].[Customers] as c
JOIN webclient.Bank.Branches AS b ON c.IDFilial = b.ID
LEFT JOIN webclient.Access.GroupCustomer as gc ON gc.[CustomerID] = c.[id] AND gc.GroupID in ('5584')
--join [webclient].[Access].[Groups] as g ON g.[id]=gc.[GroupID]
where c.[bWork]=1
AND b.[CBY] in ('700','701','706','711','715','723','725','726','728','703','707','709','722','708','710','712','713','714','721','724','727') 
--AND gc.[GroupID] is null
group by gc.[GroupID]
--group by g.[Name]

--ORDER BY id asc

