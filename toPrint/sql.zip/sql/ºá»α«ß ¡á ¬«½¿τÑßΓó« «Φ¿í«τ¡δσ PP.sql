use webclient
go
DECLARE @datefrom DATETIME = '2017-01-08' ; -- YYYY-DD-MM --���� �
DECLARE @dateto DATETIME   = '2017-23-11' ;---/*GETDATE();*/'2017-30-09'--  -- YYYY-DD-MM GETDATE() --���� ��
DECLARE @strdate VARCHAR(8);
DECLARE @sDAY VARCHAR(2);  --���� �� ����
DECLARE @DynamicSQL nvarchar(4000) ='';
DECLARE @myresult TABLE ([datefind] varchar(17), [name] varchar(255), [datedoc] datetime, [numberdoc] varchar(100), [iso] varchar(3), sumdoc decimal(32,2));

WHILE @datefrom <= @dateto --����
BEGIN
  SET @strdate = convert(varchar(8), @datefrom, 112)
  DECLARE @tablePP VARCHAR(17) = concat('pp',@strdate);
  IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Document' AND TABLE_NAME = @tablePP))
  BEGIN
    SET @sDAY = convert(varchar(2),DAY(@datefrom))
    SET @DynamicSQL =N'SELECT ' + @strdate +', c.[name], t.[DateDocument], t.[NumberDocument], t.[ISOOfTransfer], t.[AmountOfTransfer]
	FROM [webclient].[Document].[pp'+ @strdate + '] as t
	join [webclient].[Bank].[Customers] as c on c.[id] = t.[CustomerID]
	where t.[BeneficiaryAccount] like ''%NBRB320%'' and t.[StepBank]=2 and t.[SubstBank] in (''2'',''15'')'
  END
  INSERT INTO @myresult ([datefind],[name],[datedoc],[numberdoc],[iso],[sumdoc])
  EXECUTE sp_executesql @DynamicSQL
  SET @DynamicSQL=''
  SET @datefrom = DATEADD(DAY,1,@datefrom)
END


SELECT * FROM @myresult as r  --print @DynamicSQL
--PIVOT (SUM([cou]) FOR [typeMT] IN ([MT103], [MT202], [afe]))p 	--�������� �������
