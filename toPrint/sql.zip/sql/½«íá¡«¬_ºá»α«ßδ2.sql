/****** Script for SelectTopNRows command from SSMS  ******/
SELECT DISTINCT TOP (1000) 
u.[login]+' '+u.[LastName]+' '+u.[FirstName]
, CASE OperationCode WHEN 53 THEN '��������' WHEN 51 THEN '����������' END
,day([WorkDT])
  FROM [webclient].[dbo].[Protokol202010] as p
  join [webclient].[Bank].[UsersBank] as u on u.[id]=p.[userid]

  where p.[TableOperation]=45 and p.[ClientID]=1167 and u.[Login]!='b00001174'
 -- order by [WorkDT] desc