	SELECT '�� ��������� ����' as '����', A.NumFil, A.NumCBY, A.NumOtd, A.total_s-B.sum_v as 'sum' FROM
	(SELECT t.[id], t.[NumFil], t.[NumCBY], t.[NumOtd], t.[total_s] FROM [webclient].[Document].[txt20171114] as t WHERE  t.[typedop] = 44) as A,
	(SELECT t.[OriginalDocumentId] , CAST(REPLACE(REPLACE(REPLACE(SUBSTRING(CONVERT (varchar(100),[BodyPartialCredited]), CHARINDEX('<total_s>', CONVERT (varchar(100),[BodyPartialCredited]))+9, CHARINDEX('<npp>', CONVERT (varchar(100),[BodyPartialCredited]))-CHARINDEX('<total_s>', CONVERT (varchar(100),[BodyPartialCredited]))-9), char(10), ''), char(13), ''), char(44), CHAR(46)) as decimal(32,2)) as 'sum_v' FROM [webclient].[Document].[txtpc201711] as t WHERE t.[OriginalDateDocument] = '2017-11-14') as B
	WHERE A.[id] = B.[OriginalDocumentId] AND (A.total_s-B.sum_v) > 0

	

	---SELECT t.[OriginalDocumentId] , CAST(REPLACE(REPLACE(REPLACE(SUBSTRING(CONVERT (varchar(100),[BodyPartialCredited]), CHARINDEX('<total_s>', CONVERT (varchar(100),[BodyPartialCredited]))+9, CHARINDEX('<npp>', CONVERT (varchar(100),[BodyPartialCredited]))-CHARINDEX('<total_s>', CONVERT (varchar(100),[BodyPartialCredited]))-9), char(10), ''), char(13), ''), char(44), CHAR(46)) as decimal(32,2)) as 'sum_v' FROM [webclient].[Document].[txtpc201711] as t WHERE t.[OriginalDateDocument] = '2017-11-14' 
	--GROUP BY t.[DocumentId],t.[CustomerId],t.[DateDocument],t.[OriginalDocumentId],t.[OriginalCustomerId],t.[OriginalDateDocument], CAST(REPLACE(REPLACE(REPLACE(SUBSTRING(CONVERT (varchar(100),[BodyPartialCredited]), CHARINDEX('<total_s>', CONVERT (varchar(100),[BodyPartialCredited]))+9, CHARINDEX('<npp>', CONVERT (varchar(100),[BodyPartialCredited]))-CHARINDEX('<total_s>', CONVERT (varchar(100),[BodyPartialCredited]))-9), char(10), ''), char(13), ''), char(44), CHAR(46)) as decimal(32,2))
	 
