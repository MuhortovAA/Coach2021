/****** Script for SelectTopNRows command from SSMS  ******/
use [webclient]
go

--���� �
--DECLARE @datefrom DATETIME = '2017-01-12'; -- YYYY-DD-MM
DECLARE @datefrom DATETIME = '2018-01-04'; -- YYYY-DD-MM
--���� ��
--DECLARE @dateto DATETIME = /*GETDATE();*/'2017-31-12'--  -- YYYY-DD-MM GETDATE()
DECLARE @dateto DATETIME = GETDATE();--*/'2018-31-01'--  -- YYYY-DD-MM GETDATE()
--
DECLARE @strdate VARCHAR(8);
--���� �� ����
DECLARE @sDAY VARCHAR(2); 
---
DECLARE @DynamicSQL nvarchar(4000) ='';
--
DECLARE @myresult TABLE (brname varchar(255), cusname varchar(255)/*cou int varchar(255)*/);
--����
while @datefrom <= @dateto
---
begin

set @strdate = convert(varchar(8), @datefrom, 112)

DECLARE @tableSt VARCHAR(17) = concat('txt',@strdate);
	----������ � ��������
		IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Document' AND  TABLE_NAME = @tableSt))
	BEGIN
	set @sDAY = convert(varchar(2),DAY(@datefrom))
	--������ �� ������������ �� ������� ������� 
	SET @DynamicSQL =N'with mytable as(SELECT distinct
	b.[BikIban]
	, c.[name]
	FROM [webclient].[Document].[txt'+ @strdate + '] as t
	JOIN [webclient].[Bank].[Customers] as c ON c.[id] = t.[ClientID]
	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
	where t.[typedop] in (''9'', ''14'') and t.[yesiban] = ''0'') 
	select br.[Name], m.[name] from mytable as m
	join (select * from [webclient].[Bank].[Branches] as b where len(b.[Otdelenie])=0 and len(b.[CBY])=0 ) as br ON m.BikIban = br.BikIban'
	END
    --print @DynamicSQL
	INSERT INTO @myresult ([brname],[cusname]) 
	EXECUTE sp_executesql @DynamicSQL
	--SET @DynamicSQL=''
set @datefrom = DATEADD(DAY,1,@datefrom)
end
--print @DynamicSQL
	--SELECT distinct r.[brname], r.[cusname] FROM @myresult as r 
	SELECT r.[brname], r.[cusname], COUNT(*) FROM @myresult as r 
	GROUP BY r.[brname], r.[cusname]
	--GROUP BY r.[brname]
	--�������� �������
--	PIVOT (SUM([cou]) FOR [regl] IN ([������], [������]))p
    --PIVOT (SUM([cou]) FOR [yesiban] IN ([������ ����], [IBAN]))p



--with mytable as(
--SELECT 
--   b.[BikIban]
--   ,COUNT(*) as 'cou'
--	FROM [webclient].[Document].[txt20171220] as t
--	JOIN [webclient].[Bank].[Customers] as c ON c.[id] = t.[ClientID]
--	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
--	where t.[typedop] in ('9', '14') and t.[regl] = '0' and t.[YesIban] = '0'
--	group by b.[BikIban])
--select br.[Name], m.cou from mytable as m
--join (select * from [webclient].[Bank].[Branches] as b where len(b.[Otdelenie])=0 and len(b.[CBY])=0 ) as br ON m.BikIban = br.BikIban
