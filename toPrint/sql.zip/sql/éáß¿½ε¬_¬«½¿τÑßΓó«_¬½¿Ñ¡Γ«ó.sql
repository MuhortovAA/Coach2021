
SELECT        
 Access.Groups.Name AS NameGroup
, Branches_1.Filial AS filialcustomer
, Branches_1.CBY AS cbycustomer
, count(*) as '���������� ��������'
, CASE Bank.Customers.prCentr WHEN '0' THEN '���' WHEN '1' THEN '��' ELSE '���' END as 'aaa'

FROM            Access.GroupCustomer INNER JOIN
                         Bank.Customers ON Access.GroupCustomer.CustomerID = Bank.Customers.id INNER JOIN
                         Access.Groups ON Access.GroupCustomer.GroupID = Access.Groups.ID INNER JOIN
                         Bank.Branches ON Access.Groups.BranchID = Bank.Branches.ID INNER JOIN
                         Bank.Branches AS Branches_1 ON Bank.Customers.IDFilial = Branches_1.ID
						 where 
						 [access].[groups].[id]=5872
						 --[Access].[Groups].[Name] like '%�������� �� (��� 214%'
						 
						 --AND Branches_1.cby in ('605','606','611','624','625','626','672')
						 --and Access.GroupCustomer.GroupID = '4785'
GROUP BY 
Access.Groups.Name 
, Branches_1.Filial 
, Branches_1.CBY 
, CASE Bank.Customers.prCentr WHEN '0' THEN '���' WHEN '1' THEN '��' ELSE '���' END

