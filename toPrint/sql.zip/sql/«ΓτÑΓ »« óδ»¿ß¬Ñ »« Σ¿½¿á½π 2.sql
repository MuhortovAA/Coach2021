 SELECT 
 
 b.[Filial], b.[Mfo], count(*) as '���'
 FROM [StatementAccount2017].[dbo].[Statement20170711] as s /*YYYYMMDD*/
 JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID]
 JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
 JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
 WHERE DAY(s.[QueryDateTime]) = 10 AND a.[prSAPDM] = 0
 AND c.[Kanal] = 1 AND c.[bWork]=1 --AND b.[TypeODB] = 2 --AND b.[Filial] not in ('529','400','703','200' )
 GROUP BY  b.[Mfo], b.[Filial]
 --HAVING  Count(*)<500
 
 --ORDER BY s.[QueryDateTime] desc
  SELECT 
    b.[Filial], b.[Mfo], c.[idcl],c.[name], a.AccountIban, a.prSAPDM, s.QueryDateTime
 FROM [StatementAccount2017].[dbo].[Statement20170704] as s /*YYYYMMDD*/
 JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID]
 JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
 JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID]
 WHERE DAY(s.[QueryDateTime]) = 4 AND a.[prSAPDM] = 0
 AND c.[Kanal] = 1 AND c.[bWork]=1 --AND b.[TypeODB] = 2 AND b.[Filial]='529' 
 --GROUP BY  b.[Mfo], b.[Filial]