
SELECT * FROM (	SELECT * FROM [webclient].[Document].[pp20170401] as pp WHERE	(DATEPART(Hour, pp.[DateWorkCustomer]) <= 15) AND (pp.[DateWorkBank] is not null) ) as pp		
		 WHERE pp.[PayerAccount] like '3011%' 
		 OR pp.[PayerAccount] like '3012%' 
		 OR pp.[PayerAccount] like '3013%'   
		 OR pp.[PayerAccount] like '3015%' 
		 OR pp.[PayerAccount] like '3632%' 
		 OR pp.[BeneficiaryAccount] not like '10%' 
		 OR pp.[BeneficiaryAccount] not like '36%' 
		 OR pp.[BeneficiaryAccount] not like '38%' 	



SELECT  *
	--'�� 15' as mytime 
	--, DATEPART(DAY, pp.[DateWorkCustomer]) as dwc 
	--, Count(*) as mycount 
	FROM [webclient].[Document].[pp20170401] as pp 
	WHERE 
	(DATEPART(Hour, pp.[DateWorkCustomer]) <= 15) AND (pp.[DateWorkBank] is not null)  
	AND
	--AND pp.[PayerAccount] like '3011%' 
      pp.[PayerAccount] like '3012%' 
	 pp.[PayerAccount] like '3013%'   
	--OR pp.[PayerAccount] like '3015%' 
	--OR pp.[PayerAccount] like '3632%' 
	--OR pp.[BeneficiaryAccount] not like '10%' 
	--OR pp.[BeneficiaryAccount] not like '36%' 
	--OR pp.[BeneficiaryAccount] not like '38%'  
	--GROUP BY DATEPART(DAY, pp.[DateWorkCustomer])