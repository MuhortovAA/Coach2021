
SELECT        

 g.[Name] AS NameGroup

, Branches_1.Filial AS filialcustomer
, Branches_1.CBY AS cbycustomer
, COUNT(*) as 'count'
FROM [webclient].[Access].[GroupCustomer] as gc
INNER JOIN [webclient].[Bank].[Customers] as c ON gc.[CustomerID] = c.[id] 
INNER JOIN [webclient].[Access].[Groups] as g ON gc.[GroupID] = g.[ID] 
INNER JOIN [webclient].[Bank].[Branches] as b2 ON g.[BranchID] = b2.[ID]
INNER JOIN [webclient].[Bank].[Branches] AS Branches_1 ON c.[IDFilial] = Branches_1.ID
where 
g.[ID]='4817'

GROUP BY
g.[Name]
, Branches_1.Filial
, Branches_1.CBY
ORDER BY 
 Branches_1.Filial
, Branches_1.CBY


