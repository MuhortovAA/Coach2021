SELECT       
distinct 
g.[ID]
, g.[Name] AS NameGroup
, g.[BranchID]
FROM [webclient].[Access].[Groups] as g 
join [webclient].[Bank].[Branches] as b On b.[id]=g.[BranchID]
where 
g.[prCustomer]='1' 
and g.[Name] like '%���������%'
ORDER BY g.[Name] 

