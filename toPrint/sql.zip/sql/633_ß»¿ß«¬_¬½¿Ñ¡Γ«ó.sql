
select c.[CustomerID], cus.[name], cus.[IDFilial] from (
select b.CustomerID from (
				SELECT    
					gc.CustomerID
				FROM [webclient].[Access].[Groups] as g 
				join [webclient].[Bank].[Branches] as b On b.[id]=g.[BranchID]
				join [webclient].[Access].[GroupCustomer] as gc ON gc.[GroupID]=g.[ID]
				where b.Filial='633' and g.[id]='4866'
				) as a
				right join 
					(SELECT distinct
					gc.CustomerID
					FROM [webclient].[Access].[Groups] as g 
					join [webclient].[Bank].[Branches] as b On b.[id]=g.[BranchID]
					join [webclient].[Access].[GroupCustomer] as gc ON gc.[GroupID]=g.[ID]
					where b.Filial='633' and g.[id] in ('15','3188','3189','499','3370','3190','4171','4267','4071','4075','4212','2029','1371','1918','1536','1194')
					) as b ON a.[CustomerID]=b.[CustomerID]

					where a.[CustomerID] is null
					) as c
					join [webclient].[Bank].[Customers] as cus ON c.[CustomerID]=cus.[id]


--select * from [webclient].[Access].[GroupCustomer]

--insert into [webclient].[Access].[GroupCustomer] ([GroupID], [CustomerID]) 
--values ('4866','102249'),('4866','102274'),('4866','102287')
