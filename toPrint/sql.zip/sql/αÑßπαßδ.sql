SELECT db_name(l.resource_database_id) db, COUNT(*) quantity 
FROM sys.dm_tran_locks l 
GROUP BY db_name(l.resource_database_id) 
ORDER BY 1
