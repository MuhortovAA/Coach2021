update [webclient].[Bank].[Customers]
set [CodeCustomerOdbScOracle] = ( select myc.[elclientid] 
									FROM [webclient].[dbo].[myCustomersGO] as myc
								where [codecustomerodb] = myc.[old_id] and myc.[filialmfo] like '%510'
								)
			where [IDFilial]='1196'

	select myc.[elclientid] 
	FROM [webclient].[dbo].[myCustomersGO] as myc
	where  myc.[filialmfo] like '%510'

	select * FROM [webclient].[Bank].[Customers]
	where [IDFilial]='1196'

SELECT 
[idcl],[bWork],c.[codecustomerodb],c.[CodeCustomerOdbScOracle], a.[AccountIban]
  FROM [webclient].[Bank].[Customers] as c
  join [webclient].[Bank].[Branches] as b ON b.[id] = c.[idfilial]
  left join [webclient].[Bank].[AccountCustomers] as a ON a.[CustomersID] = c.[id]
  where b.[CBY]='510'

--  USE [webclient]
--GO

--/****** Object:  Table [dbo].[myCustomers510]    Script Date: 09.03.2019 9:13:25 ******/
--SET ANSI_NULLS ON
--GO

--SET QUOTED_IDENTIFIER ON
--GO

--CREATE TABLE [dbo].[myCustomers510](
--	[ID] [nvarchar](max) NULL,
--	[Name] [nvarchar](max) NULL,
--	[DOS_ID] [nvarchar](max) NULL,
--	[NEWID] [nvarchar](max) NULL
--) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
--GO


