SELECT TOP(100)
*
FROM [webclient].[Bank].[OutputSendOnline_bk]

SELECT 
COUNT(*)
FROM [webclient].[Bank].[OutputSendOnline]

