with mytable as(
SELECT        

 g.[Name] AS NameGroup

--, Branches_1.Filial AS filial
--, Branches_1.CBY AS cby
,c.[id]
,c.[idcl]

FROM [webclient].[Access].[GroupCustomer] as gc
INNER JOIN [webclient].[Bank].[Customers] as c ON gc.[CustomerID] = c.[id] 
INNER JOIN [webclient].[Access].[Groups] as g ON gc.[GroupID] = g.[ID] 
INNER JOIN [webclient].[Bank].[Branches] as b2 ON g.[BranchID] = b2.[ID]
INNER JOIN [webclient].[Bank].[Branches] AS Branches_1 ON c.[IDFilial] = Branches_1.ID
where g.[ID] in ('5584','5580','4815','4817','5579','5578','5577','5576')
AND c.[bWork]=0

)
SELECT * FROM mytable as m


