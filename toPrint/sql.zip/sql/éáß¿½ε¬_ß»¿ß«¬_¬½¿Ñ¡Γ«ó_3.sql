select 
 gr.idcl
 , gr.[name]
 , g2.[Name]
FROM [webclient].[Access].[GroupCustomer] as gc2
join (
		SELECT 
			c.[id], c.[idcl], c.[name]
		FROM [webclient].[Access].[GroupCustomer] as gc
		INNER JOIN [webclient].[Bank].[Customers] as c ON gc.[CustomerID] = c.[id] 
		INNER JOIN [webclient].[Access].[Groups] as g ON gc.[GroupID] = g.[ID] 
		where 
		g.[PrEnrollmentLists]='1' 
		and g.[prCustomer]='1' 
		and g.[BranchID]='1167'
		and 
		--g.[ID]='16'
		g.[ID]='35'
) AS gr on gr.id=gc2.CustomerID
INNER JOIN [webclient].[Access].[Groups] as g2 ON gc2.[GroupID] = g2.[ID] 
		where 
		g2.[PrEnrollmentLists]='1' 
		and g2.[prCustomer]='1' 
		and g2.[BranchID]='1167'
--GROUP BY gr.[idcl], gr.[name]
ORDER BY  gr.idcl
 , gr.[name]
