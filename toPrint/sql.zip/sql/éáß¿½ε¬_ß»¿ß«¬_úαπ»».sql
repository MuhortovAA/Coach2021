SELECT       
distinct 
g.[ID]
, g.[Name] AS NameGroup
, g.[BranchID]
,b.[name]
FROM [webclient].[Access].[Groups] as g 
join [webclient].[Bank].[Branches] as b On b.[id]=g.[BranchID]
where 
g.[PrEnrollmentLists]='1' 
and 
g.[prCustomer]='1' 
--and 
--g.[ID]=60
--b.[cby]='100'
--and b.[Filial]='302'
and g.[BranchID]='1167'
--and g.[Name] like '%312%'
--where g.[Name] like '%�� 1%'
--ORDER BY g.[Name] 

--select * from [webclient].[Access].[Groups]

--update [webclient].[Access].[Groups]
--set [BranchID]='1167'
--where id='286'



