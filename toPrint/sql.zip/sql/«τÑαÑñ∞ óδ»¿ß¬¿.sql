---������� ������� ������� ��������� �������������� � ��������
update [webclient].[Bank].[BalanceAccount]
set [QueryTimeStatement] = null, [QueryStatement] = 0
WHERE [AccountID] in (SELECT [AccountID]
FROM [webclient].[Bank].[BalanceAccount] as b
JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = b.[AccountID]
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
JOIN [webclient].[Bank].[Branches] as br ON br.[id] = c.[IDFilial]
WHERE 
--br.CBY='500' 
--SUBSTRING(br.[Mfo], 7, 3)='246'
br.Filial='312' --AND c.[idcl] = 'w7dy'
)
-- ������� ������� �� ����� SC
UPDATE [webclient].[Bank].[RequestsSC]  
SET [Completed] =1
WHERE [QueryID] IN (
SELECT [QueryID]
FROM [webclient].[Bank].[RequestsSC] as r
JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[AccountIban] = r.[Account]
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
JOIN [webclient].[Bank].[Branches] as br ON br.[id] = c.[IDFilial]
WHERE 
--br.CBY='500' 
--SUBSTRING(br.[Mfo], 7, 3)='246'
br.[Filial] = '312'
--r.[MFO] = '660'
--c.[idcl] = 'w7dy' --r.[MFO] = '661' AND r.[Completed]=0 --AND DAY(r.[DateFirst])=27
)

UPDATE [webclient].[Bank].[RequestsSCOracle]  
SET [Completed] =1
WHERE [QueryID] IN (
SELECT [QueryID]
FROM [webclient].[Bank].[RequestsSCOracle] as r
JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[AccountIban] = r.[Account]
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
JOIN [webclient].[Bank].[Branches] as br ON br.[id] = c.[IDFilial]
WHERE [Completed] =0
)

UPDATE [webclient].[Bank].[RequestsSAP]  
SET [Completed] =1
WHERE [QueryID] IN (
SELECT [QueryID]
FROM [webclient].[Bank].[RequestsSAP] as r
JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[AccountIban] = r.[Account]
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
JOIN [webclient].[Bank].[Branches] as br ON br.[id] = c.[IDFilial]
WHERE [Completed] =0 
--and br.CBY='511'
--br.[Filial] = '500'
--r.[MFO] = '660'
--c.[idcl] = 'w7dy' --r.[MFO] = '661' AND r.[Completed]=0 --AND DAY(r.[DateFirst])=27
)


-- ������� ������� �� ����� SAP
--UPDATE [webclient].[Bank].[RequestsSap] 
--SET [Completed] =1
--SELECT count(*)
--FROM [webclient].[Bank].[RequestsSap] as r
--WHERE r.[Completed] =0


--SELECT 

--r.[MFO], c.[idcl], COUNT(*)
--FROM [webclient].[Bank].[RequestsSC] as r
--JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[AccountIban] = r.[Account]
--JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
--JOIN [webclient].[Bank].[Branches] as br ON br.[id] = c.[IDFilial]
--WHERE r.[MFO] = '752' /*AND c.[idcl] in ('w04o') */AND r.[Completed]=0
--GROUP BY r.[MFO], c.[idcl]
--ORDER BY COUNT(*) DESC

--SELECT *
--FROM [webclient].[Bank].[BalanceAccount] as b
--JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = b.[AccountID]
--JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
--JOIN [webclient].[Bank].[Branches] as br ON br.[id] = c.[IDFilial]
--WHERE br.[Filial] = '500'
--c.[idcl] = 'W048'
----br.[Filial] = '500'



