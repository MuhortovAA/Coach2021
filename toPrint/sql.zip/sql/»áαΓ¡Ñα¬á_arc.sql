USE [PartnerPayment]
GO

INSERT INTO [dbo].[CMSNewArc2018]([Card],[TransDateTime],[CMSDate],[TransVal],[TransSum],[AccountVal],[AccountSum],[TransType],[TransName],[MID],[TID],[MCC],[Field98],[POSCode],[OTSName],[EventArea],[Filial],[CBU],[AccountInCMS],[AccountInScCard],[InternalNo],[FIO])
SELECT [Card]
      ,[TransDateTime]
      ,[CMSDate]
      ,[TransVal]
      ,[TransSum]
      ,[AccountVal]
      ,[AccountSum]
      ,[TransType]
      ,[TransName]
      ,[MID]
      ,[TID]
      ,[MCC]
      ,[Field98]
      ,[POSCode]
      ,[OTSName]
      ,[EventArea]
      ,[Filial]
      ,[CBU]
      ,[AccountInCMS]
      ,[AccountInScCard]
      ,[InternalNo]
      ,[FIO]
  FROM [PartnerPayment].[dbo].[CMSNew] as c
  WHERE year(c.[CMSDate]) = '2018' and MONTH(c.[CMSDate])='12'


