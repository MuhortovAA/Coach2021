select
ROW_NUMBER() OVER (ORDER BY b.[Name] ASC) AS Row
, c.[name]
, c.[UNP]
, b.[Name]
, c.[FIOBoss]
, c.[Phones]
, c.[DateOn]
from [webclient].[Bank].[Customers] as c
join [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
where c.[DateOn] BETWEEN '01.05.2019' and '31.07.2019' and c.[bWork]='1'
