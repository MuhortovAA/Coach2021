SELECT * FROM sys.dm_exec_requests
