    SELECT        
	b.[Login] as [loginuser]
	, b.[LastName]+' '+b.[FirstName] + ' '+ b.[MiddleName] as un
	, r.[Name]
	, b.[bWork]
	, br.[Name] AS brname
	, '����' AS cl
	, b.[OrgunitCode]
	--count(*)
	, br.[OrgSapId]
    FROM            [webclient].[Referencies].[roli] as r 
	LEFT JOIN [webclient].[Bank].[UserRoli] ur ON r.[id] = ur.[CodeRoliID]
	LEFT JOIN [webclient].[Bank].[UsersBank] b ON ur.[UserBankID] = b.[id]
	LEFT JOIN [webclient].[Bank].[Branches] AS br ON b.[ClientID] = br.[ID] 
	LEFT JOIN [webclient].[Access].[Arm] AS a ON r.[CodeARM] = a.[id]
	where r.[Name] like '%������%' --and br.Filial in ('633') /*and br.CBY in ('632')*/
	and b.[OrgunitCode] is null 
	and br.[OrgSapId] is not null 
	and b.bWork =1 and br.Name not like '%�������%'
	--group by br.[OrgSapId]
	--order by count(*) desc

	update [webclient].[Bank].[UsersBank]
	set OrgunitCode='50008258'
	where id in
	(
	    SELECT        
	b.id
    FROM            [Referencies].[roli] as r 
	LEFT JOIN [webclient].[Bank].[UserRoli] ur ON r.[id] = ur.[CodeRoliID]
	LEFT JOIN [webclient].[Bank].[UsersBank] b ON ur.[UserBankID] = b.[id]
	LEFT JOIN [Bank].[Branches] AS br ON b.[ClientID] = br.[ID] 
	LEFT JOIN [Access].[Arm] AS a ON r.[CodeARM] = a.[id]
	where r.[Name] like '%������%' --and br.Filial in ('633')
	and b.[OrgunitCode] is null and b.bWork =1 and br.Name not like '%�������%'
	and br.OrgSapId='50008258'
	)



