/****** Script for SelectTopNRows command from SSMS  ******/

with mytable as (
SELECT 
    day(p.[WorkDT]) as 'day'
	, DATEPART(HOUR, p.[WorkDT]) as 'timer'
	, COUNT(c.[idcl]) as 'sum'
  FROM [webclient].[dbo].[Protokol202002] as p
  join [webclient].[Bank].[Customers] as c on c.[id]=p.[ClientID]
  join [webclient].[Bank].[UsersBank] as u on u.[id]=p.[UserID]
  join [webclient].[dbo].[MessageProtocol] as m on m.[id]=p.[OperationCode]
  where p.[TypeArm]=1 
  AND p.[TypeDoc]=5  /*���*/
  AND p.[OperationCode]=57 /*�������� � ����*/
  AND day(p.[WorkDT]) ='28' --and DATEPART(HOUR, p.[WorkDT]) >= '16' 
  --and u.[login]='b00001658'
GROUP BY day(p.[WorkDT]), p.[WorkDT], DATEPART(HOUR, p.[WorkDT]) 
) 
SELECT * FROM mytable as m
PIVOT (COUNT([sum]) FOR [timer] IN ([01],[02],[03],[04],[05],[06],[07],[08],[09],[10],[11],[12],[13],[14],[15],[16],[17],[18],[19],[20],[21],[22],[23]))p
