SELECT    
	g.[ID]
	, g.[Name]

FROM [webclient].[Access].[Groups] as g 
join [webclient].[Bank].[Branches] as b On b.[id]=g.[BranchID]

where b.Filial='633' and prCustomer=1 
--and g.[id]='4866' 
ORDER BY g.[Name]



--update [webclient].[Access].[Groups]
--set BranchID='1687'
--where id='4866'
--select * from [webclient].[Access].[Groups]

