SELECT '����� ������', COUNT(*)
	FROM [webclient].[Bank].[AccountCustomers] as a
	JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
	WHERE 
	b.[TypeODB] = 2
	AND c.[bWork]=1 
	AND a.[prSAPDM] = 0 
	AND a.[AccountIban]!='' 
	AND a.[AccountIban] is not null 
    AND a.[DateCloseAccount] is null
    AND (a.[AccountIban] not like ('%AKBB38%') OR a.[AccountIban] not like ('%AKBB2%') )
	AND b.[Filial] = '510'
	--AND c.[idcl] = 'BG05'

	SELECT 
	'� ��������'
	,b.[TypeODB]
	, c.[bWork]
	, count(*)
	FROM [StatementAccount2018].[dbo].[Statement20181204] as s
	LEFT JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID] 
	LEFT JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
	LEFT JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
	WHERE 
	--c.[Kanal] = 2 
	b.[TypeODB] = 2 
	AND c.[bWork] = 1
	AND b.[Filial] = '510'
		--AND a.[prSAPDM] = 0 
	--AND a.[AccountIban]!='' 
	--AND a.[AccountIban] is not null 
    AND a.[DateCloseAccount] is null
	--AND c.[idcl] = 'BG05'
	GROUP BY b.[TypeODB], c.[bWork]
	ORDER BY b.[TypeODB]
	
	--select COUNT (*) from [StatementAccount2019].[dbo].[Statement20190102]


		SELECT 
	'��� �������'
	,b.[TypeODB]
	, c.[bWork]
	, count(*)
	FROM [StatementAccount2018].[dbo].[Statement20181204] as s
	RIGHT JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID] 
	RIGHT JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
	WHERE 
	s.[AccountID] is null
	--c.[Kanal] = 2 
	AND b.[TypeODB] = 2 
	AND c.[bWork] = 1
	AND b.[Filial] = '510'
		--AND a.[prSAPDM] = 0 
	--AND a.[AccountIban]!='' 
	--AND a.[AccountIban] is not null 
    AND a.[DateCloseAccount] is null
	GROUP BY b.[TypeODB], c.[bWork]
	ORDER BY b.[TypeODB]

			SELECT 
	--'���������� ������ � ��������'
	
c.[idcl]
	FROM [StatementAccount2019].[dbo].[Statement20190116] as s
	RIGHT JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID] 
	RIGHT JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
	WHERE 
	s.[AccountID] is null
	--c.[Kanal] = 2 
	AND b.[TypeODB] = 2 
	AND c.[bWork] = 1
	AND b.[Filial] = '510'
		--AND a.[prSAPDM] = 0 
	--AND a.[AccountIban]!='' 
	--AND a.[AccountIban] is not null 
    AND a.[DateCloseAccount] is null
	GROUP BY c.[idcl]
	ORDER BY c.[idcl]

	select * FROM
	(
			SELECT 
			a.[AccountIban]
	--'��� �������'
	--,b.[TypeODB]
	--, c.[bWork]
	--, a.[AccountIban]
	FROM [StatementAccount2019].[dbo].[Statement20190116] as s
	RIGHT JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID] 
	RIGHT JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID] 
	JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = a.[BranchID] 
	WHERE 
	s.[AccountID] is null
	AND c.[bWork] = 1
	AND b.[Filial] = '510'
	AND a.[prSAPDM] = 0 
	AND a.[AccountIban]!='' 
	AND a.[AccountIban] is not null 
	--AND (a.[AccountIban] not like ('%AKBB2%') OR a.[AccountIban] not like ('BY83AKBB38%') )
	AND a.[AccountIban] not like ('%AKBB2%') 
	--AND a.[AccountIban] not like ('BY83AKBB38%') 
    AND a.[DateCloseAccount] is null
	) as a 
	
	
	
