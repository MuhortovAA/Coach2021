 UPDATE [StatementAccount2017].[dbo].[Statement20170630]/*YYYYMMDD*/
 SET [QueryDateTime] = '2017-30-06'/*YYYY-DD-MM*/
 WHERE [AccountID] in (
 SELECT [AccountID]
 FROM [StatementAccount2017].[dbo].[Statement20170711] as s
 JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID]
 JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
 JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
  WHERE c.[Kanal] = '1' --AND b.[Filial] = '317'
 --WHERE c.[idcl] IN ('ZIVH')
 )

 --webclient.[Bank].[CP866ToNVarChar](s.BodyStatementAccount)
 SELECT 
 *
--webclient.[Bank].[CP866ToNVarChar](s.BodyStatementAccount)
--Count(*)
 FROM [StatementAccount2017].[dbo].[Statement20170704] as s /*YYYYMMDD*/
 JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID]
 JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
 JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
 --WHERE /*c.[Kanal] = '1' AND */ ---b.[Filial] = '000' AND DAY(s.[QueryDateTime])=12  --AND c.[idcl]='T001' 
 --WHERE c.[Kanal] = '1' AND b.[Mfo] = '795'
 --WHERE c.[idcl] IN ('W0A1') /*AND a.[prSAPDM]=1*/

 --
 --SELECT GETDATE()-1
 --SELECT 
	-- DAY(s.[QueryDateTime])+'-'+MONTH(s.[QueryDateTime]+'-'+YEAR(s.[QueryDateTime])
	-- , b.[Filial] 
 --FROM [StatementAccount2017].[dbo].[Statement20170707] as s
 --JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[ID] = s.[AccountID]
 --JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
 --JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
 ----WHERE c.[idcl] = 'WEGO'
 --WHERE b.[Filial] = '300'

