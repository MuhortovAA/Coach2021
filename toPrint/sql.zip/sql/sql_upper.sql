update [webclient].[Bank].[Customers]
set [name] = UPPER([name]), [namecustomereng]=upper([namecustomereng]),[namecustomerlatin]=upper([namecustomerlatin])  /*LOWER([name])*/
select top(1)
id 
from [webclient].[Bank].[Customers] as c

select 
c.[name]
, c.[namecustomereng]
, c.[namecustomerlatin]
 from [webclient].[Bank].[Customers] as c