--with mytable as (
--SELECT

--t.[NumFil], t.[NumCBY], t.[NumOtd]
--, t.[VSP] as 'vsp'
--, t.[total_s] as 'total_s'
--FROM [webclient].[Document].[txt20171116] as t
--WHERE t.[typedop] = 44 ) 
--SELECT * FROM mytable as t
--PIVOT (SUM([total_s]) FOR [VSP] IN ([K], [V])) p

SELECT
t.[NumFil], t.[NumCBY], t.[NumOtd],t.[total_s]

,CASE t.[VSP] WHEN 'K' THEN 'R0481' WHEN 'V' THEN 'R0480' END as '��� ����������'
--, SUM(t.[total_s]) as '�����'
--SELECT *
FROM [webclient].[Document].[txt20171116] as t
WHERE t.NZP like '%������%'
--WHERE  t.[typedop] = 44
--GROUP BY t.[NumFil], t.[NumCBY], t.[NumOtd], t.[VSP]