SELECT 
		--CASE cast(c.[CBU] as nvarchar(max)) when '0' then cast(c.[filial] as nvarchar(max)) else cast(c.[filial] as nvarchar(max)) +cast('/' as nvarchar(max))+cast(c.[CBU] as nvarchar(max)) end,
				g.[filialSupport], 
					(
						case c.[TransType] 
							when 205 then isnull(c.[TransSum],0)
							when 206 then -1*isnull(c.[TransSum],0)
							when 225 then -1*isnull(c.[TransSum],0) end)*[procentCashBack]/100 as SumCashBack,
		CASE a.[need] WHEN '547087400' then '������' else '������ ���' END
		, c.[CMSDate]
		, c.[TransDateTime]
		, c.[TransSum]
		,c.[Card]
		,c.[MID] as cms_mid
		,g.[MID] as g_mid
		,g.[unn]
		,g.[nameOTS]
		, g.[procentCashBack]
		--Round((ISNULL(c.TransSum,0))*[procentNonAcq]/100,2)	
		--Round((ISNULL(c.TransSum,0))*[procentCashBack]/100,2)	
FROM CMSNew c WITH(INDEX(IX_MT))
  --LEFT OUTER JOIN GTRM g ON c.MID = g.MID AND g.acquiring = 0
  JOIN GTRM g ON c.MID = g.MID AND g.acquiring = 1 --AND g.[unn]='690309146' AND g.[MID]='1674497101'
    JOIN (SELECT B.need FROM (values 
						--('547087400') /*������*/
					  	('671176001')
					  , ('671129001')
					  , ('553608001')
					  , ('547091002')
					  , ('425520030')
					  , ('671177001')
					  , ('547087004')
					  , ('547087404')
					  , ('671129004')
					  , ('484894007')
					  ) B(need)) a ON  g.[rangeCodes] like '%'+a.need+'%' and c.[Card] like '%'+a.need+'%'
  --JOIN (SELECT B.need FROM (values 
		--				('547087400') /*������*/
		--			  ,	('671176001')
		--			  , ('671129001')
		--			  , ('553608001')
		--			  , ('547091002')
		--			  , ('425520030')
		--			  , ('671177001')
		--			  , ('547087004')
		--			  , ('547087404')
		--			  , ('671129004')
		--			  , ('484894007')
		--			  --) B(need)) a ON  a.need like '%'+SUBSTRING(g.[rangeCodes], 1, 9)+'%'
		--			  ) B(need)) a2 ON g.[rangeCodes]  like '%'+a2.[need]+'%'
  WHERE    
		 c.CMSDate Between '2019-06-29' and '2019-07-31'
		AND (c.[TransType] IN (205, 226, 206, 225))
		AND  g.id IS NOT NULL	
			--AND g.[rangeCodes] like '%'+SUBSTRING(c.[Card], 1, 9)+'%'
			--AND g.[rangeCodes] not in ('547087400')
		AND  c.[TransDateTime]>=g.[dateStartCredit]  
		AND (g.[dateFinishCredit] is null OR c.[TransDateTime] < g.[dateFinishCredit]) 
		AND g.[unn]='691536217'
		
		--AND g.[unn]='690309146'
		--AND g.[MID]='0900469'
		--AND (CASE cast(c.[CBU] as nvarchar(max)) when '0' then cast(c.[filial] as nvarchar(max)) else cast(c.[filial] as nvarchar(max)) +cast('/' as nvarchar(max))+cast(c.[CBU] as nvarchar(max)) end)='100'

		--GROUP BY CASE cast(c.[CBU] as nvarchar(max)) when '0' then cast(c.[filial] as nvarchar(max)) else cast(c.[filial] as nvarchar(max)) +cast('/' as nvarchar(max))+cast(c.[CBU] as nvarchar(max)) end, a.[need], [procentCashBack]
		ORDER BY 
		--c.[TransSum]
		CASE cast(c.[CBU] as nvarchar(max)) when '0' then cast(c.[filial] as nvarchar(max)) else cast(c.[filial] as nvarchar(max)) +cast('/' as nvarchar(max))+cast(c.[CBU] as nvarchar(max)) end
