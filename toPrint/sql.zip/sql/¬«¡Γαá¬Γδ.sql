--SELECT * FROM [webclient].[Referencies].[ContractBranch]
TRUNCATE TABLE [webclient].[Referencies].[ContractBranch]