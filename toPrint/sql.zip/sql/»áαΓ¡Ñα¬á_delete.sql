delete 
from [PartnerPayment].[dbo].[CMSNew] 
where month([CMSDate]) = '12' AND Year([CMSDate]) = '2018'