USE [webclient]
GO
EXEC [webclient].[dbo].[Dynamic_SP] '20170303'

--SELECT convert(datetime, '20161023', 112)
--print CONVERT(VARCHAR(10),DATETIME(),112)
--print convert(datetime, '20161023', 12)
--SELECT CONVERT(VARCHAR(10), GETDATE(), 112) AS [YYYYMMDD]
--print CONVERT(VARCHAR(10), GETDATE(), 112)