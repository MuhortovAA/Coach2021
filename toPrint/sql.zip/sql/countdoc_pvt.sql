WITH mytable as(
				SELECT c.[name] as cname , 1 as [countdoca] , 'TXT' as [tdoca] FROM [webclient].[Document].[txt20170131] AS txt RIGHT JOIN [webclient].[Bank].[Customers] AS c ON txt.[ClientID] = c.[id] 
				UNION ALL
				SELECT c.[name] as cname , 1 as [countdoca] , 'PP' as [tdoca] FROM [Document].pp20170131 AS txt RIGHT JOIN [webclient].[Bank].[Customers] AS c ON txt.[CustomerID] = c.[id]
				)
	SELECT * FROM mytable
	--RIGHT JOIN [webclient].[Bank].[Customers] AS c ON txt.[ClientID] = c.[id] 
--	JOIN [Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
	--where (c.bWork = 1)
	PIVOT (COUNT([countdoca]) FOR [tdoca] IN ([TXT], [PP])) as pvt
	ORDER BY [TXT] desc