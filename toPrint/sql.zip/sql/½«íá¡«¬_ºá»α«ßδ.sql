/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [AccountID]
      ,[QueryDateTime]
      ,[BodyStatementAccount]
      ,[BodyStatementAccountAddition]
  FROM [StatementAccount2020].[dbo].[Statement20201002] as s
  join [webclient].[Bank].[accountcustomers] as a on a.[id]=s.[AccountID]
  join [webclient].[Bank].[Customers] as c on c.[id]=a.[CustomersID] and c.[idcl]='3999'

  delete from [StatementAccount2020].[dbo].[Statement20201002]
  where [AccountID] in 
  (
  SELECT s.[AccountID]
  FROM [StatementAccount2020].[dbo].[Statement20201002] as s
  join [webclient].[Bank].[accountcustomers] as a on a.[id]=s.[AccountID]
  join [webclient].[Bank].[Customers] as c on c.[id]=a.[CustomersID] and c.[idcl]='3999'
  )