DECLARE @sales TABLE (saleID INT, saleAmount DECIMAL (10,2), saleDate DATETIME)
INSERT INTO @sales (saleID, saleAmount, saleDate) VALUES
(1, 100, '2015-08-01')
select * from @sales