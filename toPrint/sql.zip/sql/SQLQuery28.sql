SELECT pp.[SubstBank], pp.[ISOOfTransfer], SUM(pp.[AmountOfTransfer]), COUNT(*)
FROM [webclient].[Document].[pp20170828] as pp
WHERE pp.SubstBank in (15,16) AND pp.StepBank = 2
GROUP BY pp.[SubstBank], pp.[ISOOfTransfer]
ORDER BY pp.[SubstBank]
