USE [bb]
GO
declare @date nvarchar(max) = '2018-12-'  /*2018-MM-DD*/
--declare @day nvarchar(max) = '30'  /*2018-MM-DD*/
declare @Sql nvarchar(max)
declare @day int = 1;
declare @dayS nvarchar(max);

while @day <= 31
begin
--set @dayS = CONVERT(varchar(max), @day)
set @dayS = CASE WHEN @day<10 THEN CONVERT(varchar(max), 0) ELSE '' END + CONVERT(varchar(max), @day)

set @Sql = 'INSERT INTO [dbo].[Requests]
           ([date]
           ,[Account]
           ,[ISO]
           ,[DateFirst]
           ,[DateLast]
           ,[DocumentsDK]
           ,[TypeOfDischange]
           ,[Balance]
           ,[SessionID]
           ,[Completed] )
    SELECT  
	getdate()    
      ,[AccountIban]
	  ,[ISO]
	  , '''+@date+ @dayS +'''
	  , '''+@date+ @dayS +'''
	  ,0,0,0,0,0
  FROM [webclient].[Bank].[AccountCustomers] as c
  inner join webclient.Bank.Branches as bb on bb.[id]=c.[BranchID]
  inner join webclient.Bank.Customers as cu on cu.[id]=c.[CustomersID]
  left join [StatementAccount2018].[dbo].[Statement201812'+@dayS+'] as s ON s.[AccountID] = c.[ID]
  where 
  s.[BodyStatementAccount] is null
  and c.[AccountIban]!='''' 
  and c.[AccountIban] is not null 
  and c.[prSAPDM] = 0
  and cu.[bWork]=1 
  and bb.[ID] = 1171
  AND c.[DateCloseAccount] is null
  AND (c.[AccountIban] not like (''%AKBB38%'') OR c.[AccountIban] not like (''%AKBB2%'') )'
  --print @Sql
  EXEC (@Sql)
  set @Sql=''
  set @day = @day + 1
  end;