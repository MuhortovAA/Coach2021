
SELECT        
b2.[filial] as 'brgroup_f'
, b2.[cby] as 'brgroup_cby'
, g.[Name] AS NameGroup
--,g.[ID]
, Branches_1.Filial AS filialcustomer
, Branches_1.CBY AS cbycustomer
, c.[idcl]
, c.[name]
, CASE c.[prCentr] WHEN '0' THEN '���' WHEN '1' THEN '��' ELSE '���' END as '����������������'
FROM [webclient].[Access].[GroupCustomer] as gc
INNER JOIN [webclient].[Bank].[Customers] as c ON gc.[CustomerID] = c.[id] 
INNER JOIN [webclient].[Access].[Groups] as g ON gc.[GroupID] = g.[ID] 
INNER JOIN [webclient].[Bank].[Branches] as b2 ON g.[BranchID] = b2.[ID]
INNER JOIN [webclient].[Bank].[Branches] AS Branches_1 ON c.[IDFilial] = Branches_1.ID
where 
g.[PrEnrollmentLists]='1' 
and g.[prCustomer]='1' 
and g.[BranchID]='1167'
--and 
--g.[ID]='5009'
---g.[ID]='5624'
--and gc.GroupID in ('346','318','991','254','1166','3356','3357','3358','8','34')
--gc.GroupID in ('16')

--g.[Name] like '%���������� ��%'
--g.[Name] like '%�������� �� (527)%'
--AND Branches_1.Filial = '216'
						--AND LEN(Branches_1.cby)<1
						--AND (Branches_1.Filial in ('215','216')
						 --OR Branches_1.cby in ('200','207','212','218','225'))
						 --and Access.GroupCustomer.GroupID = '4785'
ORDER BY
g.[Name]
, Branches_1.Filial
, Branches_1.CBY
, c.[idcl]
, c.[name]
--c.[name]
