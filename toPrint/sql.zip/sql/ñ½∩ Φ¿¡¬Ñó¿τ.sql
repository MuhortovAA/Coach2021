SELECT 
b.[filial]
,b.[CBY]
, c.[name]
,c.[idcl]
,c.[UNP]
      ,u.[VersionOs]
	  ,u.[Login]
	  ,u.[DateLogin]
	  ,c.[bWork]
  FROM [webclient].[Bank].[user_client] as u
  	JOIN [webclient].[Bank].[Customers] as c ON c.[id] = u.[ClientID]
	JOIN [webclient].[Bank].[Branches] as b ON b.[ID]=c.[IDFilial]
	WHERE c.[bWork]=1 AND  u.[bWork] = 1 --and [versionos] in ('Windows XP') 
	and c.[idcl]='t795' and u.Login like '%9836%'
	--and b.filial='215' and  b.CBY='219'/*len(b.[cby])<1*/ --b.[id] in (@Branches)
  GROUP BY b.[filial], c.[name],c.[idcl],u.[VersionOs],u.[Login],u.[DateLogin],c.[bWork],b.[CBY],c.[UNP]
  order by u.[DateLogin],b.[filial], c.[idcl]

--SELECT        b.[id], b.[Name]
--FROM            [webclient].[Bank].[Branches] AS b
--WHERE        (LEN([Otdelenie]) = 0)
--ORDER BY [Filial]


