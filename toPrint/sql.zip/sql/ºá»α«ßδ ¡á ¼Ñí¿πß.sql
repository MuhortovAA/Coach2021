    SELECT  *
	----DISTINCT 
	--getdate()    
 --     ,[AccountIban]
	--  ,[ISO]
	--  ,'2018-12-01'
	--  ,'2018-12-01'
	--  --,dateadd(dd,-35,getdate())
	--  --,dateadd(dd,-35,getdate())
	--  ,0,0,0,0,0
  FROM [webclient].[Bank].[AccountCustomers] as c
  join webclient.Bank.Branches as bb on bb.id=c.BranchID
  join webclient.Bank.Customers as cu on cu.id=c.CustomersID
  left join [StatementAccount2018].[dbo].[Statement20181201] as s ON s.[AccountID] = c.[ID]
  where
   ---s.[BodyStatementAccount] is null
   --and 
  cu.idcl = 'ZHI0' 
  --AND 
  ----cu.idcl = 'zlqs' AND 
  ----AccountIban!='' and AccountIban is not null 
  ------and cu.kanal=1 
  --and c.prSAPDM = 0
  --and cu.bWork=1 
  ----and bb.[ID] = 1174
  ----and bb.[ID] = 1171
  ----and bb.TypeODB=1 
  --AND c.[DateCloseAccount] is null