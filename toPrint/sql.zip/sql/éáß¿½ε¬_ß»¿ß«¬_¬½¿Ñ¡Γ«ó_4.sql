--select 
--	cus.CustomerID 
--from
--(
select 
	 gr.idcl
	 , gr.[cname]
	 , gr.[grname]
	 , gc2.[CustomerID]
	 , g2.[Name]
FROM [webclient].[Access].[GroupCustomer] as gc2
left join (
			SELECT 
				c.[id], c.[idcl], c.[name] as cname, g.[Name] as grname
			FROM [webclient].[Access].[GroupCustomer] as gc
			INNER JOIN [webclient].[Bank].[Customers] as c ON gc.[CustomerID] = c.[id] 
			INNER JOIN [webclient].[Access].[Groups] as g ON gc.[GroupID] = g.[ID] 
			where g.[prCustomer]='1' and g.[BranchID]='307' and g.[ID]='109'
			) AS gr on gr.id = gc2.CustomerID
INNER JOIN [webclient].[Access].[Groups] as g2 ON gc2.[GroupID] = g2.[ID] 
where g2.[prCustomer]='1' and g2.[BranchID]='307'and g2.[ID]='41'
--) as cus
--where cus.idcl is null
--order by cus.CustomerID

