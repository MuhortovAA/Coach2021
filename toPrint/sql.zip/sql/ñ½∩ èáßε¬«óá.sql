



with mytable as (

SELECT dd.AccountIban, sum(dd.cou) as suma FROM
(SELECT
a.[AccountIban]
, c.[idcl]
--, count(*) as cou
,1 as cou
FROM [webclient].[Bank].[AccountCustomers] as a
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
JOIN [webclient].[Bank].[Branches] as b2 ON b2.[ID] = a.[BranchID]
group by a.[AccountIban] , c.[idcl], c.[bWork]--,a.[ISO], c.[idcl] , c.[bWork]
HAVING 
count(*)>0 
and len(a.[AccountIban])=28 
and c.[bWork]=1 
--and a.[AccountIban]='BY66AKBB30120000000200000000'
--and a.[AccountIban]='BY56AKBB30120000276301000000'
) as dd
GROUP BY dd.AccountIban, dd.cou
HAVING sum(dd.cou)>1
) 

select m.AccountIban, a.ISO,  c.[idcl], c.[name] from mytable as m
join [webclient].[Bank].[AccountCustomers] as a ON a.[AccountIban] = m.[AccountIban]
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
where m.AccountIban not like '%AKBB36%'
--join (

--select m.[AccountIban] from mytable as m
--join [webclient].[Bank].[AccountCustomers] as a ON a.[AccountIban] = m.[AccountIban]
--JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
--group by m.[AccountIban] , c.[idcl]
----having count(*)<2
--)							as aa On aa.AccountIban =a.[AccountIban]


