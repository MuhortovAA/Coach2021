WITH myunion(mydate, cid, tdoc) AS (
				
				SELECT '2017.02.10' AS mydate, c.[id] as cid, 'PP' as tdoc FROM [webclient].[Document].pp20170210 AS txt 
				INNER JOIN [webclient].[Bank].[Customers] AS c ON txt.[CustomerID] = c.[id]
				UNION ALL
				SELECT '2017.02.10' AS mydate, c.[id] as cid, 'TXT' as tdoc FROM [webclient].[Document].txt20170210 AS txt 
				JOIN [webclient].[Bank].[Customers] AS c ON txt.[ClientID] = c.[id] 
				)
select b.[Name] as bname, c.[name] as cname, [tdoc], count([tdoc]) as coudoc from myunion
RIGHT JOIN [webclient].[Bank].[Customers] as c on c.[id] = myunion.[cid] 
JOIN [webclient].[Bank].[Branches] as b ON b.[ID] = c.[IDFilial]
--where c.bWork = 1 and [mydate] is not null and b.[name] in (@Branches)
group by b.[Name], c.[name], [tdoc]
order by b.[Name], c.[name]