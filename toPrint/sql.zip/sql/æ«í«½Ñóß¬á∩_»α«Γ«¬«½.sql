/****** Script for SelectTopNRows command from SSMS  ******/
with mytable as(
SELECT 
  b.[name]
, u.[LastName]+' '+u.FirstName+' '+u.[MiddleName] as 'fio'
, CASE p.[TypeOperation] WHEN '46051' THEN 'ADD' WHEN '46052' THEN 'EDIT' WHEN '46053' THEN 'DELETE' END as 'oper'
, 1 as 'cou'
, cast(p.[WorkDT] as date) as 'daterep'
  FROM [webclient].[dbo].[Protokol202006] as p
  join [webclient].[Bank].[UsersBank] as u on u.[id]=p.[UserID]
  join [webclient].[Bank].[Branches] as b on b.[id]=p.[clientid]
  where p.[TypeOperation] in ('46051', '46052', '46053') 
  and [WorkDT] between '2020-24-06 00:00:00' and '2020-30-06 23:59:59'
  and b.[id]='1167'
    --and p.[Comment] like '%000013599%'
  UNION ALL
  SELECT 
  b.[name]
, u.[LastName]+' '+u.FirstName+' '+u.[MiddleName] as 'fio'
, CASE p.[TypeOperation] WHEN '46051' THEN 'ADD' WHEN '46052' THEN 'EDIT' WHEN '46053' THEN 'DELETE' END as 'oper'
, 1 as 'cou'
, cast(p.[WorkDT] as date) as 'daterep'
  FROM [webclient].[dbo].[Protokol202007] as p
  join [webclient].[Bank].[UsersBank] as u on u.[id]=p.[UserID]
  join [webclient].[Bank].[Branches] as b on b.[id]=p.[clientid]
  where p.[TypeOperation] in ('46051', '46052', '46053') 
  and [WorkDT] between '2020-01-07 00:00:00' and '2020-01-07 23:59:59'
  and b.[id]='1167'
  --and p.[Comment] like '%000013599%'

  --ORDER BY b.[name], u.[LastName]+' '+u.FirstName+' '+u.[MiddleName]
  )
  SELECT * FROM mytable as m
  PIVOT (sum(m.[cou]) FOR m.[daterep] IN ([2020-06-24],[2020-06-25],[2020-06-26],[2020-06-27],[2020-06-28],[2020-06-29],[2020-06-30],[2020-07-01]) ) pvt

