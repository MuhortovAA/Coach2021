SELECT 
b.[Filial]
, b.[CBY]
,c.[idcl]
, c.[name]
,c.[UNP]
,c.[prRemoteSupport]

  FROM [webclient].[Bank].[Customers] as c
  join [webclient].[Bank].[Branches] as b ON b.[id] = c.[IDFilial]
  where c.[bwork]=1 and b.[Filial]='312' --and c.[idcl] in ('WSQB', 'WHU4')
  order by b.[Filial], b.[CBY], c.[name]
  --group by c.[WorkPackage]
