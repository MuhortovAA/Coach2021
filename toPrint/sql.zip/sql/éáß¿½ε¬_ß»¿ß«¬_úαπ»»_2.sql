with mytable as (
SELECT        
--b2.[filial] as 'brgroup_f'
--, b2.[cby] as 'brgroup_cby'
g.[Name] AS NameGroup
--,g.[ID]
, Branches_1.Filial +'\' + Branches_1.CBY AS branch
, 1 as 'countcustom'
--, c.[idcl]
--, c.[name]
--, CASE c.[prCentr] WHEN '0' THEN '���' WHEN '1' THEN '��' ELSE '���' END as '����������������'
FROM [webclient].[Access].[GroupCustomer] as gc
INNER JOIN [webclient].[Bank].[Customers] as c ON gc.[CustomerID] = c.[id] 
INNER JOIN [webclient].[Access].[Groups] as g ON gc.[GroupID] = g.[ID] 
INNER JOIN [webclient].[Bank].[Branches] as b2 ON g.[BranchID] = b2.[ID]
INNER JOIN [webclient].[Bank].[Branches] AS Branches_1 ON c.[IDFilial] = Branches_1.ID
where 
g.[PrEnrollmentLists]='1' 
and g.[prCustomer]='1' 
and g.[BranchID]='1167'
--and 
--g.[ID]='45'
--and gc.GroupID in ('346','318','991','254','1166','3356','3357','3358','8','34')
--and gc.GroupID in ('5394')

--g.[Name] like '%���������� ��%'
--g.[Name] like '%�������� �� (527)%'
--AND Branches_1.Filial = '413'
						--AND LEN(Branches_1.cby)<1
						 --AND Branches_1.Filial in ('802')
						-- AND Branches_1.cby in ('524')
						 --and Access.GroupCustomer.GroupID = '4785'
--ORDER BY
--g.[Name]
--, Branches_1.Filial
--, Branches_1.CBY
--, c.[idcl]
--, c.[name]
) 
SELECT * FROM mytable as m
--SELECT m.[branch] FROM mytable as m
--group by m.[branch]
--order by m.[branch]
PIVOT (count([countcustom]) FOR  [branch] in ([000\],[000\400],[000\401],[000\402],[000\403],[000\407],[000\408],[000\410],[000\411],[000\413],[000\415],[000\416],[000\417],[000\418],[000\419],[000\421],[000\422],[000\423],[000\424],[000\500],[000\510],[000\511],[000\514],[000\527],[000\529],[000\601],[000\602],[000\605],[000\606],[000\607],[000\609],[000\610],[000\611],[000\612],[000\613],[000\615],[000\616],[000\619],[000\620],[000\621],[000\623],[000\624],[000\625],[000\626],[000\627],[000\632],[000\633],[000\700],[000\701],[000\703],[000\706],[000\707],[000\708],[000\709],[000\710],[000\711],[000\712],[000\713],[000\714],[000\715],[000\721],[000\722],[000\723],[000\724],[000\725],[000\726],[000\727],[000\728],[100\],[100\109],[100\115],[113\],[113\106],[113\122],[121\],[121\112],[121\119],[121\124],[200\],[200\207],[200\212],[200\218],[200\225],[215\],[215\203],[215\210],[215\219],[215\222],[216\],[216\205],[216\206],[216\208],[216\209],[216\211],[216\213],[216\214],[216\217],[216\221],[216\224],[216\230],[300\],[300\306],[300\309],[300\315],[300\316],[300\323],[300\326],[300\327],[302\],[302\307],[302\308],[312\],[312\319],[312\322],[312\324],[317\],[317\311],[317\313],[317\318],[317\320],[802\],[802\107],[802\108],[802\111],[802\117]))p
--PIVOT (COUNT([sum]) FOR [timer] IN ([01],[02],[03],[04],[05],[06],[07],[08],[09],[10],[11],[12],[13],[14],[15],[16],[17],[18],[19],[20],[21],[22],[23]))p
