SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE Dynamic_SP
      @Table_Name sysname
AS
BEGIN
      SET NOCOUNT ON;
      DECLARE @DynamicSQL nvarchar(4000)
      SET @DynamicSQL = N'SELECT * FROM ' + @Table_Name
      EXECUTE sp_executesql @DynamicSQL
END
GO