  declare @myid int = 1;
declare @SCCount int = 100;
DECLARE @DynamicSQL nvarchar(max) ='';
while @myid <= @SCCount
begin
	with mytable as (
	SELECT 
	ROW_NUMBER() OVER (ORDER BY [clientid]) AS Row
	,m.[clientid]
	,m.[elclientid]
	,m.[clientname]
	,m.[code]
	FROM [dbo].[myCustomers] as m
	  LEFT JOIN [webclient].[Bank].[Customers] as c ON c.[idcl] = m.[code]
	  where c.[bWork] = 1 and c.[CodeCustomerOdbScOracle] is null OR c.[CodeCustomerOdbScOracle] ='' --*/AND c.[idcl] like 'B%'
	)
	select @DynamicSQL='UPDATE [webclient].[Bank].[Customers] SET [CodeCustomerOdbScOracle] =' + m.[clientid] + ' WHERE [idcl] = '''+m.[code] + ''''from mytable as m
	where m.[Row] = 1/* @myid */
	print @DynamicSQL
	--EXEC (@DynamicSQL)
	SET @DynamicSQL=''
	set @myid = @myid+1
	print @myid
end