/****** Script for SelectTopNRows command from SSMS  ******/
/****** Script for SelectTopNRows command from SSMS  ******/
WITH MYTABLE (name, idcl, [ClientID]) as
(
SELECT mydate, clientid
  FROM 
  (
  select  '2014.05.06' as mydate, my06.ClientID as clientid from [webclient].[Document].[txt20140506] as my06
  union all
  select  '2014.05.05', my05.ClientID from [webclient].[Document].[txt20140505] as my05
  ) mydbtxt INNER JOIN [webclient].[Bank].[Customers] as c
  ON mydbtxt.clientid = c.id
  )
  select  
  '2014.05.06' as mydate
  --,m.name
  --,m.idcl
  ,COUNT(name) as mycount 
  from MYTABLE as m 
  --group by 
  --m.name
  --, m.idcl 
  --order by mycount

