
delete from [webclient].[Access].[GroupCustomer]
where ID in (
				select cte.ID from 
				(select 
					t1.ID
					, t1.CustomerID
					, ROW_NUMBER() OVER (PARTITION BY t1.CustomerID ORDER BY t1.CustomerID) row_num
				from [webclient].[Access].[GroupCustomer] as t1
				join (SELECT 
						gc.[CustomerID]
						FROM [webclient].[Access].[GroupCustomer] as gc
						where gc.GroupID in ('4767')
						GROUP BY gc.[CustomerID]
						having COUNT(*)>1) as res ON res.CustomerID=t1.CustomerID
				WHERE t1.GroupID='4767'
				) as cte
				where cte.row_num=1
			)