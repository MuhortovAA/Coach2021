
DECLARE @myresult TABLE (
nameAllOTS varchar(255),
MID varchar(255),
TransType varchar(255),
CMSDate varchar(255),
TransSum varchar(255),
rangeCodes varchar(255) );

INSERT INTO @myresult (res1,res2,res3,res4,res5,res6) /*EXEC [webclient].[dbo].[Dynamic_SP] @strdate*/
SELECT     DISTINCT   g.nameAllOTS, c.MID, c.TransType, c.CMSDate, c.TransSum, g.rangeCodes
FROM            dbo.CMS AS c 
INNER JOIN dbo.GTRM AS g ON c.MID = g.MID
WHERE        (c.TransType IN ('205', '226'))

SELECT * FROM @myresult

SELECT '205-226' as '����', SUM(c.[TransSum]) as '�����'
  /*SELECT c.[MID], c.[TransType], c.[CMSDate], SUM(c.[TransSum])*/
  FROM [PartnerPayment].[dbo].[CMS] as c
  WHERE c.[TransType] in ('205', '226')