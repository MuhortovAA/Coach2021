DECLARE @SQLQuery AS NVARCHAR(500)
--DECLARE @myDateQuery AS DATETIME =DATEPART()  GETDATE()--CONVERT(char(10), GetDate(),102)
DECLARE @TableName AS NVARCHAR(100) = '[webclient].[Document].pp20170210'
--DECLARE @myDateQuery DateTime
--SET @myDateQuery = GetDate()
--SET @myDateQuery = DateAdd(day, 1, @myDateQuery)

--SET @myDateQuery = CONVERT(char(10), GetDate(),102)
--SET @TableName = '[webclient].[Document].pp20170210'
--  CONVERT (DAY, GETDATE()) + CONVERT (month, GETDATE())
--SET @SQLQuery = 'SELECT ''2017.02.10'' AS mydate, c.[id] as cid, ''PP'' as tdoc FROM [webclient].[Document].pp20170210 AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id' 
SET @SQLQuery = 'SELECT txt.datedocument, c.[id] as cid, ''PP'' as tdoc FROM ' + @TableName + ' AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id' 
--SELECT + '2017.02.10', c.[id] as cid, 'PP' as tdoc FROM ' + @TableName + ' AS txt INNER JOIN Bank.Customers AS c ON txt.CustomerID = c.id
EXECUTE sp_executesql @SQLQuery
 --SELECT CONVERT(nvarchar(10), getdate(), 103)
--select CONVERT (date, GETDATE())
--select DATEPART(YEAR, GETDATE()) +'.'+ DATEPART(MONTH, GETDATE()) +''+ DATEPART(DAY, GETDATE())
--SELECT DATEADD(year, 0, GETDATE()) 
--SELECT CONVERT(char(10), GetDate(),102)
--SELECT DATE(dd, 1, GETDATE())
--DECLARE @date DateTime
--SET @date = GetDate()
--SET @date = DateAdd(day, 1, @date)
--SELECT @date 