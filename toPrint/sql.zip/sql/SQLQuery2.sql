/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [UserID]
      ,[ClientID]
      ,[datedoc]
      ,[NumDoc]
      ,[IP]
      ,[WorkDT]
      ,[TypeARM]
      ,[TypeOperation]
      ,[TypeDoc]
      ,[TypeDocDop]
      ,[Login]
      ,[Comment]
      ,[DocClientID]
      ,[TableOperation]
      ,[OperationCode]
  FROM [webclient].[dbo].[Protokol202010]
  where [Comment] like '%vip%'
  order by [WorkDT] desc