DECLARE @mydate datetime = '2019-06-09' -- yyyy-dd-mm
DECLARE @sdt nvarchar(max) = CONVERT(varchar(8),@mydate,112);
DECLARE @year nvarchar(max) = YEAR(@mydate);
DECLARE @add nvarchar(max) = cast(YEAR(@mydate) as varchar(max))+'-'+cast(day(@mydate) as varchar(max))+'-'+cast(month(@mydate) as varchar(max));

--DECLARE @sdt nvarchar(max) = CONVERT(varchar(8),dateadd(dd,-108,getdate()),112);
DECLARE @DynamicSQL nvarchar(4000) =N'
	use [webclient]
	declare @dayadd datetime = '''+@add+'''
	INSERT INTO [webclient].[Bank].[RequestsSC]
           ([DateQuery]
           ,[Account]
           ,[ISO]
           ,[MFO]
           ,[DateFirst]
           ,[DateLast]
           ,[DocumentsDK]
           ,[Balance]
           ,[Completed]
 ,[OdbOld]
            )
	SELECT getdate()    
      ,[AccountIban]
	  ,[ISO]
	  ,''810''
	  --, SUBSTRING( [bb].[Mfo],7,3)
	  ,@dayadd
	  ,@dayadd
	  ,0,0,0,0 --- ����� �� -1, ����� 0 / null
  FROM [webclient].[Bank].[AccountCustomers] as c
  inner join [webclient].[Bank].[Branches] as bb on bb.id=c.BranchID
  inner join [webclient].[Bank].[Customers] as cu on cu.id=c.CustomersID
  left join [StatementAccount'+@year+'].[dbo].[Statement'+@sdt+'] as s ON c.[ID] = s.[AccountID] 
  where 
  c.[AccountIban]!='''' 
  --and s.[AccountID] is null
  and c.[AccountIban] is not null 
  
  AND (c.[AccountIban] not like (''%AKBB38%'') AND c.[AccountIban] not like (''%AKBB2%''))
  --and bb.[Filial] = ''614''
  and bb.[CBY] = ''621''
  and cu.[bWork]=1 
  --and bb.[TypeODB]=2 
  AND c.[DateCloseAccount] is null
  --AND SUBSTRING( [bb].[Mfo],7,3) <> ''795''
  --and s.[AccountID] is null
  --and cu.[idcl]=''W1HS''
  '
  --print @DynamicSQL
  EXECUTE sp_executesql @DynamicSQL
