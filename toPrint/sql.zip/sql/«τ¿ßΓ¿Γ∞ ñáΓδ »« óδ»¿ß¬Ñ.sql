select 
cast(YEAR(s.[QueryDateTime]) as varchar(max)) +'.'+ cast(MONTH(s.[QueryDateTime]) as varchar(max))+'.'+cast(DAY(s.[QueryDateTime]) as varchar(max))
, count(*)
from [StatementAccount2018].[dbo].[Statement20181213]  as s
--where YEAR(s.[QueryDateTime]) = '2019' AND MONTH(s.[QueryDateTime]) = '2' AND DAY(s.[QueryDateTime]) ='11'
group by cast(YEAR(s.[QueryDateTime]) as varchar(max)) +'.'+ cast(MONTH(s.[QueryDateTime]) as varchar(max))+'.'+cast(DAY(s.[QueryDateTime]) as varchar(max))
order by cast(YEAR(s.[QueryDateTime]) as varchar(max)) +'.'+ cast(MONTH(s.[QueryDateTime]) as varchar(max))+'.'+cast(DAY(s.[QueryDateTime]) as varchar(max)) desc

--delete from [StatementAccount2018].[dbo].[Statement20181213]
--where YEAR([QueryDateTime]) = '2019' AND MONTH([QueryDateTime]) = '2' AND DAY([QueryDateTime]) ='11'