SELECT 
month(c.[CMSDate])
, COUNT(*)
  FROM [PartnerPayment].[dbo].[CMSNew] as c
  where year(c.[CMSDate])='2018'
  GROUP BY month(c.[CMSDate])
  SELECT 
month(c.[CMSDate])
, COUNT(*)
  FROM [PartnerPayment].[dbo].[CMSNewArc2018] as c
  where year(c.[CMSDate])='2018'
  GROUP BY month(c.[CMSDate])