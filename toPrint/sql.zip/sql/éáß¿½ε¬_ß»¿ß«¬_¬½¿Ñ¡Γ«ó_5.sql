		SELECT 
			--c.[id]
			c.[idcl]
			--c.[name] as cname
			, COUNT(*)
			--, g.[Name] as grname
		FROM [webclient].[Access].[GroupCustomer] as gc
		INNER JOIN [webclient].[Bank].[Customers] as c ON gc.[CustomerID] = c.[id] 
		INNER JOIN [webclient].[Access].[Groups] as g ON gc.[GroupID] = g.[ID] 
		where 
		g.[prCustomer]='1' 
		and g.[BranchID]='307'
		--and g.[ID]='109'
		and g.[ID]='41'

		group by c.[idcl]
		having
		COUNT(*) > 1