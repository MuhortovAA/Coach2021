
USE [webclient]
GO
--���� �
DECLARE @datefrom DATETIME = '2018-01-01'; -- YYYY-DD-MM
--���� ��
DECLARE @dateto DATETIME = GETDATE();/*'2017-31-12'--  -- YYYY-DD-MM GETDATE()*/
--
DECLARE @strdate VARCHAR(8);
--���� �� ����
DECLARE @sDAY VARCHAR(2); 
---
DECLARE @DynamicSQL nvarchar(4000) ='';
--
DECLARE @myresult TABLE ([name] varchar(max),  [fil] varchar(255), [cbu] varchar(255), [otd] varchar(255), [pay] varchar(255), [marga] varchar(255), [type] varchar(255), [cou] varchar(255), [typepp] varchar(max), [TextDoc] varchar(max));


--����
while @datefrom <= @dateto
---
begin
--
set @strdate = convert(varchar(8), @datefrom, 112)
---
DECLARE @tableSt VARCHAR(17) = concat('txt',@strdate);
---
	----������ � ��������
	IF (EXISTS (SELECT * FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = 'Document' AND  TABLE_NAME = @tableSt))
	BEGIN
	set @sDAY = convert(varchar(2),DAY(@datefrom))
	--
	SET @DynamicSQL =N'SELECT 
		c.[name]
		, SUBSTRING(CAST(t.[TextDoc] as varchar(max)), CHARINDEX(''<FILIAL>'', CAST(t.[TextDoc] as varchar(max)))+8, CHARINDEX(''<CBY>'', CAST(t.[TextDoc] as varchar(max)))-CHARINDEX(''<FILIAL>'', CAST(t.[TextDoc] as varchar(max)))-8) as ''filial''
		, SUBSTRING(CAST(t.[TextDoc] as varchar(max)), CHARINDEX(''<CBY>'', CAST(t.[TextDoc] as varchar(max)))+5, CHARINDEX(''<NOTD>'', CAST(t.[TextDoc] as varchar(max)))-CHARINDEX(''<CBY>'', CAST(t.[TextDoc] as varchar(max)))-5) as ''cby''
		, SUBSTRING(CAST(t.[TextDoc] as varchar(max)), CHARINDEX(''<NOTD>'', CAST(t.[TextDoc] as varchar(max)))+6, CHARINDEX(''<total_p>'', CAST(t.[TextDoc] as varchar(max)))-CHARINDEX(''<NOTD>'', CAST(t.[TextDoc] as varchar(max)))-6) as ''otd''
		, t.[total_s] as ''������������''
		, t.[TotalCommission] as ''��������������''
		, CASE t.[VSP] WHEN ''K'' THEN ''��������'' WHEN ''V'' THEN ''�����'' END as ''���''
		, SUBSTRING(CAST(t.[TextDoc] as varchar(max)), CHARINDEX(''<total_p>'', CAST(t.[TextDoc] as varchar(max)))+9, CHARINDEX(''<total_s>'', CAST(t.[TextDoc] as varchar(max)))-CHARINDEX(''<total_p>'', CAST(t.[TextDoc] as varchar(max)))-9) as ''���''
		, t.[NZP] as ''��� �''
		, CAST(t.[TextDoc] as varchar(max))
		FROM [webclient].[Document].[txt'+ @strdate + '] as t,
		     [webclient].[Bank].[Customers] as c 
		WHERE t.[typedop] = 43 AND c.[id] = t.[ClientID]'
		--print @DynamicSQL
		INSERT INTO @myresult ([name], [fil], [cbu], [otd], [pay], [marga], [type], [cou], [typepp], [TextDoc]  ) 
	EXECUTE sp_executesql @DynamicSQL

	END
    
set @datefrom = DATEADD(DAY,1,@datefrom)
end
SELECT m.[fil], m.[cbu], m.[otd], m.[name], m.[type], m.[pay], m.[cou] FROM @myresult as m
ORDER BY m.[name]




--with mytable as (
--SELECT 
--		ROW_NUMBER() OVER (ORDER BY c.[name] DESC) AS Row
--		, c.[name]
--		, t.[total_s] as '������������'
--		, t.[TotalCommission] as '��������������'
--		, CASE t.[VSP] WHEN 'K' THEN '��������' WHEN 'V' THEN '�����' END as '���'
--		, SUBSTRING(CAST(t.[TextDoc] as varchar(max)), CHARINDEX('<total_p>', CAST(t.[TextDoc] as varchar(max)))+9, CHARINDEX('<total_s>', CAST(t.[TextDoc] as varchar(max)))-CHARINDEX('<total_p>', CAST(t.[TextDoc] as varchar(max)))-9) as '���'
--		, t.[NZP] as '��� �'

--FROM [webclient].[Document].[txt20171114] as t
--join [webclient].[Bank].[Customers] as c ON c.[id] = t.[ClientID]
--WHERE t.[typedop] = 43 

--)
--SELECT * from mytable 
