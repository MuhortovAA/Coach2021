----������� �� ��� SAP
go
--DECLARE @listclid VARCHAR(256);
--set @listclid = '5UN8';

with mytable ([myttype], [mysoz]) as (
SELECT '���������', '��� SAP'
FROM [webclient].[Bank].[RequestsSap] as r
JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[Account] = r.[Account]
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
WHERE r.[Completed]=1
UNION ALL
SELECT '� ���������', '��� SAP'
FROM [webclient].[Bank].[RequestsSap] as r
JOIN [webclient].[Bank].[AccountCustomers] as b ON b.[AccountIban] = r.[Account]
JOIN [webclient].[Bank].[Customers] as cv ON cv.[id] = b.[CustomersID]
WHERE r.[Completed]=0 
) 
SELECT * FROM mytable
PIVOT (COUNT([myttype]) FOR [myttype] IN ([���������], [� ���������]))p

----������� �� ��� SAP

--SELECT *
--FROM [webclient].[Bank].[RequestsSap] as r
--JOIN [webclient].[Bank].[AccountCustomers] as b ON b.[AccountIban] = r.[Account]
--JOIN [webclient].[Bank].[Customers] as cv ON cv.[id] = b.[CustomersID]
--WHERE r.[Completed]=0 
--ORDER BY r.[DateQuery] desc

--UPDATE [webclient].[Bank].[RequestsSap]
--SET [Completed]=1
--where DAY([DateQuery]) = 17


--with mytable1 ([datequery], [account], [iso], [mfo], [datefirst], [datelast], [idcl], [Completed]) as (
--SELECT r.[datequery], r.[account], r.[iso], r.[mfo], r.[datefirst], r.[datelast], cv.[idcl], r.[Completed]
--FROM [webclient].[Bank].[RequestsSap] as r
--JOIN [webclient].[Bank].[AccountCustomers] as b ON b.[AccountIban] = r.[Account]
--JOIN [webclient].[Bank].[Customers] as cv ON cv.[id] = b.[CustomersID]
--WHERE r.[Completed]=0 
--UNION ALL
--SELECT r.[datequery], r.[account], r.[iso], r.[mfo], r.[datefirst], r.[datelast], c.[idcl], r.[Completed]
--FROM [webclient].[Bank].[RequestsSap] as r
--JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[Account] = r.[Account]
--JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
--WHERE r.[Completed]=0 
--) 
--SELECT [idcl], [Completed],COUNT(*) as '�� ��������' FROM mytable1
--GROUP BY [idcl], [Completed]
--ORDER BY [idcl]


 

 


 

 
