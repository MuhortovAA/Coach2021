----������� �� ���
go
DECLARE @listclid VARCHAR(256);
set @listclid = 'W7DY';

with mytable ([datequery], [account], [iso], [mfo], [datefirst], [datelast], [idcl], [Completed]) as (
SELECT r.[datequery], r.[account], r.[iso], r.[mfo], r.[datefirst], r.[datelast], cv.[idcl], r.[Completed]
FROM [webclient].[Bank].[RequestsSC] as r
JOIN [webclient].[Bank].[AccountCustomers] as b ON b.[AccountIban] = r.[Account]
JOIN [webclient].[Bank].[Customers] as cv ON cv.[id] = b.[CustomersID]
WHERE cv.[idcl] in (@listclid) 
UNION ALL
SELECT r.[datequery], r.[account], r.[iso], r.[mfo], r.[datefirst], r.[datelast], c.[idcl], r.[Completed]
FROM [webclient].[Bank].[RequestsSC] as r
JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[Account] = r.[Account]
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
WHERE c.[idcl] in (@listclid)
) 
SELECT [idcl], [Completed],COUNT(*) as '�� �������' FROM mytable
GROUP BY [idcl], [Completed]
ORDER BY [idcl];

----������� �� ���

with mytable1 ([datequery], [account], [iso], [mfo], [datefirst], [datelast], [idcl], [Completed]) as (
SELECT r.[datequery], r.[account], r.[iso], r.[mfo], r.[datefirst], r.[datelast], cv.[idcl], r.[Completed]
FROM [webclient].[Bank].[RequestsSC] as r
JOIN [webclient].[Bank].[AccountCustomers] as b ON b.[AccountIban] = r.[Account]
JOIN [webclient].[Bank].[Customers] as cv ON cv.[id] = b.[CustomersID]
WHERE r.[Completed]=0 AND cv.idcl in (@listclid)
UNION ALL
SELECT r.[datequery], r.[account], r.[iso], r.[mfo], r.[datefirst], r.[datelast], c.[idcl], r.[Completed]
FROM [webclient].[Bank].[RequestsSC] as r
JOIN [webclient].[Bank].[AccountCustomers] as a ON a.[Account] = r.[Account]
JOIN [webclient].[Bank].[Customers] as c ON c.[id] = a.[CustomersID]
WHERE r.[Completed]=0 AND c.idcl in (@listclid)
) 
SELECT [idcl], [Completed],COUNT(*) as '�� ��������' FROM mytable1
GROUP BY [idcl], [Completed]
ORDER BY [idcl]


 

 


 

 
