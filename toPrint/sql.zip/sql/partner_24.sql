/*2.4  */ 
  SELECT DISTINCT g.[nameAllOTS], g.[rangeCodes], g.unn, g.[filialSign], c.[MID], c.[TransType], c.[CMSDate], c.[TransSum]
  FROM [PartnerPayment].[dbo].[CMS] as c
  JOIN  [PartnerPayment].[dbo].[GTRM] as g ON g.[MID] = c.[MID]
  WHERE c.[TransType] in ('206', '225') AND g.[nameAllOTS] is not null AND c.[MID] = '48428'
  ORDER BY g.[nameAllOTS]



/*205-226*/
  SELECT '205-226' as '����', SUM(c.[TransSum]) as '�����'
  /*SELECT c.[MID], c.[TransType], c.[CMSDate], SUM(c.[TransSum])*/
  FROM [PartnerPayment].[dbo].[CMS] as c
  WHERE c.[TransType] in ('205', '226')
  --GROUP BY c.[MID], c.[TransType], c.[CMSDate]
  /* 206-225*/
  UNION ALL
  SELECT '206-225', SUM(c.[TransSum])
  /*SELECT c.[MID], c.[TransType], c.[CMSDate], SUM(c.[TransSum])*/
  FROM [PartnerPayment].[dbo].[CMS] as c
  WHERE c.[TransType] in ('206', '225')
  --GROUP BY c.[MID], c.[TransType], c.[CMSDate]
