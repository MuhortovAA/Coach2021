﻿using ConverterGtrm.Core;
using ConverterGtrm.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace ConverterGtrm
{
    class Program
    {
        static void Main(string[] args)
        {
            //
            myInformator.Send("Старт программы");
            var version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            string Description = ((AssemblyDescriptionAttribute)Attribute.GetCustomAttribute(Assembly.GetExecutingAssembly(), typeof(AssemblyDescriptionAttribute), false)).Description;
            myInformator.Send($"Текущая версия {version.Major}.{version.Minor}.{version.Build}.{version.Revision} {Description}");
            myInformator.Send($"***текущий сервер СУБД: {myInformator.GetDataSource()}");
            //get data from oracledb and save to file
            ServiceLayer sl = new ServiceLayer();
            sl.ParseData();



            //Get data from DB
            //OracleDB oracle = new OracleDB();
            //EnumerableRowCollection<DataRow> collection = oracle.GetData();
            //
            //Console.WriteLine($"{DateTime.Now}: receive data from oracle");


            //Save data to File
            //FileService fs = new FileService();
            //Console.WriteLine($"{DateTime.Now}: save data to file");
            //fs.WriteData(collection);


            //Load from file
            //List<OTSInfoNotEq> collectionfile = fs.LoadNotEq();
            //List<OTSInfoEq> collectionfile = fs.LoadEq();

            //Console.WriteLine($"{DateTime.Now}: load data from file");

            //Save data GTRM to DB Not_Eq
            //RepositoryOTSInfoNotEq repository = new RepositoryOTSInfoNotEq();
            //repository.TruncateOTSInfoNotEq();
            //repository.Save(collectionfile);
            //Save data GTRM to DB Eq
            //RepositoryOTSInfoEq repository = new RepositoryOTSInfoEq();
            //repository.Truncate();
            //repository.Save(collectionfile);


            myInformator.Send4($"Обработка данных выполнена!");
            myInformator.SendConsole3($"Нажмите любую клавишу для выхода!");

            Console.ReadLine();
        }
    }
}
