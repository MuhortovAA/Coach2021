﻿using ConverterGtrm.Core;
using Oracle.ManagedDataAccess.Client;
using Oracle.ManagedDataAccess.Types;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConverterGtrm.Services
{
    public class OracleDB
    {
        string userlogin = "gt_bonus";
        string password = "gBt_201";

        //string userlogin = "gtrm_asb";
        //string password = "gtrm_p4SW";
        string serverhost = "10.200.65.144";
        DateTime datefrom;
        DateTime dateto;

        ConfigApp conf;

        public OracleDB()
        {
            //
            conf = new ConfigApp();
            //
            if (null== conf.GetSetting("DateFrom")) conf.AddUpdateAppSettings("DateFrom", DateTime.Now.ToString("dd.MM.yyyy"));
            if (null == conf.GetSetting("DateTo")) conf.AddUpdateAppSettings("DateTo", DateTime.Now.ToString("dd.MM.yyyy"));

            //conf.AddUpdateAppSettings("DateTo", DateTime.Now.ToString("dd.MM.yyyy"));
            datefrom = DateTime.Parse(conf.GetSetting("DateFrom")?? DateTime.Now.ToString("dd.MM.yyyy"));
            dateto = DateTime.Parse(conf.GetSetting("DateTo")?? DateTime.Now.ToString("dd.MM.yyyy"));
        }

        public EnumerableRowCollection<DataRow> GetData()
        {

            string datasource = $"(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = {serverhost})(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = XE)))";
            //
            OracleConnectionStringBuilder ocsb = new OracleConnectionStringBuilder()
            {
                UserID = userlogin,
                Password = password,
                DataSource = datasource
            };
            //
            DateTime dt1 = new DateTime(DateTime.Now.Year, DateTime.Now.Month - 1, 1, 0, 0, 0, 0);
            DateTime dt2 = new DateTime(DateTime.Now.Year, DateTime.Now.Month - 1, 31, 0, 0, 0, 0);

            DateTime dt = DateTime.Now;

            //
            using (OracleConnection connection = new OracleConnection(ocsb.ConnectionString))
            {
                using (OracleCommand cmd = new OracleCommand())
                {
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;
                    string function1 = "NOT_EQ_OTS_InFO";
                    string function2 = "EQ_OTS_InFO";

                    cmd.CommandText = $"begin  :cursType := GTRM_ASB.P_GTRM_REP_BONUS.{function2}(:date_begin, :date_end); end;";
                    cmd.BindByName = true;
                    cmd.Parameters.Add("date_begin", OracleDbType.Date, ParameterDirection.Input).Value = dt1;
                    cmd.Parameters.Add("date_end", OracleDbType.Date, ParameterDirection.Input).Value = dt2;
                    cmd.Parameters.Add("cursType", OracleDbType.RefCursor).Direction = ParameterDirection.ReturnValue;
                    cmd.Connection.Open();
                    cmd.ExecuteNonQuery();
                    OracleDataAdapter da = new OracleDataAdapter();
                    DataSet ds = new DataSet();
                    da.Fill(ds, "TableGTRM", (OracleRefCursor)(cmd.Parameters["cursType"].Value));
                    EnumerableRowCollection<DataRow> collection = ds.Tables["TableGTRM"].AsEnumerable();
                    //foreach (var item in collection)
                    //{
                    //    string resstr = "";
                    //    foreach (var datagtrm in item.ItemArray)
                    //    {
                    //        resstr = resstr + "\t" + datagtrm.ToString();
                    //    }
                    //    Console.WriteLine(resstr);
                    //}
                    return collection;
                }
            }
        }

        public EnumerableRowCollection<DataRow> GetData(string name_func)
        {

            string datasource = $"(DESCRIPTION =(ADDRESS = (PROTOCOL = TCP)(HOST = {serverhost})(PORT = 1521))(CONNECT_DATA =(SERVER = DEDICATED)(SERVICE_NAME = XE)))";
            //
            OracleConnectionStringBuilder ocsb = new OracleConnectionStringBuilder()
            {
                UserID = userlogin,
                Password = password,
                DataSource = datasource
            };
            //

           


            //DateTime dt1 = new DateTime(DateTime.Now.Year, DateTime.Now.Month - 1, 1, 0, 0, 0, 0);
            //DateTime dt2 = new DateTime(DateTime.Now.Year, DateTime.Now.Month - 1, 31, 0, 0, 0, 0);
            myInformator.Send($"Получение данных для: {name_func} период с:{datefrom.Day}.{datefrom.Month}.{datefrom.Year} по:{dateto.Day}.{dateto.Month}.{dateto.Year}");

            DateTime dt = DateTime.Now;

            //
            using (OracleConnection connection = new OracleConnection(ocsb.ConnectionString))
            {
                using (OracleCommand cmd = new OracleCommand())
                {
                    cmd.Connection = connection;
                    cmd.CommandType = CommandType.Text;
                    //string function1 = "NOT_EQ_OTS_InFO";
                    //string function2 = "EQ_OTS_InFO";

                    cmd.CommandText = $"begin  :cursType := GTRM_ASB.P_GTRM_REP_BONUS.{name_func}(:date_begin, :date_end); end;";
                    cmd.BindByName = true;
                    cmd.Parameters.Add("date_begin", OracleDbType.Date, ParameterDirection.Input).Value = datefrom;
                    cmd.Parameters.Add("date_end", OracleDbType.Date, ParameterDirection.Input).Value = dateto;
                    cmd.Parameters.Add("cursType", OracleDbType.RefCursor).Direction = ParameterDirection.ReturnValue;
                    cmd.Connection.Open();
                    cmd.ExecuteNonQuery();
                    OracleDataAdapter da = new OracleDataAdapter();
                    DataSet ds = new DataSet();
                    da.Fill(ds, "TableGTRM", (OracleRefCursor)(cmd.Parameters["cursType"].Value));
                    EnumerableRowCollection<DataRow> collection = ds.Tables["TableGTRM"].AsEnumerable();
                    //foreach (var item in collection)
                    //{
                    //    string resstr = "";
                    //    foreach (var datagtrm in item.ItemArray)
                    //    {
                    //        resstr = resstr + "\t" + datagtrm.ToString();
                    //    }
                    //    Console.WriteLine(resstr);
                    //}
                    return collection;
                }
            }
        }
    }
}
