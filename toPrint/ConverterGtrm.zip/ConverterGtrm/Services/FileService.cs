﻿using ConverterGtrm.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConverterGtrm.Services
{
    public class FileService
    {
        private string FileName = "";
        private string CatalogLoad = "";
        private string FileLoad = "";
        ConfigApp conf;
        RepositoryProtocolLoad repPL;


        public FileService()
        {
            conf = new ConfigApp();
            repPL = new RepositoryProtocolLoad();

            CatalogLoad = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Load");
            FileLoad = Path.Combine("gtrm.txt");
            CheckFile();
        }
        private void CheckFile()
        {
            if (File.Exists(FileName))
            {
                File.Delete(FileName);
            }
            else
            {
            }
        }
        public void SaveToFile(string result)
        {
            using (StreamWriter outputFile = new StreamWriter(FileName, true))
            {
                outputFile.WriteLine(result);
            }
        }
        public void WriteData(EnumerableRowCollection<DataRow> collection)
        {
            //
            FileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Load", $"gtrm_{DateTime.Now.ToString("yyyyMMddHHmmss")}.txt");

            //columns
            DataRow columns = collection.FirstOrDefault();
            string columnsdata = "";
            int countcolumns = 0;
            foreach (DataColumn column in columns.Table.Columns)
            {
                columnsdata = countcolumns == 0 ? $"{countcolumns}:{column.ColumnName}|" : $"{columnsdata}{countcolumns}:{column.ColumnName}|";
                countcolumns++;
            }
            this.SaveToFile(columnsdata);


            //raws
            foreach (var gtrm in collection)
            {
                string rawdata = "";
                int countitem = 0;

                foreach (var customer in gtrm.ItemArray)
                {
                    rawdata = countitem == 0 ? $"{customer.ToString().Replace("|", " ")}|" : $"{rawdata}{customer.ToString().Replace("|", " ")}|";
                    countitem++;
                }
                this.SaveToFile(rawdata);
            }
        }
        public void WriteData(EnumerableRowCollection<DataRow> collection, string filename)
        {
            //
            FileName = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Load", $"gtrm_{filename}_{DateTime.Now.ToString("yyyyMMddHHmmss")}.txt");
            //
            myInformator.Send($"Сохранение данных для: {FileName}");

            //columns
            DataRow columns = collection.FirstOrDefault();
            string columnsdata = "";
            int countcolumns = 0;
            foreach (DataColumn column in columns.Table.Columns)
            {
                columnsdata = countcolumns == 0 ? $"{countcolumns}:{column.ColumnName}|" : $"{columnsdata}{countcolumns}:{column.ColumnName}|";
                countcolumns++;
            }
            this.SaveToFile(columnsdata);


            //raws
            foreach (var gtrm in collection)
            {
                string rawdata = "";
                int countitem = 0;

                foreach (var customer in gtrm.ItemArray)
                {
                    rawdata = countitem == 0 ? $"{customer.ToString().Replace("|", " ")}|" : $"{rawdata}{customer.ToString().Replace("|", " ")}|";
                    countitem++;
                }
                this.SaveToFile(rawdata);
            }
        }

        public List<OTSInfoNotEq> LoadNotEq()
        {
            List<OTSInfoNotEq> list = new List<OTSInfoNotEq>();

            foreach (var dir in Directory.GetFiles(CatalogLoad, FileLoad))
            {
                using (var fs = new FileStream(dir, FileMode.Open))
                {
                    using (BinaryReader reader = new BinaryReader(fs, Encoding.Default))
                    {
                        HandlerBigFile handler = new HandlerBigFile(fs);
                        ConverterData converter = new ConverterData();
                        while (handler.fEOF == 0)
                        {
                            string[] resultStr = handler.GetStr(reader).Split('|');//получить текущую строку из файла
                            if (handler.CountRows > 1 && handler.fEOF == 0)
                            {
                                //OTSInfoNotEq data = converter.GetNotEq(resultStr, 1);
                                //list.Add(data);
                            }
                        }
                    }
                }
            }
            return list;
        }
        public void Load()
        {
            foreach (var dir in Directory.GetFiles(CatalogLoad))
            {
                using (var fs = new FileStream(dir, FileMode.Open))
                {
                    using (BinaryReader reader = new BinaryReader(fs, Encoding.Default))
                    {
                        myInformator.Send($"Загрузка файла: {Path.GetFileName(dir)} Размер:{fs.Length} байт");

                        if (Path.GetFileName(dir).Contains("gtrm_noteq") == true)
                        {
                            int id = this.SaveKey(dir);
                            List<OTSInfoNotEq> coll_noteq = GetNotEq(fs, reader, id);
                            RepositoryOTSInfoNotEq repository = new RepositoryOTSInfoNotEq();
                            //repository.TruncateOTSInfoNotEq();
                            repository.Save(coll_noteq);
                        }
                        else if (Path.GetFileName(dir).Contains("gtrm_eq") == true)
                        {
                            int id = this.SaveKey(dir);
                            List<OTSInfoEq> coll_eq = GetEq(fs, reader, id);
                            RepositoryOTSInfoEq repository = new RepositoryOTSInfoEq();
                            //repository.Truncate();
                            repository.Save(coll_eq);
                        }
                    }
                }
                this.ToArc(dir);
            }
        }
        int SaveKey(string dir)
        {
            ProtocolLoad pl = new ProtocolLoad() { FileName = Path.GetFileName(dir), DateFrom = DateTime.Parse(conf.GetSetting("DateFrom")), DateTo = DateTime.Parse(conf.GetSetting("DateTo")), DateLoad = DateTime.Now };
            repPL.Add(pl);
            List<sp_GetListIDProtocolLoad_Result> listid = repPL.GetId(pl);
            if (listid.Count() == 1) return ((sp_GetListIDProtocolLoad_Result)listid.First()).id;
            else myInformator.Send($"Получена больше чем одно ключевое поле [ProtocolLoad].[id]");

            throw new Exception("Получена больше чем одно ключевое поле [ProtocolLoad].[id]");
        }
        void ToArc(string sourсefile)
        {
            string sourceFile = $"{sourсefile}";

            string destFile = $"{Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Arc", Path.GetFileName(sourceFile))}";
            try
            {
                File.Move(sourceFile, destFile);
                myInformator.Send($"Файл {Path.GetFileName(sourceFile)} перемещен в {destFile}");
            }
            catch (Exception ex)
            {
                myInformator.Send($"При перемещение файла {sourceFile} в {destFile} возникла ошибка {ex.Message}");
            }
        }
        public List<OTSInfoNotEq> GetNotEq(FileStream fs, BinaryReader reader, int id)
        {
            List<OTSInfoNotEq> list = new List<OTSInfoNotEq>();
            HandlerBigFile handler = new HandlerBigFile(fs);
            ConverterData converter = new ConverterData();
            while (handler.fEOF == 0)
            {
                string[] resultStr = handler.GetStr(reader).Split('|');//получить текущую строку из файла
                if (handler.CountRows > 1 && handler.fEOF == 0)
                {
                    OTSInfoNotEq data = converter.GetNotEq(resultStr, id);
                    list.Add(data);
                }
            }
            return list;
        }
        public List<OTSInfoEq> GetEq(FileStream fs, BinaryReader reader, int id)
        {
            List<OTSInfoEq> list = new List<OTSInfoEq>();
            HandlerBigFile handler = new HandlerBigFile(fs);
            ConverterData converter = new ConverterData();
            while (handler.fEOF == 0)
            {
                string[] resultStr = handler.GetStr(reader).Split('|');//получить текущую строку из файла
                if (handler.CountRows > 1 && handler.fEOF == 0)
                {
                    OTSInfoEq data = converter.GetEq(resultStr, id);
                    list.Add(data);
                }
            }
            return list;
        }
        public List<OTSInfoEq> LoadEq()
        {
            List<OTSInfoEq> list = new List<OTSInfoEq>();

            foreach (var dir in Directory.GetFiles(CatalogLoad, FileLoad))
            {
                using (var fs = new FileStream(dir, FileMode.Open))
                {
                    using (BinaryReader reader = new BinaryReader(fs, Encoding.Default))
                    {
                        HandlerBigFile handler = new HandlerBigFile(fs);
                        ConverterData converter = new ConverterData();
                        while (handler.fEOF == 0)
                        {
                            string[] resultStr = handler.GetStr(reader).Split('|');//получить текущую строку из файла
                            if (handler.CountRows > 1 && handler.fEOF == 0)
                            {
                                //OTSInfoEq data = converter.GetEq(resultStr);
                                //list.Add(data);
                            }
                        }
                    }
                }
            }
            return list;
        }
    }
}
