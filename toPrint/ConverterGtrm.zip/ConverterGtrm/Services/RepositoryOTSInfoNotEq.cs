﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Linq;
using ConverterGtrm.Core;
//using System.Collections.Generic;
//using System.Configuration;
//using System.Data.Entity.Core.EntityClient;
//using System.Data.SqlClient;

using ConverterGtrm.Services.Interfaces;



namespace ConverterGtrm.Services
{
    public class RepositoryOTSInfoNotEq : IRepositoryOTSInfoNotEq<GTRMInfoEntities>
    {
        GTRMInfoEntities db;
        int MAXCOUNT = 2097152;
        //int MAXCOUNT = 1;


        public RepositoryOTSInfoNotEq()
        {
            db = new GTRMInfoEntities();
        }

        public void Add(OTSInfoNotEq data)
        {
            db.OTSInfoNotEq.Add(data);
            this.Save();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            db.SaveChanges();
        }

        public void Save<TEntity>(List<TEntity> collection) where TEntity : class
        {
            string connectionstring = ConfigurationManager.ConnectionStrings["GTRMInfoEntities"].ConnectionString;
            string provider = new EntityConnectionStringBuilder(connectionstring).ProviderConnectionString;
            using (var loader = new System.Data.SqlClient.SqlBulkCopy(provider, SqlBulkCopyOptions.Default) { DestinationTableName = "OTSInfoNotEq", BatchSize = collection.Count, BulkCopyTimeout = 100000 })
            {
                DataTable table = new DataTable();
                PropertyDescriptor[] columns = TypeDescriptor.GetProperties(typeof(TEntity)).Cast<PropertyDescriptor>().Where(propertyInfo => propertyInfo.PropertyType.Namespace.Equals("System")).ToArray();
                SqlConnection con = new SqlConnection(provider);
                con.Open();
                foreach (var column in columns)
                {
                    loader.ColumnMappings.Add(column.Name, column.Name);
                    table.Columns.Add(column.Name, Nullable.GetUnderlyingType(column.PropertyType) ?? column.PropertyType);
                }
                con.Close();
                object[] values = new object[columns.Length];

                //var length = 0;
                var countitem = 0;

                foreach (var item in collection)
                {
                    countitem++;
                    myInformator.SendConsole($"Подготовка к загрузке: {countitem} Выполнено: {countitem * 100 / collection.Count()}%");

                    for (var i = 0; i < values.Length; i++)
                    {
                        values[i] = columns[i].GetValue(item);
                    }
                    if (table.Rows.Count == MAXCOUNT)//контроль max значения 2097152
                    {
                        loader.WriteToServer(table);
                        //
                        table.Rows.Clear();
                    }
                    table.Rows.Add(values);
                }
                if (table.Rows.Count > 0)
                {
                    Console.WriteLine("");
                    myInformator.Send($"Загрузка...");
                    loader.WriteToServer(table);
                    Console.Write("");
                    myInformator.Send($"Загрузка... выполнена.");

                }
                loader.Close();
            }
        }
        public void TruncateOTSInfoNotEq()
        {
            myInformator.Send($"Подготовка БД к загрузке...");

            db.Database.ExecuteSqlCommand("TRUNCATE TABLE [dbo].[OTSInfoNotEq]");
        }

    }
}
