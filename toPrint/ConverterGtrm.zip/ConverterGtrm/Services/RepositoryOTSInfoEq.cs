﻿using ConverterGtrm.Core;
using ConverterGtrm.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConverterGtrm.Services
{
    public class RepositoryOTSInfoEq : IRepositoryOTSInfo<OTSInfoEq>
    {
        GTRMInfoEntities db;
        string connectionstring;
        string provider;


        public RepositoryOTSInfoEq()
        {
            db = new GTRMInfoEntities();
            connectionstring = ConfigurationManager.ConnectionStrings["GTRMInfoEntities"].ConnectionString;
            provider = new EntityConnectionStringBuilder(connectionstring).ProviderConnectionString;
        }
        public void Add(OTSInfoEq data)
        {
            db.OTSInfoEq.Add(data);
            this.Save();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            db.SaveChanges();
        }

        public void Save<TEntity>(List<TEntity> list) where TEntity : class
        {
            DataTable table;
            PropertyDescriptor[] columns;
            using (var loader = this.SetSqlBulk(list, out table, out columns))
            {
                object[] values = new object[columns.Length];
                var countitem = 0;
                foreach (var item in list)
                {
                    countitem++;
                    myInformator.SendConsole($"Подготовка к загрузке: {countitem} Выполнено: {countitem * 100 / list.Count()}%");

                    for (var i = 0; i < values.Length; i++)
                    {
                        values[i] = columns[i].GetValue(item);
                    }
                    if (table.Rows.Count == 2097152)//контроль max значения
                    {
                        loader.WriteToServer(table);
                        //
                        table.Rows.Clear();
                    }
                    table.Rows.Add(values);
                }
                if (table.Rows.Count > 0)
                {
                    Console.WriteLine("");
                    myInformator.Send($"Загрузка...");
                    loader.WriteToServer(table);
                    Console.Write("");
                    myInformator.Send($"Загрузка... выполнена.");
                }
                loader.Close();
            }
        }

        public System.Data.SqlClient.SqlBulkCopy SetSqlBulk<TEntity>(List<TEntity> list, out DataTable table, out PropertyDescriptor[] columnsout) where TEntity : class
        {
            var loader = new System.Data.SqlClient.SqlBulkCopy(provider, SqlBulkCopyOptions.Default) { DestinationTableName = "OTSInfoEq", BatchSize = list.Count, BulkCopyTimeout = 100000 };
            table = new DataTable();
            PropertyDescriptor[] columns = TypeDescriptor.GetProperties(typeof(OTSInfoEq)).Cast<PropertyDescriptor>().Where(propertyInfo => propertyInfo.PropertyType.Namespace.Equals("System")).ToArray();
            SqlConnection con = new SqlConnection(provider);
            con.Open();
            foreach (var column in columns)
            {
                loader.ColumnMappings.Add(column.Name, column.Name);
                table.Columns.Add(column.Name, Nullable.GetUnderlyingType(column.PropertyType) ?? column.PropertyType);
            }
            con.Close();
            columnsout = columns;
            return loader;
        }

        public void Truncate()
        {
            myInformator.Send($"Подготовка БД к загрузке...");

            db.Database.ExecuteSqlCommand("TRUNCATE TABLE [dbo].[OTSInfoEq]");
        }

    }
}
