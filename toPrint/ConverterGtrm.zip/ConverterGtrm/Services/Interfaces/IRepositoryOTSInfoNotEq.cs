﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;

namespace ConverterGtrm.Services.Interfaces
{
    interface IRepositoryOTSInfoNotEq<T> : IDisposable where T : class
    {
        void Save();
        void Save<TEntity>(List<TEntity> list) where TEntity : class;
        void Add(OTSInfoNotEq data);
        void TruncateOTSInfoNotEq();
    }
}
