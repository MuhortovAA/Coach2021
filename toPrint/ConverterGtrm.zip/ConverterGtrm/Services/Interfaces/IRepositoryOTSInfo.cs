﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConverterGtrm.Services.Interfaces
{
    interface IRepositoryOTSInfo<T> : IDisposable where T : class
    {
        void Save();
        void Save<TEntity>(List<TEntity> list) where TEntity : class;
        void Add(T data);
        void Truncate();
        System.Data.SqlClient.SqlBulkCopy SetSqlBulk<TEntity>(List<TEntity> list, out DataTable table, out PropertyDescriptor[] columnsout) where TEntity : class;
    }
}
