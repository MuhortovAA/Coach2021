﻿using ConverterGtrm.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConverterGtrm.Services
{
    public class RepositoryProtocolLoad : IRepositoryProtocolLoad<ProtocolLoad>
    {
        GTRMInfoEntities db;

        public RepositoryProtocolLoad()
        {
            db = new GTRMInfoEntities();
        }
        public void Add(ProtocolLoad data)
        {
            db.ProtocolLoad.Add(data);
            this.Save();
        }

        public void Delete(ProtocolLoad data)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public List<sp_GetListIDProtocolLoad_Result> GetId(ProtocolLoad data)
        {
            List<sp_GetListIDProtocolLoad_Result> id = db.sp_GetListIDProtocolLoad(data.FileName, data.DateLoad, data.DateFrom, data.DateTo).ToList();
            return id;
        }

        public void Save()
        {
            db.SaveChanges();
        }

        public void Truncate()
        {
            throw new NotImplementedException();
        }

        public void Update(ProtocolLoad data)
        {
            throw new NotImplementedException();
        }
    }
}
