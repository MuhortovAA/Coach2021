﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConverterGtrm.Core
{
    public class ConverterData
    {
        public ConverterData()
        {

        }

        public OTSInfoNotEq GetNotEq(string[] result, int id)
        {
            OTSInfoNotEq data = new OTSInfoNotEq();
            data.IdPLoad = id;//id record table ProtocolLoad
            data.NAME_KL = ConvertUTF8toStr(result[0]);
            data.FILIAL = result[1];
            data.BANK_SUPP = result[2];
            data.YES_NO_EQ = Convert.ToInt32(result[3]) == 0 ? false : true; ;
            data.UNN_KL = result[4];
            data.UNN_BRUSNICHKA = result[5];
            data.NUM_DOC = ConvertUTF8toStr(result[6]);
            data.BONUS_PROG_TYPE = ConvertUTF8toStr(result[7]);
            data.SHTRIH_DISCOUNT = ConvertUTF8toStr(result[8]);
            data.BONUS_DOG_NAME = ConvertUTF8toStr(result[9]);
            data.DATEBOUNSDOG = string.IsNullOrWhiteSpace(result[10]) ? (DateTime?)null : Convert.ToDateTime(result[10]).Date;
            data.MCC = result[11];
            data.MID = result[12];
            data.DOP_INFO = result[13];
            data.GTRMBOUNSDOGDATE = Convert.ToDateTime(result[14]);
            data.BPCDATE = string.IsNullOrWhiteSpace(result[15]) ? (DateTime?)null : Convert.ToDateTime(result[15]).Date;
            data.OFFER_STARTDATE = string.IsNullOrWhiteSpace(result[16]) ? (DateTime?)null : Convert.ToDateTime(result[16]).Date;
            data.OFFER_ENDDATE = string.IsNullOrWhiteSpace(result[17]) ? (DateTime?)null : Convert.ToDateTime(result[17]).Date;
            data.OFFER_TERM = result[18];
            data.BONUS_CLOSE_DATE = string.IsNullOrWhiteSpace(result[19]) ? (DateTime?)null : Convert.ToDateTime(result[19]).Date;
            data.GTRM_BONUS_CLOSE_DATE = string.IsNullOrWhiteSpace(result[20]) ? (DateTime?)null : Convert.ToDateTime(result[20]).Date;
            data.CARD = result[21];
            data.CARD_REZ = result[22];
            data.CARD_NEREZ = result[23];
            data.BONUSPERCENT_SUMM = string.IsNullOrWhiteSpace(result[24]) ? (decimal?)null : Convert.ToDecimal(result[24]);
            data.CASH_BACK = Convert.ToDecimal(result[25]);
            data.INSTALLMENT_TERM = Convert.ToDecimal(result[26]);
            data.BONUSPERCENT = Convert.ToDecimal(result[27]);
            data.OTS_FULL_NAME = ConvertUTF8toStr(result[28]);
            data.SHTRIH_PROGS = result[29];
            data.BINS = result[30];
            data.BONUSNAME = ConvertUTF8toStr(result[31]);
            data.JUST_BONUSNAME = ConvertUTF8toStr(result[32]);
            data.BONUS_ID = Convert.ToInt32(result[33]);
            data.OBL = ConvertUTF8toStr(result[34]);
            data.REGION = ConvertUTF8toStr(result[35]);
            data.TYPE_POINT = ConvertUTF8toStr(result[36]);
            data.POINT = ConvertUTF8toStr(result[37]);
            data.TYPE_STREET = ConvertUTF8toStr(result[38]);
            data.STREET = ConvertUTF8toStr(result[39]);
            data.HOME = ConvertUTF8toStr(result[40]);
            data.CATEGORIES = result[41];
            data.WEBPAGE = "";// result[42];
            data.E_MAIL = result[43];
            data.BONUS_LINK = result[44];
            data.OTS_BANKS = ConvertUTF8toStr(result[45]);
            data.OTS_ACCOUNTS = result[46];
            data.OTS_BIC_SWIFTS = result[47];
            data.BD_IBAN_ACCOUNT = result[48];
            data.SHTRAF = string.IsNullOrWhiteSpace(result[49]) ? (decimal?)null : Convert.ToDecimal(result[49].Replace(".", ","));
            data.EMAIL_VIPISKA = result[50];
            data.OTSINFO = ConvertUTF8toStr(result[51]);
            data.DOPINFO = ConvertUTF8toStr(result[52]);
            data.KOR1 = string.IsNullOrWhiteSpace(result[53]) ? (decimal?)null : Convert.ToDecimal(result[53]);
            data.KOR2 = string.IsNullOrWhiteSpace(result[54]) ? (decimal?)null : Convert.ToDecimal(result[54]);
            data.KOR3 = string.IsNullOrWhiteSpace(result[55]) ? (decimal?)null : Convert.ToDecimal(result[55]);
            data.KOR4 = string.IsNullOrWhiteSpace(result[56]) ? (decimal?)null : Convert.ToDecimal(result[56]);
            data.KOR5 = string.IsNullOrWhiteSpace(result[57]) ? (decimal?)null : Convert.ToDecimal(result[57]);
            data.KOR6 = string.IsNullOrWhiteSpace(result[58]) ? (decimal?)null : Convert.ToDecimal(result[58]);
            data.KOR_SHIROTA = result[59];
            data.KOR_DOLGOTA = result[60];
            data.FULL_ADRESS = ConvertUTF8toStr(result[61]);

            return data;
        }


        public OTSInfoEq GetEq(string[] result, int id)
        {
            OTSInfoEq data = new OTSInfoEq();
            data.IdPLoad = id;
            data.NAME_KL = ConvertUTF8toStr(result[0]);
            data.FILIAL = result[1];
            data.BANK_SUPP = result[2];
            data.YES_NO_EQ = Convert.ToInt32(result[3]) == 0 ? false : true; ;
            data.UNN_KL = result[4];
            data.UNN_BRUSNICHKA = result[5];
            data.NUM_DOC = ConvertUTF8toStr(result[6]);
            data.BONUS_PROG_TYPE = ConvertUTF8toStr(result[7]);
            data.SHTRIH_DISCOUNT = ConvertUTF8toStr(result[8]);
            data.BONUS_DOG_NAME = ConvertUTF8toStr(result[9]);
            data.DATEBOUNSDOG = string.IsNullOrWhiteSpace(result[10]) ? (DateTime?)null : Convert.ToDateTime(result[10]).Date;
            data.MCC = result[11];
            data.MID = result[12];
            data.DOP_INFO = result[13];
            data.GTRMBOUNSDOGDATE = Convert.ToDateTime(result[14]);
            data.OFFER_STARTDATE = string.IsNullOrWhiteSpace(result[15]) ? (DateTime?)null : Convert.ToDateTime(result[15]).Date;
            data.OFFER_ENDDATE = string.IsNullOrWhiteSpace(result[16]) ? (DateTime?)null : Convert.ToDateTime(result[16]).Date;
            data.OFFER_TERM = result[17];
            data.BONUS_CLOSE_DATE = string.IsNullOrWhiteSpace(result[18]) ? (DateTime?)null : Convert.ToDateTime(result[18]).Date;
            data.GTRM_BONUS_CLOSE_DATE = string.IsNullOrWhiteSpace(result[19]) ? (DateTime?)null : Convert.ToDateTime(result[19]).Date;
            data.CARD = result[20];
            data.CARD_REZ = result[21];
            data.CARD_NEREZ = result[22];
            data.BONUSPERCENT_SUMM = string.IsNullOrWhiteSpace(result[23].Replace(".", ",")) ? (decimal?)null : Convert.ToDecimal(result[23].Replace(".", ","));
            data.BPCDATE = string.IsNullOrWhiteSpace(result[24]) ? (DateTime?)null : Convert.ToDateTime(result[24]).Date;
            data.CASH_BACK = string.IsNullOrWhiteSpace(result[25].Replace(".", ",")) ? (decimal?)null : Convert.ToDecimal(result[25].Replace(".", ","));
            data.INSTALLMENT_TERM = string.IsNullOrWhiteSpace(result[26].Replace(".", ",")) ? (decimal?)null : Convert.ToDecimal(result[26].Replace(".", ","));
            data.BONUSPERCENT = string.IsNullOrWhiteSpace(result[27].Replace(".", ",")) ? (decimal?)null : Convert.ToDecimal(result[27].Replace(".", ","));
            data.OTS_FULL_NAME = ConvertUTF8toStr(result[28]);
            data.SHTRIH_PROGS = result[29];
            data.BINS = result[30];
            data.BONUSNAME = ConvertUTF8toStr(result[31]);
            data.JUST_BONUSNAME = ConvertUTF8toStr(result[32]);
            data.BONUS_ID = Convert.ToInt32(result[33]);
            data.OBL = ConvertUTF8toStr(result[34]);
            data.REGION = ConvertUTF8toStr(result[35]);
            data.TYPE_POINT = ConvertUTF8toStr(result[36]);
            data.POINT = ConvertUTF8toStr(result[37]);
            data.TYPE_STREET = ConvertUTF8toStr(result[38]);
            data.STREET = ConvertUTF8toStr(result[39]);
            data.HOME = "";// ConvertUTF8toStr(result[40]);
            data.CATEGORIES =  ConvertUTF8toStr(result[41]);
            data.WEBPAGE = ConvertUTF8toStr(result[42]);
            data.E_MAIL = ConvertUTF8toStr(result[43]);
            data.BONUS_LINK = ConvertUTF8toStr(result[44]);
            data.OTS_BANKS = ConvertUTF8toStr(result[45]);
            data.OTS_ACCOUNTS = result[46];
            data.OTS_BIC_SWIFTS = result[47];
            data.BD_IBAN_ACCOUNT = result[48];
            data.SHTRAF = string.IsNullOrWhiteSpace(result[49]) ? (decimal?)null : Convert.ToDecimal(result[49].Replace(".", ","));
            data.EMAIL_VIPISKA = result[50];
            data.OTSINFO = ConvertUTF8toStr(result[51]);
            data.DOPINFO = ConvertUTF8toStr(result[52]);
            data.KOR1 = string.IsNullOrWhiteSpace(result[53]) ? (decimal?)null : Convert.ToDecimal(result[53]);
            data.KOR2 = string.IsNullOrWhiteSpace(result[54]) ? (decimal?)null : Convert.ToDecimal(result[54]);
            data.KOR3 = string.IsNullOrWhiteSpace(result[55]) ? (decimal?)null : Convert.ToDecimal(result[55]);
            data.KOR4 = string.IsNullOrWhiteSpace(result[56]) ? (decimal?)null : Convert.ToDecimal(result[56]);
            data.KOR5 = string.IsNullOrWhiteSpace(result[57]) ? (decimal?)null : Convert.ToDecimal(result[57]);
            data.KOR6 = string.IsNullOrWhiteSpace(result[58]) ? (decimal?)null : Convert.ToDecimal(result[58]);
            data.KOR_SHIROTA = result[59];
            data.KOR_DOLGOTA = result[60];
            data.FULL_ADRESS = ConvertUTF8toStr(result[61]);
            data.TERMINAL_EXISTS= ConvertUTF8toStr(result[62]);

            return data;
        }
        private string ConvertUTF8toStr(string str)
        {
            byte[] bytes = Encoding.Default.GetBytes(str);
            string result = Encoding.UTF8.GetString(bytes);
            return result;
        }
    }
}
