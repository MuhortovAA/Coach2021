﻿using ConverterGtrm.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConverterGtrm.Core
{
    public class ServiceLayer
    {
        OracleDB oracle;
        FileService fs;
        ConfigApp conf;

        public ServiceLayer()
        {
            conf = new ConfigApp();
            if (null == conf.GetSetting("LoadDataFromOracle")) conf.AddUpdateAppSettings("LoadDataFromOracle", "True");
            if (null == conf.GetSetting("SaveDataToMSSQL")) conf.AddUpdateAppSettings("SaveDataToMSSQL", "True");
            oracle = new OracleDB();
            fs = new FileService();
        }
        public void ParseData()
        {

            bool oracleflag = bool.Parse(conf.GetSetting("LoadDataFromOracle") ?? "True");
            bool mssqlflag = bool.Parse(conf.GetSetting("SaveDataToMSSQL") ?? "True");


            if (oracleflag)
            {

                //eq
                EnumerableRowCollection<DataRow> coll_eq = oracle.GetData("NOT_EQ_OTS_InFO");
                fs.WriteData(coll_eq, "noteq");

                //not_eq
                EnumerableRowCollection<DataRow> coll_not_eq = oracle.GetData("EQ_OTS_InFO");
                fs.WriteData(coll_not_eq, "eq");

            }
            else myInformator.Send($"LoadDataFromOracle = False загрузка данных отключена");

            if (mssqlflag)
            {
                //eq
                //not_eq
                fs.Load();
            }
            else
            {
                myInformator.Send($"SaveDataToMSSQL = False загрузка данных отключена");
            }

        }
    }
}
