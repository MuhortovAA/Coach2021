﻿using BPCParcer.Core;
using BPCParcer.Services;
using System;
using System.Reflection;

namespace BPCParcer
{
    class Program
    {
        static void Main(string[] args)
        {

            myInformator.Send("Старт программы");
            var version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            string Description = ((AssemblyDescriptionAttribute)Attribute.GetCustomAttribute(Assembly.GetExecutingAssembly(), typeof(AssemblyDescriptionAttribute), false)).Description;
            myInformator.Send($"Текущая версия {version.Major}.{version.Minor}.{version.Build}.{version.Revision} {Description}");
            //Console.ReadLine();
            Import();
            //Console.ReadLine();

            myInformator.Send4($"Нажмите любую клавишу для выхода!");
            Console.ReadLine();

        }
        private static void Import()
        {
            try
            {

                FileService fs = new FileService();
                fs.LoadFile();
            }
            catch (Exception ex)
            {
                myInformator.Send2($"Exception: {ex.InnerException} {ex.Message}");
            }
        }
    }
}
