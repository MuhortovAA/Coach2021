﻿using System.IO;
using System.Text;

namespace BPCParcer.Core
{
    public class HandlerBigFile
    {
        private FileStream fs { get; set; }
        private int byteRead { get; set; }
        public long fsPosition { get; set; }
        private byte[] buffer;
        private int arrayLength = 1;
        public int vCountChar { get; set; }
        private int countChar { get; set; }
        public int CountRows { get; set; }
        public int fEOF { get; set; }

        public HandlerBigFile(FileStream _fs)
        {
            fs = _fs;
            buffer = new byte[arrayLength];
            fsPosition = 0;
            fEOF = 0;
            CountRows = 0;
        }
        public string GetStr(BinaryReader reader)
        {
            fs.Position = fsPosition;//текущая позиция в файле
            byteRead = reader.Read(buffer, 0, arrayLength);//читаем из файла заданный набор данных
            StringBuilder str = new StringBuilder();
            while (byteRead > 0)//пока не закончится файл
            {
                if (buffer[0].ToString() == "13")//если есть символ перехода строки
                {
                    vCountChar = countChar;//текущее значение символов в строке
                    countChar = 0;//счетчик обнуляем
                    CountRows++;//счетчик записи
                    fsPosition = fs.Position;//текущая позиция в файле после чтения данных
                                             //if (Changed != null) Changed(this, new EventArgs());//событие 

                    Encoding utf8 = Encoding.GetEncoding("UTF-8");
                    Encoding win1251 = Encoding.GetEncoding("Windows-1251");
                    byte[] utf8bytes = win1251.GetBytes(str.ToString());
                    byte[] win1251bytes = Encoding.Convert(utf8, win1251, utf8bytes);
                    string result = win1251.GetString(win1251bytes);//читаем данные дальше
                    return result;
                }
                else
                {
                    countChar++;
                    //str = str + Encoding.GetEncoding("utf-8").GetString(buffer);//читаем данные дальше
                    str.Append(System.Text.Encoding.Default.GetString(buffer));//читаем данные дальше
                }
                byteRead = reader.Read(buffer, 0, arrayLength);
            }
            fEOF = 1;

            return "";
        }
        public string GetStr1251(BinaryReader reader)
        {
            fs.Position = fsPosition;//текущая позиция в файле
            byteRead = reader.Read(buffer, 0, arrayLength);//читаем из файла заданный набор данных
            StringBuilder str = new StringBuilder();
            while (byteRead > 0)//пока не закончится файл
            {
                if (buffer[0].ToString() == "13")//если есть символ перехода строки
                {
                    vCountChar = countChar;//текущее значение символов в строке
                    countChar = 0;//счетчик обнуляем
                    CountRows++;//счетчик записи
                    fsPosition = fs.Position;//текущая позиция в файле после чтения данных
                                             //if (Changed != null) Changed(this, new EventArgs());//событие 

                    Encoding utf8 = Encoding.GetEncoding("UTF-8");
                    Encoding win1251 = Encoding.GetEncoding("Windows-1251");
                    //byte[] utf8bytes = win1251.GetBytes(str.ToString());
                    //byte[] win1251bytes = Encoding.Convert(utf8, win1251, utf8bytes);
                    //string result = win1251.GetString(win1251bytes);//читаем данные дальше
                    string result = str.ToString();
                    return result;
                }
                else
                {
                    countChar++;
                    //str = str + Encoding.GetEncoding("utf-8").GetString(buffer);//читаем данные дальше
                    str.Append(System.Text.Encoding.Default.GetString(buffer));//читаем данные дальше
                }
                byteRead = reader.Read(buffer, 0, arrayLength);
            }
            fEOF = 1;

            return "";
        }
    }
}
