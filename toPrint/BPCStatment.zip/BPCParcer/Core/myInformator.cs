﻿using NLog;
using System;

namespace BPCParcer.Core
{
    public static class myInformator
    {
        public static string GetDataSource()
        {
            //var connectionString = ConfigurationManager.ConnectionStrings["InterChangeEntities"].ConnectionString;
            //var builder = new EntityConnectionStringBuilder(connectionString);
            //var count = 0;
            //foreach (var item in builder.Values)
            //{
            //    count++;
            //    if (count == 4)
            //    {
            //        var cs = new SqlConnectionStringBuilder(item.ToString());
            //        return cs.DataSource;
            //    }

            //}
            return String.Empty;
        }
        public static void Send(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            Console.WriteLine($"{DateTime.Now} {loginfo}");
            logger.Info(loginfo);
        }
        public static void Send2(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            Console.Write($"\r{DateTime.Now} {loginfo}");
            Console.Write("");
            logger.Info(loginfo);
        }
        public static void SendConsole(string loginfo)
        {
            Console.Write($"\r{DateTime.Now} {loginfo}");
        }
        public static void Send4(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            Console.WriteLine();
            Console.Write($"\r{DateTime.Now} {loginfo}");
            logger.Info(loginfo);
        }
    }
}
