﻿using BPCParcer.Core;
using BPCParcer.Services.Interfaces;
using BPCParcer.Services.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPCParcer.Services.Repository
{
    public class RepositoryGtrm : IRepository<GTRM>
    {
        BPCStatementEntities db;
        string connectionstring;
        string provider;

        public RepositoryGtrm()
        {
            db = new BPCStatementEntities();
            connectionstring = ConfigurationManager.ConnectionStrings["BPCStatementEntities"].ConnectionString;
            provider = new EntityConnectionStringBuilder(connectionstring).ProviderConnectionString;
        }

        public void Add(GTRM data)
        {
            throw new NotImplementedException();
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public List<GTRM> GetData()
        {
            throw new NotImplementedException();
        }

        public int GetID(GTRM data)
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            throw new NotImplementedException();
        }

        public void Save<TEntity>(List<TEntity> list) where TEntity : class
        {
            throw new NotImplementedException();
        }

        public void Save<TEntity>(Dictionary<int, Statement> dic) where TEntity : class
        {
            throw new NotImplementedException();
        }

        public void Save3(Dictionary<int, myGtrm> dic)
        {
            DataTable table;
            PropertyDescriptor[] columns;
            using (var loader = this.SetSqlBulk2(dic.Count, out table, out columns))
            {
                object[] values = new object[columns.Length];
                var countitem = 0;
                Console.WriteLine();
                foreach (KeyValuePair<int, myGtrm> item in dic)
                {
                    countitem++;
                    myInformator.SendConsole($"Подготовка к загрузке: {countitem} Выполнено: {countitem * 100 / dic.Count()}%");
                    for (var i = 0; i < values.Length; i++)
                    {
                        var cus = (GTRM)item.Value;
                        values[i] = columns[i].GetValue(cus);
                    }
                    if (table.Rows.Count == 2097152)//контроль max значения
                    {
                        loader.WriteToServer(table);
                        //
                        table.Rows.Clear();
                    }
                    table.Rows.Add(values);
                }
                if (table.Rows.Count > 0)
                {
                    Console.WriteLine("");
                    myInformator.SendConsole($"Загрузка...");
                    loader.WriteToServer(table);
                    Console.Write("");

                    myInformator.SendConsole($"Загрузка... выполнена.");
                }
                loader.Close();
            }
        }

        public void Save2<TEntity>(Dictionary<int, TEntity> dic) where TEntity : class
        {
            throw new NotImplementedException();
        }

        public SqlBulkCopy SetSqlBulk<TEntity>(List<TEntity> list, out DataTable table, out PropertyDescriptor[] columnsout) where TEntity : class
        {
            throw new NotImplementedException();
        }

        public SqlBulkCopy SetSqlBulk<TEntity>(Dictionary<int, Statement> dic, out DataTable table, out PropertyDescriptor[] columnsout) where TEntity : class
        {
            throw new NotImplementedException();
        }

        public SqlBulkCopy SetSqlBulk2(int count, out DataTable table, out PropertyDescriptor[] columnsout)
        {
            var loader = new System.Data.SqlClient.SqlBulkCopy(provider, SqlBulkCopyOptions.Default) { DestinationTableName = nameof(GTRM), BatchSize = count, BulkCopyTimeout = 100000 };
            table = new DataTable();
            var columns = TypeDescriptor.GetProperties(typeof(GTRM)).Cast<PropertyDescriptor>().Where(propertyInfo => propertyInfo.PropertyType.Namespace.Equals("System")).ToArray();
            var con = new SqlConnection(provider);
            con.Open();
            foreach (var column in columns)
            {
                loader.ColumnMappings.Add(column.Name, column.Name);
                table.Columns.Add(column.Name, Nullable.GetUnderlyingType(column.PropertyType) ?? column.PropertyType);
            }
            con.Close();
            columnsout = columns;
            return loader;
        }

        public void Truncate()
        {
            db.Database.ExecuteSqlCommand("TRUNCATE TABLE [BPCStatement].[dbo].[GTRM]");
        }
    }
}
