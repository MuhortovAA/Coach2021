﻿using BPCParcer.Core;
using BPCParcer.Services.Interfaces;
using BPCParcer.Services.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.Entity.Core.EntityClient;
using System.Linq;

namespace BPCParcer.Services.Repository
{
    public class RepositoryGtrm : IBase<myGtrm>
    {
        BPCStatementEntities db;
        string connectionstring;
        string provider;
        DBWork<GTRM> dbwork;


        public RepositoryGtrm()
        {
            dbwork = new DBWork<GTRM>();
            db = new BPCStatementEntities();
            connectionstring = ConfigurationManager.ConnectionStrings["BPCStatementEntities"].ConnectionString;
            provider = new EntityConnectionStringBuilder(connectionstring).ProviderConnectionString;
        }
        public void Truncate()
        {
            db.Database.ExecuteSqlCommand("TRUNCATE TABLE [BPCStatement].[dbo].[GTRM]");
        }

        public void Save(Dictionary<int, myGtrm> dic)
        {
            DataTable table;
            PropertyDescriptor[] columns;
            using (var loader = this.dbwork.SetSqlBulk(dic.Count, provider, out table, out columns))
            {
                object[] values = new object[columns.Length];
                var countitem = 0;
                Console.WriteLine();
                foreach (var item in dic)
                {
                    countitem++;
                    myInformator.SendConsole($"Подготовка к загрузке: {countitem} Выполнено: {countitem * 100 / dic.Count()}%");
                    for (var i = 0; i < values.Length; i++)
                    {
                        GTRM cus = item.Value;
                        values[i] = columns[i].GetValue(cus);
                    }
                    if (table.Rows.Count == 2097152)//контроль max значения
                    {
                        loader.WriteToServer(table);
                        //
                        table.Rows.Clear();
                    }
                    table.Rows.Add(values);
                }
                if (table.Rows.Count > 0)
                {
                    Console.WriteLine("");
                    myInformator.SendConsole($"Загрузка...");
                    loader.WriteToServer(table);
                    Console.Write("");

                    myInformator.SendConsole($"Загрузка... выполнена.");
                }
                loader.Close();
            }
        }

        public void Dispose()
        {
            throw new NotImplementedException();
        }
    }
}
