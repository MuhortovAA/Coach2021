﻿using BPCParcer.Core;
using System;
using System.IO;
using System.Linq;
using System.Text;

namespace BPCParcer.Services
{

    class FileService
    {
        //private static Logger logger = LogManager.GetCurrentClassLogger();
        private string PathLoad = "";
        private string PathLoadGTRM = "";
        private string PathArc = "";


        ConfigApp conf;
        DataService2 ds;
        DataServiceGTRM ds_gtrm;

        public FileService()
        {
            conf = new ConfigApp();
            //conf.AddUpdateAppSettings("PathLoad", "Load");
            //conf.AddUpdateAppSettings("PathLoadGTRM", "LoadGTRM");
            //conf.AddUpdateAppSettings("PathArc", "Arc");

            PathLoad = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, conf.GetSetting("PathLoad") ?? "Load");
            PathLoadGTRM = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, conf.GetSetting("PathLoadGTRM") ?? "LoadGTRM");
            PathArc = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, conf.GetSetting("PathArc") ?? "Arc");
        }
        public void LoadFile()
        {
            #region Statemenets

            //Console.ReadLine();

            myInformator.Send($"Найдено файлов на обоработку: {Directory.GetFiles(PathLoad).Count()}");
            //Console.ReadLine();


            foreach (string dir in Directory.GetFiles(PathLoad/*, FileLoad*/))
            {
                using (FileStream fs = new FileStream(dir, FileMode.Open))
                {
                    //myInformator.Send($"Загрузка файла {PathLoad}\\{FileLoad} Размер:{fs.Length} байт");
                    myInformator.Send($"Загрузка файла {dir} Размер:{fs.Length} байт");

                    using (BinaryReader reader = new BinaryReader(fs, Encoding.Default))
                    {
                        ds = new DataService2();

                        ds.DataProcessing(fs, reader);
                    }

                }
                ds.CommitDate();
                this.ToArcBase(dir, PathArc);//перемещение в архив
            }
            #endregion

            #region GTRM
            myInformator.Send($"Найдено файлов на обоработку: {Directory.GetFiles(PathLoadGTRM).Count()}");

            foreach (string dir in Directory.GetFiles(PathLoadGTRM))
            {
                using (FileStream fs = new FileStream(dir, FileMode.Open))
                {
                    myInformator.Send($"Загрузка файла {dir} Размер:{fs.Length} байт");

                    using (BinaryReader reader = new BinaryReader(fs, Encoding.Default))
                    {
                        ds_gtrm = new DataServiceGTRM();

                        ds_gtrm.DataProcessing(fs, reader);
                    }

                }
                ds_gtrm.CommitDate();

                this.ToArcBase(dir, PathArc);//перемещение в архив
            }
            #endregion

        }
        void ToArcBase(string sourcefile, string patharc)
        {
            string sourceFile = $"{sourcefile}";

            string destFile = $"{Path.Combine(AppDomain.CurrentDomain.BaseDirectory, patharc, Path.GetFileName(sourceFile))}";

            try
            {
                File.Move(sourceFile, destFile);
                myInformator.Send4($"Файл {Path.GetFileName(sourceFile)} перемещен в {destFile}");
            }
            catch (Exception ex)
            {
                myInformator.Send4($"При перемещение файла {sourceFile} в {destFile} возникла ошибка {ex.Message}");
            }
        }
    }
}
