﻿using BPCParcer.Core;
using BPCParcer.Services.Models;
using BPCParcer.Services.Repository;
using System;
using System.Collections.Generic;
using System.IO;

namespace BPCParcer.Services
{
    public class DataServiceGTRM
    {
        RepositoryGtrm rep;
        public Dictionary<int, myGtrm> dic;
        myGtrm data;
        public DataServiceGTRM()
        {
            rep = new RepositoryGtrm();
            dic = new Dictionary<int, myGtrm>();
        }
        public void DataProcessing(FileStream fs, BinaryReader reader)
        {
            HandlerBigFile handler = new HandlerBigFile(fs);
            int iditem = 1;
            while (handler.fEOF == 0)
            {
                string resultStr = handler.GetStr1251(reader);//получить текущую строку из файла
                if (handler.CountRows > 0 && handler.fEOF == 0)
                {
                    myInformator.SendConsole($"Обработка строки: {handler.CountRows} Выполнено: {handler.fsPosition * 100 / fs.Length}%                    ");
                    this.DataControl(resultStr);
                    iditem++;
                }
            }
            myInformator.Send2($"Обработано строк: {handler.CountRows} Выполнено: {fs.Length * 100 / fs.Length}%");

        }
        int countdic = 1;//key for dictionary
        private void DataControl(string resultStr)
        {
            var arr = resultStr.Split(';');


            if (arr.Length == 4)
            {
                try
                {
                    data = new myGtrm();
                    data.unn = arr[0].Trim();
                    data.CustomerName = arr[1].Trim();
                    data.MID = arr[2].Trim();
                    data.email = arr[3].Trim();
                    data.dateDownload = DateTime.Now;
                    //
                    dic.Add(countdic, data);
                    countdic++;
                }
                catch (Exception ex)
                {
                    myInformator.Send2($"Строка: {countdic} ошибка разбора. Exception: {ex.InnerException} {ex.Message}");
                }

            }
        }
        public void CommitDate()
        {
            rep.Truncate();
            rep.Save(dic);
        }
    }
}
