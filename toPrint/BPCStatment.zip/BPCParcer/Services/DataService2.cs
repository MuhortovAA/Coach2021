﻿using BPCParcer.Core;
using BPCParcer.Services.Models;
using BPCParcer.Services.Repository;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace BPCParcer.Services
{
    public class DataService2
    {
        ReposiroryStatement rep;
        public Dictionary<int, Statement> dic;
        Statement data;
        public DataService2()
        {
            rep = new ReposiroryStatement();
            dic = new Dictionary<int, Statement>();
        }

        public void DataProcessing(FileStream fs, BinaryReader reader)
        {
            HandlerBigFile handler = new HandlerBigFile(fs);
            int iditem = 1;
            while (handler.fEOF == 0)
            {
                string resultStr = handler.GetStr(reader);//получить текущую строку из файла
                if (handler.CountRows > 0 && handler.fEOF == 0)
                {
                    myInformator.SendConsole($"Обработка строки: {handler.CountRows} Выполнено: {handler.fsPosition * 100 / fs.Length}%                    ");
                    this.DataControl(resultStr);
                    iditem++;
                }
            }
            myInformator.Send2($"Обработано строк: {handler.CountRows} Выполнено: {fs.Length * 100 / fs.Length}%");

        }
        bool isMerchantID = false;
        int countRow = 0;//количество строк
        int countdic = 1;//key for dictionary
        bool isTotal = false;
        string TypeCard, MerchantID, CustomerName1, CustomerName2 = "";
        DateTime DateOper = default;

        private void DataControl(string str)
        {
            //Type Card
            if (str.Contains("Тип карты:"))
            {
                var index_str = str.IndexOf(":");
                string strtemp = index_str > 0 ? str.Substring(index_str + 1, str.Length - index_str - 1).Trim() : "";
                TypeCard = strtemp;//тип карты
            }
            //Date of
            else if (str.Contains("Посылка:"))
            {
                string[] arr = str.Split('-');
                var year = arr[1];
                var month = arr[2];
                var day = arr[3];
                DateOper = Convert.ToDateTime($"{year}.{month}.{day}");
            }
            //MerchantId
            else if (str.Contains("Клиент:"))
            {
                string[] arr = str.Split(' ');
                MerchantID = arr[1];
                isMerchantID = true;
                countRow = 1;
            }
            //Customer Name
            else if (isMerchantID && countRow == 1)
            {
                var index_str = str.IndexOf("Счет:");
                var strtemp = index_str > 0 ? str.Substring(0, index_str).Trim() : "";
                string[] arr = strtemp.Split('/');
                CustomerName1 = arr[0].Trim(); // Customer1
                CustomerName2 = arr.Count() == 2 ? arr[1].Trim() : ""; //Customer2
                countRow++;
            }
            //SHG
            else if (isMerchantID && countRow > 1)
            {
                if (!str.Contains("--") && (!str.Contains("Счет:")))
                {
                    string[] arrtmp = str.Split(' ');
                    string[] arr = this.Uptimization(arrtmp).ToArray();
                    if (arr.Count() < 7)
                    {
                        CustomerName2 = CustomerName2 + str.Trim();
                    }
                    else
                    {
                        string Number = "";
                        DateTime? DateTr = default;
                        int CountTr = 0;
                        decimal SumTr1 = default;
                        decimal SumTr2 = default;
                        decimal SumTr3 = default;
                        string ISOTr = "";
                        if (!isTotal)
                        {
                            try
                            {
                                Number = arr[0]; // номер устройства
                                DateTr = DateTime.Parse(arr[1]); // дата транзакции
                                CountTr = Int32.Parse(arr[2]); // количество
                                SumTr1 = Decimal.Parse(arr[3].Replace('.', ',')); // сумма1
                                SumTr2 = Decimal.Parse(arr[4].Replace('.', ',')); // сумма2
                                SumTr3 = Decimal.Parse(arr[5].Replace('.', ',')); // сумма3
                                ISOTr = arr[6];
                            }
                            catch (Exception ex)
                            {
                                myInformator.Send2($"Строка: {str.Trim()} ошибка разбора. Exception: {ex.InnerException} {ex.Message}");
                                CustomerName2 = CustomerName2 + str.Trim();
                                myInformator.Send2($"Добавлена к названию клиента: {data.Name2}                                      ");

                            }
                        }
                        else if (isTotal)
                        {
                            DateTr = null;
                            CountTr = Int32.Parse(arr[3]); // количество
                            SumTr1 = Decimal.Parse(arr[4].Replace('.', ',')); // сумма1
                            SumTr2 = Decimal.Parse(arr[5].Replace('.', ',')); // сумма2
                            SumTr3 = Decimal.Parse(arr[6].Replace('.', ',')); // сумма3
                            ISOTr = arr[7];
                            ////
                            isTotal = false; // флаг итоговой строки
                            isMerchantID = false; // флаг код оборудования
                            countRow = 0; // счетчик количества строк по клиенту 
                        }
                        countRow++; // количество строк
                        data = new Statement()
                        {
                            Name1 = this.CustomerName1,
                            Name2 = this.CustomerName2,
                            TypeCard = this.TypeCard,
                            MerchantId = this.MerchantID,
                            isTotal = isTotal,
                            Device = Number.Length > 7 ? Number?.Substring(0, 8) : Number,
                            Count = CountTr,
                            DateOper= DateOper,
                            DateShift = DateTr,
                            Sum1 = SumTr1,
                            Sum2 = SumTr2,
                            Sum3 = SumTr3,
                            ISO = ISOTr
                        };

                        dic.Add(countdic, data); // add new record
                        countdic++;
                    }
                }
                else if (str.Contains("--"))
                {
                    isTotal = true; // итоговая строка с суммой 
                }
                else if (str.Contains("Счет:"))
                {
                    var index_str = str.IndexOf("Счет:");
                    var strtemp = index_str > 0 ? str.Substring(0, index_str).Trim() : "";
                    string[] arr = strtemp.Split('/');
                    string CustomerName1 = arr[0].Trim(); // Customer1
                    string CustomerName2 = arr.Count() == 2 ? arr[1].Trim() : ""; //Customer2
                    countRow++;
                    //add data to customer
                    data.Name1 = data.Name1 + CustomerName1;
                    data.Name2 = data.Name2 + CustomerName2;
                }

            }
            if (isTotal && !str.Contains("--"))
            {
                isTotal = false; // флаг итоговой строки
                isMerchantID = false; // флаг код оборудования
                countRow = 0; // счетчик количества строк по клиенту
            }
        }/// <summary>
         /// its delete spaces
         /// </summary>
         /// <param name="arr"></param>
         /// <returns></returns>
        List<string> Uptimization(string[] arr)
        {
            List<string> newarr = new List<string>();
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i].Trim() != "") newarr.Add(arr[i]);
            }
            return newarr;
        }
        public void CommitDate()
        {
            //rep.Truncate();
            rep.Save(dic);
            //repCust.Truncate();
            //repCust.Save<Customers>(dicCustomers);
            //dicCustomers = repCust.AddCustomerId(dicCustomers);//получаем CustomerId


            ////repTrans.Truncate();
            //repTrans.Save<Transactions>(dicCustomers);
        }
    }
}
