﻿using System;

namespace BPCParcer.Services.Models
{
    public class Statement
    {
        public static explicit operator Statement(Statements vc)
        {
            return new Statement()
            {
                Id = vc.Id,
                MerchantId = vc.MerchantId,
                Name1 = vc.Name1,
                Name2 = vc.Name2,
                DateOper = vc.DateOper,
                DateShift = vc.DateShift,
                Device = vc.Device,
                Count = vc.Count,
                TypeCard = vc.TypeCard,
                Sum1 = vc.Sum1,
                Sum2 = vc.Sum2,
                Sum3 = vc.Sum3,
                ISO = vc.ISO
            };

        }
        public static implicit operator Statements(Statement vc)
        {
            return new Statements()
            {
                //Id = vc.Id,
                MerchantId = vc.MerchantId,
                Name1 = vc.Name1,
                Name2 = vc.Name2,
                DateOper=vc.DateOper,
                DateShift = vc.DateShift,
                Device = vc.Device,
                Count = vc.Count,
                TypeCard = vc.TypeCard,
                Sum1 = vc.Sum1,
                Sum2 = vc.Sum2,
                Sum3 = vc.Sum3,
                ISO = vc.ISO,
                DateLoad = DateTime.Now
            };

        }
        public int Id { get; set; }
        public string MerchantId { get; set; }
        public string TypeCard { get; set; }
        public string Name1 { get; set; }
        public string Name2 { get; set; }
        public string Device { get; set; }
        public DateTime? DateOper { get; set; }
        public DateTime? DateShift { get; set; }
        public int? Count { get; set; }
        public decimal? Sum1 { get; set; }
        public decimal? Sum2 { get; set; }
        public decimal? Sum3 { get; set; }
        public string ISO { get; set; }
        public bool isTotal { get; set; }
    }
}
