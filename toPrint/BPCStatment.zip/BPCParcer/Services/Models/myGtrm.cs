﻿using System;

namespace BPCParcer.Services.Models
{
    public class myGtrm
    {
        public static explicit operator myGtrm(GTRM vc)
        {
            return new myGtrm()
            {
                CustomerName = vc.CustomerName,
                dateDownload = vc.dateDownload,
                email = vc.email,
                MID = vc.MID,
                unn = vc.UNN,
                id = vc.id
            };

        }
        public static implicit operator GTRM(myGtrm vc)
        {
            return new GTRM()
            {
                CustomerName = vc.CustomerName,
                dateDownload = vc.dateDownload,
                email = vc.email,
                MID = vc.MID,
                UNN = vc.unn
                //id = vc.id
            };
        }
        public int id { get; set; }
        public DateTime dateDownload { get; set; }
        public string CustomerName { get; set; }
        public string unn { get; set; }
        public string MID { get; set; }
        public string email { get; set; }
    }
}
