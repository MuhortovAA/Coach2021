﻿using System;
using System.Collections.Generic;

namespace BPCParcer.Services.Interfaces
{
    interface IBase<T> : IDisposable where T : class
    {
        void Save(Dictionary<int, T> dic);
        void Truncate();
    }
}
