﻿using BPCParcer.Services.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;

namespace BPCParcer.Services.Interfaces
{
    interface IRepository<T> : IDisposable where T : class
    {
        void Save();
        void Truncate();
        void Add(T data);
        int GetID(T data);
        List<T> GetData();
        System.Data.SqlClient.SqlBulkCopy SetSqlBulk<TEntity>(List<TEntity> list, out DataTable table, out PropertyDescriptor[] columnsout) where TEntity : class;
        //System.Data.SqlClient.SqlBulkCopy SetSqlBulk<TEntity>(Dictionary<int, Customer> dic, out DataTable table, out PropertyDescriptor[] columnsout) where TEntity : class;
        System.Data.SqlClient.SqlBulkCopy SetSqlBulk<TEntity>(Dictionary<int, Statement> dic, out DataTable table, out PropertyDescriptor[] columnsout) where TEntity : class;
        System.Data.SqlClient.SqlBulkCopy SetSqlBulk2(int count, out DataTable table, out PropertyDescriptor[] columnsout);

        void Save<TEntity>(List<TEntity> list) where TEntity : class;
        //void Save<TEntity>(Dictionary<int, Customer> dic) where TEntity : class;
        void Save<TEntity>(Dictionary<int, Statement> dic) where TEntity : class;

        void Save2<TEntity>(Dictionary<int, TEntity> dic) where TEntity : class;




    }
}
