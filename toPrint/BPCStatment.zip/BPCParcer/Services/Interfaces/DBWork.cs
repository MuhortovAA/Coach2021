﻿using System;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace BPCParcer.Services.Interfaces
{
    public class DBWork<T>
    {
        Type typeClass;
        string stringClass;
        public DBWork()
        {
            typeClass = typeof(T);
            stringClass = typeof(T).Name;
        }

        public SqlBulkCopy SetSqlBulk(int count, string provider, out DataTable table, out PropertyDescriptor[] columnsout)
        {
            var loader = new System.Data.SqlClient.SqlBulkCopy(provider, SqlBulkCopyOptions.Default) { DestinationTableName = stringClass, BatchSize = count, BulkCopyTimeout = 100000 };
            table = new DataTable();
            var columns = TypeDescriptor.GetProperties(typeClass).Cast<PropertyDescriptor>().Where(p => p.PropertyType.Namespace.Equals("System")).ToArray();
            var con = new SqlConnection(provider);
            con.Open();
            foreach (var column in columns)
            {
                loader.ColumnMappings.Add(column.Name, column.Name);
                table.Columns.Add(column.Name, Nullable.GetUnderlyingType(column.PropertyType) ?? column.PropertyType);
            }
            con.Close();
            columnsout = columns;
            return loader;
        }
    }
}
