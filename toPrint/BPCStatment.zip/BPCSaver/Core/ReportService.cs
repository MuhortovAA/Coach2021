﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace BPCSaver.Core
{
    public class ReportService
    {

        private string report_path { get; set; }
        private string report_format { get; set; }
        //private string report_customer { get; set; }
        private string user_name { get; set; }
        private string user_password { get; set; }
        private string BaseUrl { get; set; }
        public double TimeOut { get; set; }




        public ReportService(string r_server, string r_path, string r_format, string r_user, string r_user_password, double time_out)
        {
            BaseUrl = r_server;
            this.report_path = r_path;
            this.report_format = r_format;
            this.user_name = r_user;
            this.user_password = r_user_password;
            this.TimeOut = time_out;
        }

        private string GetUri(string customer_name, string datefrom, string dateto) => $"{report_path}&rs:Command=Render&rs:Format={report_format}&UNN={customer_name}&datefrom={datefrom}&dateto={dateto}";
        private Stream GetData(string url)
        {
            using (var handler = new HttpClientHandler { Credentials = new NetworkCredential(user_name, user_password), UseDefaultCredentials = false, MaxResponseHeadersLength = int.MaxValue })
            using (var myhttpclient = new HttpClient(handler) { BaseAddress = new Uri(BaseUrl, UriKind.RelativeOrAbsolute), Timeout = TimeSpan.FromSeconds(TimeOut) })
            {
                return myhttpclient.GetStreamAsync(url).Result;
            }
        }
        public Stream GetReport(string customer_name, string datefrom, string dateto) => GetData(GetUri(customer_name, datefrom, dateto));

    }
}
