﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace BPCSaver.Core
{
    public class EmailService
    {
        SmtpClient smtp;
        //MailMessage message;
        NetworkCredential credential { get; set; }
        MailAddress mail_address { get; set; }
        int maxsizeFile = 50000000;
        string file_extension;
        string file_path;

        public EmailService(string server_email, string email_user, string email_user_password, string report_extension, string path_report)
        {
            //
            credential = new NetworkCredential(email_user, email_user_password);
            smtp = new SmtpClient(server_email, 25) { Credentials = credential };
            mail_address = new MailAddress(email_user);
            file_extension = report_extension;
            file_path = path_report;
        }

        public void SendMail(WorkStatements customer)
        {
            var path_report = $"{customer.UNN}_{customer.DateFrom.ToString("ddMMyyyy")}_{customer.DateTo.ToString("ddMMyyyy")}.{file_extension}";
            var senderEmail = new MailAddress(customer.Email);
            MailMessage message = new MailMessage() { 
                From = mail_address, Subject = $"Выписка по счету клиента:{customer.CustomerName} УНН:{customer.UNN}", 
                Body = $"Доброго времени суток! \r" +
                $"ОАО АСБ Беларусбанк выражает благодарность и уважение за плодотворное сотрудничество.\r" +
                $"Направляем выписку по операциям в рамках договора по расчетному обслуживанию (эквайрингу) за отчетный период.\r" +
                $"В случае возникновения вопросов, просим Вас обращаться в службу корпоративного бизнеса учреждения ОАО АСБ Беларусбанк по месту заключения договора по расчетному обслуживанию (эквайрингу).\r" +
                $"С уважением, ОАО АСБ Беларусбанк.\r"
            };
            message.To.Add(senderEmail);
            message.Attachments.Add(GetFile(Path.Combine(file_path, path_report)));
            smtp.Send(message);
        }

        private Attachment GetFile(string path_report)
        {
            if (File.Exists(path_report) && new FileInfo(path_report).Length < maxsizeFile)
            {
                return new Attachment(path_report);
            }
            else if (!File.Exists(Path.GetFileName(path_report)))
            {
                throw new Exception($"Файл не найден: {path_report}");
            }
            else if (maxsizeFile < new FileInfo(Path.GetFileName(path_report)).Length)
            {
                throw new Exception($"Превышен допустимый размер {maxsizeFile} у файла: {path_report} размер: {new FileInfo(Path.GetFileName(path_report)).Length} ");
            }

            throw new Exception($"Файл не найден: {path_report} либо превышен допустимый размер {maxsizeFile}");
        }
    }
}
