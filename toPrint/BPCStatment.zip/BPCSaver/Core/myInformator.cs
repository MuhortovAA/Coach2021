﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPCSaver.Core
{
    public static class myInformator
    {
        public static string GetDataSource()
        {
            //var connectionString = ConfigurationManager.ConnectionStrings["InterChangeEntities"].ConnectionString;
            //var builder = new EntityConnectionStringBuilder(connectionString);
            //var count = 0;
            //foreach (var item in builder.Values)
            //{
            //    count++;
            //    if (count == 4)
            //    {
            //        var cs = new SqlConnectionStringBuilder(item.ToString());
            //        return cs.DataSource;
            //    }

            //}
            return String.Empty;
        }
        public static void Send(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            Console.WriteLine($"{DateTime.Now} {loginfo}");
            logger.Info(loginfo);
        }
        public static void Send2(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            //Console.Write("");
            Console.Write($"\r{DateTime.Now} {loginfo}");
            Console.Write("");
            logger.Info(loginfo);
        }
        public static void Send3(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            Console.Write($"\r{DateTime.Now} {loginfo}");
            Console.WriteLine();
            logger.Info(loginfo);
        }
        public static void SendConsole(string loginfo)
        {
            Console.Write($"\r{DateTime.Now} {loginfo}");
        }
        public static void SendConsole2(string loginfo)
        {
            Console.Write($"\r{DateTime.Now} {loginfo}");
            Console.WriteLine();

        }
        public static void Send4(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            Console.WriteLine();
            Console.Write($"\r{DateTime.Now} {loginfo}");
            logger.Info(loginfo);
        }
        public static void SendError(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            Console.WriteLine($"{DateTime.Now} {loginfo}");
            logger.Error(loginfo);
        }
        public static void SendLog(string loginfo)
        {
            Logger logger = LogManager.GetCurrentClassLogger();
            logger.Info(loginfo);
        }

    }
}
