﻿using BPCSaver.Services.Models;
using System;
using System.IO;

namespace BPCSaver.Core
{
    public class FileService
    {
        //ConfigApp conf;
        private string path_save = "";

        private string file_exe { get; set; }
        public FileService(string path_save_file, string file_extansion)
        {
            path_save = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path_save_file ?? "Reports");
            file_exe = file_extansion;
        }

        private string GetNameFileReport(WorkState customer) => $"{path_save}\\{customer.UNN}_{customer.DateFrom.ToString("ddMMyyyy")}_{customer.DateTo.ToString("ddMMyyyy")}.{file_exe}";
        private void SaveData(string fname, Stream stream)
        {
            using (var s = File.Create(fname))
            {
                stream.CopyTo(s);
            }
        }
        public string SaveFile(WorkState customer, Stream rep_stream)
        {
            var rep_file = GetNameFileReport(customer);
            SaveData(rep_file, rep_stream);
            return rep_file;
        }
    }
}
