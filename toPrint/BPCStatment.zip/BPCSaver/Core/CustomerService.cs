﻿using BPCSaver.Services.Models;
using BPCSaver.Services.Repository;
using System;
using System.IO;

namespace BPCSaver.Core
{
    public class CustomerService
    {
        ConfigApp conf;
        ReportService report_serv;
        FileService file_serv;
        EmailService email_serv;
        RepositoryWorkStatements repo;
        public CustomerService()
        {
            //default settings
            conf = new ConfigApp();
            conf.AddUpdateAppSettings("ReportServer", "http://sca-pbi-db");
            conf.AddUpdateAppSettings("ReportServerPath", "/ReportServer?/ПК BPCStatement/Report_Statement3");
            //conf.AddUpdateAppSettings("ReportWorkSpace", "ReportServer?");
            //conf.AddUpdateAppSettings("ReportArea", "ПК BPCStatement");
            //conf.AddUpdateAppSettings("ReportItem", "Report_Statement3");

            conf.AddUpdateAppSettings("ReportFormat", "EXCEL");
            //conf.AddUpdateAppSettings("ReportExtention", "xls");
            conf.AddUpdateAppSettings("ReportUser", "b00028116");
            conf.AddUpdateAppSettings("ReportUserPassword", "09082021");
            conf.AddUpdateAppSettings("PathReports", "Reports");
            conf.AddUpdateAppSettings("ReportTimeOut", "1200");
            conf.AddUpdateAppSettings("EmailServer", "mail2.asb.by");
            conf.AddUpdateAppSettings("EmailUser", "tech.user@belarusbank.by");
            conf.AddUpdateAppSettings("EmailUserPassword", "di82BJ77");


            //report settings
            var report_server = conf.GetSetting("ReportServer");
            var report_server_path = conf.GetSetting("ReportServerPath");
            //var report_workspace = conf.GetSetting("ReportWorkSpace");
            //var report_area = conf.GetSetting("ReportArea");
            //var report_item = conf.GetSetting("ReportItem");

            var report_format = conf.GetSetting("ReportFormat");
            var report_user = conf.GetSetting("ReportUser");
            var report_user_password = conf.GetSetting("ReportUserPassword");
            var report_timeout = conf.GetSetting("ReportTimeOut");
            var email_server = conf.GetSetting("EmailServer");
            var email_user = conf.GetSetting("EmailUser");
            var email_user_password = conf.GetSetting("EmailUserPassword");
            //file settings
            var path_reports = conf.GetSetting("PathReports");
            var file_extension = report_format.ToUpper() == "EXCEL" ? "XLS" : report_format == "CSV" ? "CSV" : report_format;
            //convert settings
            double timeout;
            if (!Double.TryParse(report_timeout, out timeout)) { throw new Exception("Проверьте ReportTimeOut - должно быть целое число"); }

            //services
            //report_server_path = $"/{report_workspace}/{report_area}/{report_item}";
            //
            report_serv = new ReportService(report_server, report_server_path, report_format, report_user, report_user_password, timeout);
            file_serv = new FileService(path_reports, file_extension);
            email_serv = new EmailService(email_server, email_user, email_user_password, file_extension, Path.Combine(AppDomain.CurrentDomain.BaseDirectory, path_reports));
            repo = new RepositoryWorkStatements();
        }
        private (short flag, string file_name) Statement_Save(WorkState customer)
        {
            short result = 0;
            string file_name = "file_name";
            try
            {
                //получаем отчет
                var report = report_serv.GetReport(customer.UNN, customer.DateFrom.ToString("yyyy-MM-dd"), customer.DateTo.ToString("yyyy-MM-dd"));

                //сохраняем в файл
                file_name = file_serv.SaveFile(customer, report);
                //
                result = 1; // успешное выполнение
            }
            catch (Exception ex) { myInformator.SendError($"{ex.Message} {ex.InnerException}:{customer.UNN} {customer.CustomerName}"); }

            return (result, file_name);
        }

        public void StartProccess()
        {
            myInformator.SendConsole2($"Старт формирования");
            //create report
            foreach (var customer in repo.GetReportFlagData())
            {
                //сохраняем отчет
                (short flag, string file_name) result = Statement_Save(customer);
                //(short flag, string file_name) result = (1, "test.file");
                customer.flagReport = result.flag;
                //обновляем флаг
                repo.Update(customer);
                //
                var countall = repo.CountAll();
                var countReady = repo.CountReadyReport();
                //
                string message = $"готовность выписки: {countReady}:{countall - countReady}:{countall} {countReady * 100 / countall}% для УНН {customer.UNN} сформирован файл: {Path.GetFileName(result.file_name)}";
                //string message = countall == countReady ?
                //                  $"готовность выписки: {countReady * 100 / countall}%                                                     " :
                //                  $"готовность выписки: {countReady}:{countall - countReady}:{countall} {countReady * 100 / countall}% сформирован файл: {Path.GetFileName(result.file_name)}";
                myInformator.Send2(message);
            }
            //send email
            myInformator.SendConsole2($"");

            foreach (var customer in repo.GetEmailFlagData())
            {
                //отправляем email
                customer.flagEmail = (short)Email_Send(customer);
                //customer.flagEmail = 1;
                //обновляем флаг
                repo.Update(customer);
                var countall = repo.CountAll();
                var countReady = repo.CountReadyEmail();
                //
                string message = $"готовность email: {countReady}:{countall - countReady}:{countall} {countReady * 100 / countall}% для УНН {customer.UNN} отправлен email: {customer.Email}";
                myInformator.Send2(message);
                ////
                //string message = countall == countReady ?
                //                 $"готовность email: {countReady * 100 / countall}%                                                        " :
                //                 $"готовность email: {countReady}:{countall - countReady}:{countall} {countReady * 100 / countall}% отправлен email: {customer.Email}";

                //myInformator.Send2(message);
            }
        }

        private short Email_Send(WorkStatements customer)
        {
            short result = 0;
            try
            {
                //отправка email
                email_serv.SendMail(customer);

                result = 1;

            }
            catch (Exception ex)
            {

                myInformator.SendError($"{ex.Message} {ex.InnerException}:{customer.UNN} {customer.CustomerName}");

            }
            return result;
        }
    }
}
