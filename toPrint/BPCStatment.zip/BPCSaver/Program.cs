﻿using BPCSaver.Core;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace BPCSaver
{
    class Program
    {
        static void Main(string[] args)
        {
            myInformator.Send("Старт программы");
            var version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            string Description = ((AssemblyDescriptionAttribute)Attribute.GetCustomAttribute(Assembly.GetExecutingAssembly(), typeof(AssemblyDescriptionAttribute), false)).Description;
            myInformator.Send($"Текущая версия {version.Major}.{version.Minor}.{version.Build}.{version.Revision} {Description}");

            StartProc();

            myInformator.Send4($"Нажмите любую клавишу для выхода!");
            Console.ReadLine();

        }
        private static void StartProc()
        {
            var cs = new CustomerService();
            cs.StartProccess();//старт процесса сохранение отчета
        }
    }
}
