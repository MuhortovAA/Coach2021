﻿using BPCSaver.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.Core.EntityClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPCSaver.Services.Repository
{
    public class RepositoryWorkStatements : IRepository<WorkStatements>
    {
        BPCStatementEntities db;
        string connectionstring;
        string provider;
        public RepositoryWorkStatements()
        {
            db = new BPCStatementEntities();
            connectionstring = ConfigurationManager.ConnectionStrings["BPCStatementEntities"].ConnectionString;
            provider = new EntityConnectionStringBuilder(connectionstring).ProviderConnectionString;
        }

        public void Add(WorkStatements data)
        {
            throw new NotImplementedException();
        }

        public int CountAll() => db.WorkStatements.Count();


        public int CountReadyEmail() => db.WorkStatements.Where(e => e.flagEmail == 1).Count();

        public int CountReadyReport() => db.WorkStatements.Where(r => r.flagReport == 1).Count();


        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public List<WorkStatements> GetData() => db.WorkStatements.ToList();

        public List<WorkStatements> GetEmailFlagData() => db.WorkStatements.Where(s => s.flagEmail == 0 && s.flagReport == 1).ToList();


        public int GetID(WorkStatements data)
        {
            throw new NotImplementedException();
        }

        public List<WorkStatements> GetReportFlagData() => db.WorkStatements.Where(s => s.flagReport == 0).ToList();


        public void Save()
        {
            db.SaveChanges();
        }

        public void Save<TEntity>(TEntity data) where TEntity : class
        {
            throw new NotImplementedException();
        }

        public void Truncate()
        {
            db.Database.ExecuteSqlCommand("TRUNCATE TABLE [BPCStatement].[dbo].[WorkStatements]");
        }



        public void Update(WorkStatements data)
        {

            WorkStatements customer = db.WorkStatements.Where(w => w.id == data.id).First();
            customer = data;
            Save();

        }
    }
}
