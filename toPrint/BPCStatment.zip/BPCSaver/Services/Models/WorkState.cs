﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPCSaver.Services.Models
{
    public class WorkState
    {
        public static explicit operator WorkStatements(WorkState vc)
        {
            return new WorkStatements()
            {
                id = vc.Id,
                CustomerName = vc.CustomerName,
                DateFrom = vc.DateFrom,
                DateTo = vc.DateTo,
                Email = vc.Email,
                UNN = vc.UNN,
                flagEmail = vc.fEmail,
                flagReport = vc.fReport
            };

        }
        public static implicit operator WorkState(WorkStatements vc)
        {
            return new WorkState()
            {
                Id = vc.id,
                CustomerName = vc.CustomerName,
                DateFrom = vc.DateFrom,
                DateTo = vc.DateTo,
                Email = vc.Email,
                UNN = vc.UNN,
                fEmail = vc.flagEmail,
                fReport = vc.flagReport
            };

        }

        public int Id { get; set; }
        public string CustomerName { get; set; }
        public string UNN { get; set; }
        public DateTime DateFrom { get; set; }
        public DateTime DateTo { get; set; }
        public string Email { get; set; }
        public short fReport { get; set; }
        public short fEmail { get; set; }
    }
}
