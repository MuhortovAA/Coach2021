﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BPCSaver.Services.Interfaces
{
    interface IRepository<T> : IDisposable where T : class
    {
        void Save();
        void Truncate();
        void Add(T data);
        int GetID(T data);
        int CountAll();
        int CountReadyReport();
        int CountReadyEmail();
        List<T> GetData();
        List<T> GetReportFlagData();
        List<T> GetEmailFlagData();
        void Save<TEntity>(TEntity data) where TEntity : class;
        void Update(WorkStatements data);
    }
}
