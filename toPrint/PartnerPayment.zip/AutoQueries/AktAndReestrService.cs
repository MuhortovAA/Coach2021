﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NLog;
using System.IO;
using System.Xml.Serialization;
using System.Xml.Xsl;
using System.Xml;
using System.Net.Mail;
using System.Net;
using NPOI.XSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.SS.Util;

namespace AutoQueries
{
    public class AktAndReestrService
    {
        private static PartnerPaymentEntities _db;
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public void PreDoc(List<View_Work_Exe> modelView)
        {
            var firstDay = modelView.FirstOrDefault().dateFrom;
            var lastDay = modelView.FirstOrDefault().dateTo;
            List<GTRM> gtrm = GetGTRMList();
            List<sprFilials> listFilials = GetListFilials();
            foreach (var item in modelView)
            {
                GTRM model = gtrm.Where(x => x.numBonusDog == item.numBonusDog).LastOrDefault();

                sprFilials modelFilial = listFilials.Where(x => x.CBY == model.filialSupport).FirstOrDefault();

                if (null == modelFilial) logger.Error($"Для договора {item.numBonusDog} не найден filialSupport: {model.filialSupport} filialSign: {model.filialSign} в таблице [sprFilials]");
                else
                {
                    //path1
                    var report_path = @"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\";

                    //path2
                    //var report_path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Report\\");

                    WordRead(item, firstDay, lastDay, modelFilial, model, report_path);
                    ExcelCreate(item, firstDay, lastDay, modelFilial, model, report_path);
                }
            }
        }

        private void ExcelCreate(View_Work_Exe work, DateTime firstDay, DateTime lastDay, sprFilials modelFilial, GTRM model, string report_path)
        {
            var workbook = new XSSFWorkbook();
            var sheet = (XSSFSheet)workbook.CreateSheet("Лист 1");
            //path1
            //var report_path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Report\\");
            //path2
            //var report_path = @"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\";

            var report_name = $"Акт и реестр по договору {work.numBonusDog} за {work.dateFrom.Year}{work.dateFrom.Month.ToString("00")}.xls";
            #region Заголовок таблицы
            var styleTop = workbook.CreateCellStyle();
            styleTop.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Center;
            styleTop.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            styleTop.WrapText = true;

            sheet.CreateRow(0).myCreateCell(0).mySetStyle(styleTop).mySetValue("РЕЕСТР");
            sheet.AddMergedRegion(new CellRangeAddress(0, 0, 0, 9));

            sheet.CreateRow(1).myCreateCell(0).mySetStyle(styleTop).mySetValue($"к акту оказанных услуг по договору {model.numBonusDog} без эквайринга от {model.dateBonusDog} г.");
            sheet.AddMergedRegion(new CellRangeAddress(1, 1, 0, 9));

            sheet.CreateRow(2).myCreateCell(0).mySetStyle(styleTop).mySetValue("г.Минск");

            #endregion
            #region Название столбцов
            var styleColumnsTop = workbook.CreateCellStyle();
            styleColumnsTop.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Center;
            styleColumnsTop.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
            styleColumnsTop.WrapText = true;


            var row3 = sheet.CreateRow(3);

            row3.myHeightInPoints(130).myCreateCell(0).mySetStyle(styleColumnsTop).mySetValue("№ п/п");
            row3.myCreateCell(1).mySetStyle(styleColumnsTop).mySetValue("Дата транзакции");
            row3.myCreateCell(2).mySetStyle(styleColumnsTop).mySetValue("MID торгового объекта");
            row3.myCreateCell(3).mySetStyle(styleColumnsTop).mySetValue("Наименование торгового объекта");
            row3.myCreateCell(4).mySetStyle(styleColumnsTop).mySetValue("Тип карточки, участвующей в партнерской (бонусной) программе банка (BIN, рендж)");
            row3.myCreateCell(5).mySetStyle(styleColumnsTop).mySetValue("Сумма (оборот) платежей по карточкам, участвующим в партнерской (бонусной) программе банка, бел. руб.");
            row3.myCreateCell(6).mySetStyle(styleColumnsTop).mySetValue("Сумма возвратов денежных средств в результате возврата товаров (работ, услуг), бел. руб.");
            row3.myCreateCell(7).mySetStyle(styleColumnsTop).mySetValue("База для расчета суммы вознаграждения, бел. руб.");
            row3.myCreateCell(8).mySetStyle(styleColumnsTop).mySetValue("(графа 6 – графа 7)	Ставка вознаграждения за участие ОТС в партнерской (бонусной) программе банка, %");
            row3.myCreateCell(9).mySetStyle(styleColumnsTop).mySetValue("Сумма вознаграждения, бел. руб.");

            var row4 = sheet.CreateRow(4);
            for (int k = 0; k < 10; k++)
            {
                row4.myCreateCell(k).mySetValue((k + 1).ToString()).mySetStyle(workbook.CreateCellStyle()).myAlignment(HorizontalAlignment.Center).myVerticalAlignment(VerticalAlignment.Center).myWrapText(true);
            }
            #endregion
            #region Заполнение таблицы
            ///
            int row_data = 5;
            int count_row = 0;
            int length_nameAllOTS = 1;
            //int length_nameOTS = 1;
            int length_MID = 1;
            var styleSum = workbook.CreateCellStyle();
            styleSum.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Right;
            var reestr = getReestrList(work.numBonusDog, firstDay, lastDay);
            foreach (var item in reestr)
            {
                length_nameAllOTS = item.OTC.Trim().Length > length_nameAllOTS ? item.OTC.Trim().Length : length_nameAllOTS;
                //length_nameOTS = item.nameOTS.Trim().Length > length_nameOTS ? item.nameOTS.Trim().Length : length_nameOTS;
                length_MID = item.MID.Trim().Length > length_MID ? item.MID.Trim().Length : length_MID;

                var row_item = sheet.CreateRow(row_data + count_row++);
                row_item.myCreateCell(0).mySetValue(count_row.ToString()).mySetStyle(styleTop);
                row_item.myCreateCell(1).mySetValue(item.Date).mySetStyle(styleTop);
                row_item.myCreateCell(2).mySetValue(item.MID).mySetStyle(styleTop);
                row_item.myCreateCell(3).mySetValue(item.OTC.Trim()).mySetStyle(styleTop);
                row_item.myCreateCell(4).mySetValue(item.Card9.ToString()).mySetStyle(styleTop);
                row_item.myCreateCell(5).mySetValue(item.C205_226.ToString()).mySetStyle(styleSum);
                row_item.myCreateCell(6).mySetValue(item.C206_225.ToString()).mySetStyle(styleSum);
                row_item.myCreateCell(7).mySetValue((item.C205_226 - item.C206_225).ToString()).mySetStyle(styleSum);
                row_item.myCreateCell(8).mySetValue(item.proc.ToString()).mySetStyle(styleSum);
                row_item.myCreateCell(9).mySetValue(item.SumWithProc.ToString()).mySetStyle(styleSum);
            }

            #endregion
            #region Итоги

            foreach (var card in reestr.Select(x => x.Card9).Distinct().ToList())
            {
                var totalID = row_data + count_row++;
                //1
                var row_total1 = sheet.CreateRow(totalID);
                var tarif = GetTarifFromCard9(card);
                var total_card = $"Итого по карточкам \"{tarif}\" по ОТС";
                row_total1.myCreateCell(0).mySetValue(total_card).mySetStyle(workbook.CreateCellStyle()).myAlignment(HorizontalAlignment.Right);
                sheet.AddMergedRegion(new CellRangeAddress(totalID, totalID, 0, 3));
                row_total1.myCreateCell(4).mySetValue(card).mySetStyle(workbook.CreateCellStyle()).myAlignment(HorizontalAlignment.Center);
                var res_205206 = reestr.Where(x => x.Card9 == card).Sum(x => x.C205_226);
                var res_206225 = reestr.Where(x => x.Card9 == card).Sum(x => x.C206_225);
                row_total1.myCreateCell(5).mySetValue(res_205206.ToString()).mySetStyle(styleSum);
                row_total1.myCreateCell(6).mySetValue(res_206225.ToString()).mySetStyle(styleSum);
                row_total1.myCreateCell(7).mySetValue((res_205206 - res_206225).ToString()).mySetStyle(styleSum);
                row_total1.myCreateCell(8).mySetValue("-").mySetStyle(workbook.CreateCellStyle()).myAlignment(HorizontalAlignment.Right);
                var res_debt = (decimal)reestr.Where(x => x.Card9 == card).Sum(x => x.SumWithProc);
                row_total1.myCreateCell(9).mySetValue(res_debt.ToString()).mySetStyle(styleSum);
            }
            var totalOTS = row_data + count_row;
            var row_totalOTS1 = sheet.CreateRow(totalOTS);
            row_totalOTS1.myCreateCell(0).mySetValue("Итого по ОТС").mySetStyle(workbook.CreateCellStyle()).myAlignment(HorizontalAlignment.Right);
            sheet.AddMergedRegion(new CellRangeAddress(totalOTS, totalOTS, 0, 4));
            var ots_205206 = reestr.Sum(x => x.C205_226);
            row_totalOTS1.myCreateCell(5).mySetValue(ots_205206.ToString()).mySetStyle(styleSum);
            var ots_206225 = reestr.Sum(x => x.C206_225);
            row_totalOTS1.myCreateCell(6).mySetValue(ots_206225.ToString()).mySetStyle(styleSum);
            row_totalOTS1.myCreateCell(7).mySetValue((ots_205206 - ots_206225).ToString()).mySetStyle(styleSum);
            row_totalOTS1.myCreateCell(8).mySetValue("-").mySetStyle(workbook.CreateCellStyle()).myAlignment(HorizontalAlignment.Right);
            var ots_debt = reestr.Sum(x => x.SumWithProc);
            row_totalOTS1.myCreateCell(9).mySetValue(ots_debt.ToString()).mySetStyle(styleSum);


            #endregion

            sheet.SetColumnWidth(1, 3000);//Дата транзакции
            sheet.SetColumnWidth(2, length_MID * 320);//MID торгового объекта
            sheet.SetColumnWidth(3, length_nameAllOTS * 320);//Наименование торгового объекта
            sheet.SetColumnWidth(4, 4100);//Тип карточки, участвующей в партнерской (бонусной) программе банка (BIN, рендж)
            sheet.SetColumnWidth(5, 4100);//Сумма (оборот) платежей по карточкам, участвующим в партнерской (бонусной) программе банка, бел. руб.
            sheet.SetColumnWidth(6, 4100);//Сумма возвратов денежных средств в результате возврата товаров (работ, услуг), бел. руб.
            sheet.SetColumnWidth(7, 4100);//База для расчета суммы вознаграждения, бел. руб.
            sheet.SetColumnWidth(8, 4100);//(графа 6 – графа 7)	Ставка вознаграждения за участие ОТС в партнерской (бонусной) программе банка, %	
            sheet.SetColumnWidth(9, 4100);//Сумма вознаграждения, бел. руб.
            sheet.SetColumnWidth(10, 4000);
            using (var fs = new FileStream(report_path + report_name, FileMode.Create, FileAccess.Write))
            {
                workbook.Write(fs);
            }
            logger.Info($"Выгрузка файла: {report_name} - OK");

        }

        public void PreSend(List<View_Work_Exe> modelView)
        {
            var firstDay = modelView.Last().dateFrom;
            var lastDay = modelView.FirstOrDefault().dateTo;
            List<GTRM> gtrm = GetGTRMList();
            foreach (var item in modelView)
            {
                GTRM modelGTRM = gtrm.Where(x => x.numBonusDog == item.numBonusDog).LastOrDefault();
                SendMail(modelGTRM, firstDay);
            }
        }

        public void SendMail(GTRM model, DateTime firstDay)
        {
            SmtpClient Smtp = new SmtpClient("mail2.asb.by", 25);
            Smtp.Credentials = new NetworkCredential("tech.user@belarusbank.by", "di82BJ77");
            MailMessage Message = new MailMessage();
            var month = firstDay.Month.ToString("00");
            var year = firstDay.Year.ToString();
            Message.From = new MailAddress("tech.user@belarusbank.by");
            Message.To.Add(new MailAddress(model.email));
            //Message.To.Add(new MailAddress("xbestya@mail.ru"));
            Message.Subject = $"Акт и реестр по договору {model.numBonusDog} за {year}{month}";
            Message.Body = $"Добрый день. Вам направляется письмо с актом и реестром по договору {model.numBonusDog} за {year}{month}.";

            //Message.Attachments.Add(new Attachment(@"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\Акт и реестр по договору " + $"{model.numBonusDog} за {year}{month}.rtf"));
            //формируем имя файла с учетом настроек 
            //string str = @"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\Акт и реестр по договору " + $"{model.numBonusDog} за {year}{month}.{Properties.Settings.Default.ActReestrTypeFile}";

            //rtf
            var fileRtf = GetFile(model, year, month);
            Message.Attachments.Add(fileRtf);

            //excel 
            var fileExcel = GetFileExcel(model, year, month);
            Message.Attachments.Add(fileExcel);

            logger.Info($"Начат процесс отправки письма по договору {model.numBonusDog} на адрес: {model.emailPartners} GTRMid:{model.id}");
            Smtp.Send(Message);
            logger.Info($"Письмо успешно отправлено");
            using (_db = new PartnerPaymentEntities())
            {
                WorkNew ss = _db.WorkNew.Where(x => x.numBonusDog == model.numBonusDog && x.dateFrom == firstDay).First();
                {
                    ss.flagMail = "4";
                    ss.dateSend = DateTime.Now;
                    _db.SaveChanges();
                    logger.Info($"Изменен статус на 'Отправлено' по договору {model.numBonusDog}  и WABid:{ss.id}");
                }
            }
        }


        public Attachment GetFile(GTRM model, string year, string month)
        {
            int sizeFile = 50000000;
            string settingSizeFile = String.Empty;

            try
            {
                settingSizeFile = Properties.Settings.Default.SizeFile;
                sizeFile = Int32.Parse(settingSizeFile);
            }
            catch (Exception ex)
            {
                logger.Error($"Ошибка {ex.Message} в получении данных из файла настроек SizeFile {settingSizeFile}");
            }


            string[] strExeFiles = Properties.Settings.Default.ActReestrTypeFile.Split(',');
            Attachment filePath;
            bool flag = false;
            string curFile = "";

            long curFileSize = 0;

            foreach (var fileExe in strExeFiles)
            {
                curFile = @"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\Акт и реестр по договору " + $"{model.numBonusDog} за {year}{month}.{fileExe}";
                flag = File.Exists(curFile);

                if (flag)
                {

                    curFileSize = new FileInfo(curFile).Length;

                    bool flagLength = curFileSize < sizeFile ? true : false;

                    if (flagLength)
                    {
                        logger.Info($"Файл {curFile} найден");
                        filePath = new Attachment(curFile);
                        return filePath;
                    }
                }
                else
                {
                    logger.Error($"Файл {curFile} не найден");
                }
            }

            System.ArgumentException argEx = new System.ArgumentException($"Размер файла {curFileSize} больше допустимого размера {sizeFile} для отправки по email либо не найден {curFile}");
            throw argEx;
        }

        public Attachment GetFileExcel(GTRM model, string year, string month)
        {
            int sizeFile = 50000000;
            string settingSizeFile = String.Empty;

            try
            {
                settingSizeFile = Properties.Settings.Default.SizeFile;
                sizeFile = Int32.Parse(settingSizeFile);
            }
            catch (Exception ex)
            {
                logger.Error($"Ошибка {ex.Message} в получении данных из файла настроек SizeFile {settingSizeFile}");
            }

            string curFile = @"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\Акт и реестр по договору " + $"{model.numBonusDog} за {year}{month}.xls";
            long curFileSize = 0;

            if (File.Exists(curFile))
            {

                curFileSize = new FileInfo(curFile).Length;

                bool flagLength = curFileSize < sizeFile ? true : false;

                if (flagLength)
                {
                    logger.Info($"Файл {curFile} найден");
                    return new Attachment(curFile);
                }
                else logger.Info($"Размер файла {curFileSize} больше допустимого размера {sizeFile} для отправки по email либо не найден {curFile}");

            }
            else logger.Error($"Файл {curFile} не найден");

            throw new System.ArgumentException($"Размер файла {curFileSize} больше допустимого размера {sizeFile} для отправки по email либо не найден {curFile}");
        }

        static void WordRead(View_Work_Exe item, DateTime firstDay, DateTime lastDay, sprFilials modelFilial, GTRM model, string report_path)
        {
            try
            {
                string date = DateTime.Now.ToString("dd MMMM yyyy");
                string numBonusDog = item.numBonusDog;
                List<sp_Reestr_Result> spList = getReestrList(numBonusDog, firstDay, lastDay);
                long totalMemory = GC.GetTotalMemory(false);
                if (spList.Count != 0)
                {
                    #region Обработка суммы
                    decimal summOts = (decimal)spList.Sum(x => x.SumWithProc);
                    decimal whole = Math.Floor(summOts);// целое число суммы
                    int LonPropPart = (int)((summOts - whole) * 100);
                    string summOtsCoinLetter = "";
                    if (LonPropPart == 0)
                    {
                        summOtsCoinLetter = "0 копеек";
                    }
                    string summOtsLetter = ConvertToText.StrPropSum(whole);
                    summOtsCoinLetter = ConvertToText.strCop(LonPropPart);
                    #endregion

                    #region Обработка НДС
                    decimal summNds = item.nds;
                    decimal wholeNds = Math.Floor(summNds);// целое число суммы
                    int LonPropPartnds = (int)((summNds - wholeNds) * 100);
                    if (LonPropPart == 0)
                    {
                        summOtsCoinLetter = "0 копеек";
                    }
                    string summNdsLetter = ConvertToText.StrPropSum(wholeNds);
                    string summNdsCoinLetter = ConvertToText.strCop(LonPropPartnds);
                    #endregion

                    if (model != null)
                    {
                        string addressFilial = modelFilial.address;
                        ushort numberFilial = Convert.ToUInt16(modelFilial.filial);


                        #region Заполнение данными файла
                        DocumentXML XmlModel = new DocumentXML();
                        {
                            //Заполнение акта данными

                            XmlModel.dog_num = numBonusDog;
                            XmlModel.date = lastDay.ToShortDateString();
                            //XmlModel.date = date;
                            //XmlModel.FIO_Bank = "Чарной Ольги Леонидовны";
                            //XmlModel.FIO_Bank = "Басалыга Оксана Викторовна";
                            XmlModel.FIO_Bank = "Кардаш Таиса Петровна";
                            //XmlModel.Fio_Bank_Short = "Басалыга О.В.";
                            XmlModel.Fio_Bank_Short = "Кардаш Т.П.";
                            XmlModel.Fio_Bank_Office1 = $"ОАО \"АСБ Беларусбанк\"";
                            XmlModel.Fio_Bank_Office2 = $"г.Минск, пр.Дзержинского 18";
                            XmlModel.Fio_Bank_Office3 = $"Главный специалист отдела";
                            XmlModel.Fio_Bank_Office4 = $"регламентных процедур";
                            XmlModel.Fio_Bank_Office5 = $"управления расчетного обслуживания корпоративных";
                            XmlModel.Fio_Bank_Office6 = $"клиентов Центра расчетов";
                            XmlModel.OSN_Bank = "должностной инструкции";
                            XmlModel.Name_OTS = item.ots;
                            XmlModel.account = model.account;
                            XmlModel.FIO_OTS = "________________________________________";
                            XmlModel.OSN_OTS = "________________________________________";
                            XmlModel.date_dog = model.dateBonusDog.ToShortDateString();
                            XmlModel.period_start = firstDay.ToShortDateString();
                            XmlModel.period_finish = lastDay.ToShortDateString();
                            XmlModel.Uslugi = " по содействию реализации товара";
                            XmlModel.sum = summOts.ToString();
                            XmlModel.sum_in_word = summOtsLetter;
                            XmlModel.sum_coins = summOtsCoinLetter;
                            XmlModel.nds = summNds.ToString();
                            XmlModel.nsd_in_word = summNdsLetter;
                            XmlModel.nds_coins = summNdsCoinLetter;
                            XmlModel.Info_OTS = model.addressOts;
                            XmlModel.address_filial = addressFilial;
                            XmlModel.number_filial = numberFilial;

                            //Заполнение таблицы данными
                            List<DocumentXMLItems> ItemsFieldList = new List<DocumentXMLItems>();
                            int i = 1;
                            foreach (var data in spList)
                            {
                                DocumentXMLItems ItemsField = new DocumentXMLItems();
                                {
                                    ItemsField.number = i;
                                    ItemsField.TransDate = Convert.ToDateTime(data.Date);
                                    ItemsField.MID = data.MID;
                                    ItemsField.Name = data.OTC;
                                    ItemsField.card9 = Convert.ToUInt32(data.Card9);
                                    ItemsField.sum205_226 = data.C205_226.ToString();
                                    ItemsField.sum206_225 = data.C206_225.ToString();
                                    ItemsField.compare = (data.C205_226 - data.C206_225).ToString();
                                    ItemsField.procent = data.proc.ToString();
                                    ItemsField.debt = data.SumWithProc.ToString();
                                    i += 1;
                                    ItemsFieldList.Add(ItemsField);
                                }
                            }
                            XmlModel.Items = ItemsFieldList.ToArray();

                            //Заполнение таблицы данными по карточкам
                            List<DocumentXMLTotals> TotalFieldList = new List<DocumentXMLTotals>();
                            foreach (var data in spList.Select(x => x.Card9).Distinct().ToList())
                            {
                                //logger.Info($"Данные по карте:{data}");

                                DocumentXMLTotals TotalField = new DocumentXMLTotals();

                                try
                                {
                                    //TotalField = new DocumentXMLTotals();
                                    var strCard = GetTarifFromCard9(data);
                                    if (strCard == null)
                                    {
                                        logger.Info($"Данные по карте {data} клиента {model.numBonusDog} из справочника тарифов не найдены ");
                                    }
                                    else
                                    {
                                        TotalField.NameCard = $"Итого по карточкам \"{strCard}\" по ОТС";
                                        TotalField.card9 = Convert.ToUInt32(data);
                                        TotalField.sum205_226 = spList.Where(x => x.Card9 == data).Sum(x => x.C205_226).ToString();
                                        TotalField.sum206_225 = spList.Where(x => x.Card9 == data).Sum(x => x.C206_225).ToString();
                                        TotalField.compare = (spList.Where(x => x.Card9 == data).Sum(x => x.C205_226) - spList.Where(x => x.Card9 == data).Sum(x => x.C206_225)).ToString();
                                        TotalField.debt = ((decimal)spList.Where(x => x.Card9 == data).Sum(x => x.SumWithProc)).ToString();
                                        TotalFieldList.Add(TotalField);
                                    }
                                }
                                catch (Exception e)
                                {
                                    logger.Info($"Данные по карте:{data} вызвали ошибку {e.Message}");
                                }
                                //logger.Info($"Запись данных по реестру: \r{TotalField.NameCard}\r{TotalField.card9}\r{TotalField.sum205_226}\r{TotalField.sum206_225}\r{TotalField.compare}\r{TotalField.debt}");

                            }
                            XmlModel.Totals = TotalFieldList.ToArray();

                            //Заполнение итогов
                            DocumentXMLResult ResultField = new DocumentXMLResult();
                            {
                                ResultField.Text = "Итого по ОТС";
                                ResultField.sum205_226 = spList.Sum(x => x.C205_226).ToString();
                                ResultField.sum206_225 = spList.Sum(x => x.C206_225).ToString();
                                ResultField.compare = (spList.Sum(x => x.C205_226) - spList.Sum(x => x.C206_225)).ToString();
                                ResultField.debt = spList.Sum(x => x.SumWithProc).ToString();

                            }
                            XmlModel.Result = ResultField;

                            //Создание XML
                            XmlSerializer ser = new XmlSerializer(typeof(DocumentXML));
                            var xml = "";
                            using (var sww = new StringWriter())
                            {
                                using (XmlWriter writer = XmlWriter.Create(sww))
                                {
                                    ser.Serialize(writer, XmlModel);
                                    xml = sww.ToString();
                                }
                            }

                            //Создание файла Word
                            using (XmlReader xread = XmlReader.Create(new StringReader(xml)))
                            {
                                if (File.Exists("TemplateOts.xslt"))
                                {
                                    var path = Directory.GetCurrentDirectory();

                                    XslCompiledTransform trans = new XslCompiledTransform();
                                    //path1
                                    //var report_path = @"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\";

                                    //path2
                                    //var report_path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Report\\");
                                    string report_name = $"Акт и реестр по договору {numBonusDog} за {item.dateFrom.Year}{item.dateFrom.Month.ToString("00")}.rtf";
                                    string filename = report_path + report_name;
                                    using (StreamWriter stream = new StreamWriter(filename, false, Encoding.GetEncoding(1251)))
                                    //using (StreamWriter stream = new StreamWriter(@"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\Акт и реестр по договору " + $"{numBonusDog} за " + $"{item.dateFrom.Year}{item.dateFrom.Month.ToString("00")}_test.rtf", false, Encoding.GetEncoding(1251)))
                                    {
                                        trans.Load("TemplateOts.xslt");
                                        trans.Transform(xread, null, stream);
                                    }
                                    logger.Info($"Выгрузка файла: {report_name} - OK");

                                }
                            }

                        }
                        #endregion
                        AddCompareInformation(firstDay, numBonusDog, item.ots, summOts, summNds);
                        ChangeStatus(numBonusDog, firstDay);
                    }
                }
            }
            catch (Exception e)
            {
                string sd = e.Message;
            }
        }

        static List<sp_Reestr_Result> getReestrList(string numDog, DateTime firstDay, DateTime lastDay)
        {
            using (_db = new PartnerPaymentEntities())
            {
                List<sp_Reestr_Result> spList = _db.sp_Reestr(firstDay, lastDay, numDog).ToList();
                return spList;
            }
        }

        static void AddCompareInformation(DateTime firstDay, string numDog, string nameOts, decimal summOts, decimal summNds)
        {
            using (_db = new PartnerPaymentEntities())
            {
                Compare asda = _db.Compare.Where(x => x.numBonusDog == numDog && x.dateFrom == firstDay).FirstOrDefault();
                if (asda != null)
                {
                    asda.sum_akt = summOts;
                    asda.nds_akt = summNds;
                }
                else
                {
                    _db.Compare.Add(new Compare { dateFrom = firstDay, sum_akt = summOts, nds_akt = summNds, numBonusDog = numDog, ots = nameOts });
                }
                _db.SaveChanges();
            }
        }
        static void ChangeStatus(string numDog, DateTime dateFrom)
        {
            using (_db = new PartnerPaymentEntities())
            {
                WorkNew asda = _db.WorkNew.Where(x => x.numBonusDog == numDog && x.dateFrom == dateFrom).FirstOrDefault();
                if (asda != null)
                {
                    asda.flagMail = "2";
                }
                _db.SaveChanges();
            }
        }

        static List<sprFilials> GetListFilials()
        {
            using (_db = new PartnerPaymentEntities())
            {
                List<sprFilials> spList = _db.sprFilials.ToList();
                return spList;
            }
        }
        static List<GTRM> GetGTRMList()
        {
            using (_db = new PartnerPaymentEntities())
            {
                List<GTRM> spList = _db.GTRM.Where(x => x.acquiring == 0).ToList();
                return spList;
            }
        }

        static string GetTarifFromCard9(string card9)
        {
            using (_db = new PartnerPaymentEntities())
            {
                //card9Out = _db.sprTarif.Where(x => x.range == card9).Select(x => x.tarif).Single();
                string card9Out = _db.sprTarif.Where(x => x.range == card9).Select(x => x.tarif).FirstOrDefault();
                return card9Out;
            }
        }
    }

    public static class RowExtentions
    {

        public static ICell myCreateCell(this IRow row, int column) => row.CreateCell(column);
        public static ICell mySetStyle(this ICell cell, ICellStyle style)
        {
            cell.CellStyle = style;
            return cell;
        }
        public static ICell mySetValue(this ICell cell, string CellName)
        {
            cell.SetCellValue(CellName);
            return cell;
        }
        public static IRow myHeightInPoints(this IRow row, int data)
        {
            row.HeightInPoints = data;
            return row;
        }
        public static ICell myAlignment(this ICell cell, HorizontalAlignment align)
        {
            cell.CellStyle.Alignment = align;
            return cell;
        }
        public static ICell myVerticalAlignment(this ICell cell, VerticalAlignment align)
        {
            cell.CellStyle.VerticalAlignment = align;
            return cell;
        }
        public static ICell myWrapText(this ICell cell, bool wrap)
        {
            cell.CellStyle.WrapText = wrap;
            return cell;
        }

    }
}
