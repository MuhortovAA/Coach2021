﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Globalization;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using System.Data.Entity.Core.Objects;
using System.Configuration;
using NLog;

namespace AutoQueries
{
    public class EschfService
    {
        private PartnerPaymentEntities _db;
        public ConvertForMonth ConvertForMonth;
        private MailService _mailService;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public void EscfSend(List<View_Work_Exe> listIn)
        {
            try
            {
                _mailService = new MailService();
                DateTime date = DateTime.Now.Date.AddMonths(-1);
                var lastDay = new DateTime(date.Year, date.Month, DateTime.DaysInMonth(date.Year, date.Month));
                if (listIn.First().ots.Contains("Урегулирование.") == true)
                {
                    lastDay = DateTime.Now;
                }
                List<GTRM> listGTRM = gtrmList();
                var newdate = lastDay.ToString("ddMMyy");
                string filename = $"ESPP{newdate}001.795";
                var pathf = Directory.GetCurrentDirectory();
                var pathWay = Path.Combine(pathf, ConfigurationManager.AppSettings["FolderESCHF"].ToString(), filename);
                File.Delete(pathWay);
                var count = listIn.Count();
                var counteschf = listIn.Where(s => s.dateSend != null).Count();
                logger.Info($"Отобрано записей: {count} обработано будет:{counteschf}");

                foreach (var model in listIn.Where(s => s.dateSend != null))
                {
                    logger.Info($"Обработка данных {model.numBonusDog} {model.dateFrom}");

                    long unn = Convert.ToInt64(model.unn);
                    GTRM modelGTRM = listGTRM.Where(x => x.unn == unn).Last();
                    decimal costWnds = model.debt;
                    decimal nds = model.nds;
                    decimal costWOnds = costWnds - nds;
                    string addres = modelGTRM.addressOts;
                    string inFile = "";
                    StreamWriter writer = new StreamWriter(pathWay, true);
                    inFile = lastDay.ToString("yyyy-MM-dd") + "|" + model.unn + "|" + model.ots + "|" +
                                   "Участие в партнерской(бонусной) программе банка" + "|" + modelGTRM.numBonusDog + "|" + modelGTRM.dateBonusDog.ToString("yyyy-MM-dd") + "|" + "20" + "|" +
                             costWOnds.ToString().Replace(",", ".") + "|" + nds.ToString().Replace(",", ".") + "|" + costWnds.ToString().Replace(",", ".") + "|" + addres + "|"
                    //+ ((DateTime)model.dateSend).ToString("yyyy-MM-dd");
                    + lastDay.ToString("yyyy-MM-dd");
                    writer.WriteLine(inFile);
                    writer.Close();
                    addCompare(model);
                    editStatusESCHF(model);
                }
                _mailService.SendMessageLotus(pathWay, "ЭСЧФ");
                logger.Info($"Файл для менеджера ЭСЧФ сформирован и сохранен в {pathWay}");
            }
            catch (Exception e)
            {
                logger.Error($"Ошибка формирования файла для ПК Менеджер ЭСЧФ {e.Message}-----------------" +
                        $"{e.StackTrace}");
                _mailService = new MailService();
                _mailService.SendErrorMessageLotus($"Ошибка формирования файла для ПК Менеджер ЭСЧФ {e.Message}-----------------" +
                        $"{e.StackTrace}");
                throw new Exception(e.Message);
            }

        }

        public void addCompare(View_Work_Exe model)
        {
            using (_db = new PartnerPaymentEntities())
            {
                var result = _db.Compare.Where(x => x.numBonusDog == model.numBonusDog && x.dateFrom == model.dateFrom).FirstOrDefault();

                if (result == null)
                {
                    logger.Error($"Данные по договору {model.numBonusDog} за период {model.dateFrom} в таблице [dbo].[Compare] не найдены");
                }
                else 
                {


                    Compare sda = result;

                    //Compare sda = _db.Compare.Where(x => x.numBonusDog == model.numBonusDog && x.dateFrom == model.dateFrom).First();

                    sda.sum_eschf = model.debt;
                    sda.nds_eschf = model.nds;

                    _db.SaveChanges();
                }
            }
        }
        public void editStatusESCHF(View_Work_Exe model)
        {
            using (_db = new PartnerPaymentEntities())
            {
                WorkNew sda = _db.WorkNew.Find(model.id);
                sda.flagESCHF = 2;
                _db.SaveChanges();
            }
        }

        public List<GTRM> gtrmList()
        {
            using (_db = new PartnerPaymentEntities())
            {
                List<GTRM> modelGtrm = _db.GTRM.Where(x => x.acquiring == 0).ToList();
                return modelGtrm;
            }
        }
    }
}
