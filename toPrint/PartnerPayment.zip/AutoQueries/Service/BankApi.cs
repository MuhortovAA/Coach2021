﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace AutoQueries.Service
{
    public class BankApi
    {

        string UrlBankApi = "http://sca-cr5.bb.asb:1244";


        public string CreateDerivativeDocument(string filenamedata, string datasend)
        {
            using (var client = new WebClient() { }) //WebClient  
            {
                client.Headers.Add("Content-Type:application/json"); //Content-Type  
                client.Headers.Add("Accept:application/json");

                string uriapi = "/api/DerivativeDocument/CreateDerivativeDocument?";
                string filename = filenamedata;
                string duplication = "false";
                string bodyDocument = datasend;
                var uri = new Uri($"{UrlBankApi}{uriapi}fileName={filename}&bodyDocument={bodyDocument}&duplication={duplication}");
                var result = client.UploadString(uri, "POST", "");
                byte[] bytes = Encoding.Default.GetBytes(result);
                result = Encoding.UTF8.GetString(bytes);
                return result;
            }
        }
    }
}
