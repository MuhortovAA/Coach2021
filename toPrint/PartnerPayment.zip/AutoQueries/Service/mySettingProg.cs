﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoQueries.Service
{
    public class mySettingProg
    {

        //public string SPath = @"D:\GTRM\";
        public string FileExtansion = @"RTF";
        //public string GTRMPath = @"D:\GTRM\";
        //public string CMSPath = @"D:\CMS\";
        //public string SFileNameGTRM = "Бонусы *.xml";
        ////var SPathArc = @"D:\Work\Archive\";
        //public string SPathArc = @"D:\GTRM\arc\";
        //public string sPathLog = @"D:\GTRM\Logs\";
        //public string SFileNameRARCMS = "clubs_tranz_*.rar";
        //public string SFileNameTXTCMS = "clubs_tranz_*.txt";
        //public string CMSWorkDir = @"D:\Work\temp\";
        //public bool DetailLog = false;


        public mySettingProg()
        {
            FileExtansion = Properties.Settings.Default.ActReestrTypeFile;
            //SPath = Properties.mySettings.Default.SPath;
            //GTRMPath = Properties.mySettings.Default.GTRMPath;
            //CMSPath = Properties.mySettings.Default.CMSPath;
            //SFileNameGTRM = Properties.mySettings.Default.SFileNameGTRM;
            //SPathArc = Properties.mySettings.Default.SPathArc;
            //sPathLog = Properties.mySettings.Default.sPathLog;
            //DetailLog = Properties.mySettings.Default.DetailLog;
            //SFileNameRARCMS = Properties.mySettings.Default.SFileNameRARCMS;
            //SFileNameTXTCMS = Properties.mySettings.Default.SFileNameTXTCMS;
            //CMSWorkDir = Properties.mySettings.Default.CMSWorkDir;
        }
    }
}
