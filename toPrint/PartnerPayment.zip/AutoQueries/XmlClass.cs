﻿
// Примечание. Для запуска созданного кода может потребоваться NET Framework версии 4.5 или более поздней версии и .NET Core или Standard версии 2.0 или более поздней.
/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
[System.Xml.Serialization.XmlRootAttribute(Namespace = "", IsNullable = false)]
public partial class DocumentXML
{

    private string dog_numField;

    private string dateField;

    private string fIO_BankField;

    private string oSN_BankField;

    private string name_OTSField;

    private string accountField;

    private string fIO_OTSField;

    private string oSN_OTSField;

    private string date_dogField;

    private string period_startField;

    private string period_finishField;

    private string uslugiField;

    private string sumField;

    private string sum_in_wordField;

    private string sum_coinsField;

    private string ndsField;

    private string nsd_in_wordField;

    private string nds_coinsField;

    private string info_OTSField;

    private string address_filialField;

    private ushort number_filialField;

    private string fio_bank_shortField;

    private string fio_bank_office1Field;
    private string fio_bank_office2Field;
    private string fio_bank_office3Field;
    private string fio_bank_office4Field;
    private string fio_bank_office5Field;
    private string fio_bank_office6Field;

    private DocumentXMLItems[] itemsField;

    private DocumentXMLTotals[] totalsField;

    private DocumentXMLResult resultField;

    /// <remarks/>
    public string Fio_Bank_Office1
    {
        get
        {
            return this.fio_bank_office1Field;
        }
        set
        {
            this.fio_bank_office1Field = value;
        }
    }
    /// <remarks/>
    public string Fio_Bank_Office2
    {
        get
        {
            return this.fio_bank_office2Field;
        }
        set
        {
            this.fio_bank_office2Field = value;
        }
    }
    /// <remarks/>
    public string Fio_Bank_Office3
    {
        get
        {
            return this.fio_bank_office3Field;
        }
        set
        {
            this.fio_bank_office3Field = value;
        }
    }
    /// <remarks/>
    public string Fio_Bank_Office4
    {
        get
        {
            return this.fio_bank_office4Field;
        }
        set
        {
            this.fio_bank_office4Field = value;
        }
    }
    /// <remarks/>
    public string Fio_Bank_Office5
    {
        get
        {
            return this.fio_bank_office5Field;
        }
        set
        {
            this.fio_bank_office5Field = value;
        }
    }
    /// <remarks/>
    public string Fio_Bank_Office6
    {
        get
        {
            return this.fio_bank_office6Field;
        }
        set
        {
            this.fio_bank_office6Field = value;
        }
    }
    /// <remarks/>
    public string Fio_Bank_Short
    {
        get
        {
            return this.fio_bank_shortField;
        }
        set
        {
            this.fio_bank_shortField = value;
        }
    }

    /// <remarks/>
    public string dog_num
    {
        get
        {
            return this.dog_numField;
        }
        set
        {
            this.dog_numField = value;
        }
    }

    /// <remarks/>
    public string date
    {
        get
        {
            return this.dateField;
        }
        set
        {
            this.dateField = value;
        }
    }

    /// <remarks/>
    public string FIO_Bank
    {
        get
        {
            return this.fIO_BankField;
        }
        set
        {
            this.fIO_BankField = value;
        }
    }

    /// <remarks/>
    public string OSN_Bank
    {
        get
        {
            return this.oSN_BankField;
        }
        set
        {
            this.oSN_BankField = value;
        }
    }

    /// <remarks/>
    public string Name_OTS
    {
        get
        {
            return this.name_OTSField;
        }
        set
        {
            this.name_OTSField = value;
        }
    }

    /// <remarks/>
    public string account
    {
        get
        {
            return this.accountField;
        }
        set
        {
            this.accountField = value;
        }
    }

    /// <remarks/>
    public string FIO_OTS
    {
        get
        {
            return this.fIO_OTSField;
        }
        set
        {
            this.fIO_OTSField = value;
        }
    }

    /// <remarks/>
    public string OSN_OTS
    {
        get
        {
            return this.oSN_OTSField;
        }
        set
        {
            this.oSN_OTSField = value;
        }
    }

    /// <remarks/>
    public string date_dog
    {
        get
        {
            return this.date_dogField;
        }
        set
        {
            this.date_dogField = value;
        }
    }

    /// <remarks/>
    public string period_start
    {
        get
        {
            return this.period_startField;
        }
        set
        {
            this.period_startField = value;
        }
    }

    /// <remarks/>
    public string period_finish
    {
        get
        {
            return this.period_finishField;
        }
        set
        {
            this.period_finishField = value;
        }
    }

    /// <remarks/>
    public string Uslugi
    {
        get
        {
            return this.uslugiField;
        }
        set
        {
            this.uslugiField = value;
        }
    }

    /// <remarks/>
    public string sum
    {
        get
        {
            return this.sumField;
        }
        set
        {
            this.sumField = value;
        }
    }

    /// <remarks/>
    public string sum_in_word
    {
        get
        {
            return this.sum_in_wordField;
        }
        set
        {
            this.sum_in_wordField = value;
        }
    }

    /// <remarks/>
    public string sum_coins
    {
        get
        {
            return this.sum_coinsField;
        }
        set
        {
            this.sum_coinsField = value;
        }
    }

    /// <remarks/>
    public string nds
    {
        get
        {
            return this.ndsField;
        }
        set
        {
            this.ndsField = value;
        }
    }

    /// <remarks/>
    public string nsd_in_word
    {
        get
        {
            return this.nsd_in_wordField;
        }
        set
        {
            this.nsd_in_wordField = value;
        }
    }

    /// <remarks/>
    public string nds_coins
    {
        get
        {
            return this.nds_coinsField;
        }
        set
        {
            this.nds_coinsField = value;
        }
    }

    /// <remarks/>
    public string Info_OTS
    {
        get
        {
            return this.info_OTSField;
        }
        set
        {
            this.info_OTSField = value;
        }
    }

    /// <remarks/>
    public string address_filial
    {
        get
        {
            return this.address_filialField;
        }
        set
        {
            this.address_filialField = value;
        }
    }

    /// <remarks/>
    public ushort number_filial
    {
        get
        {
            return this.number_filialField;
        }
        set
        {
            this.number_filialField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlElementAttribute("Items")]
    public DocumentXMLItems[] Items
    {
        get
        {
            return this.itemsField;
        }
        set
        {
            this.itemsField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlElementAttribute("Totals")]
    public DocumentXMLTotals[] Totals
    {
        get
        {
            return this.totalsField;
        }
        set
        {
            this.totalsField = value;
        }
    }

    /// <remarks/>
    public DocumentXMLResult Result
    {
        get
        {
            return this.resultField;
        }
        set
        {
            this.resultField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class DocumentXMLItems
{

    private int numberField;

    private System.DateTime transDateField;

    private string mIDField;

    private string nameField;

    private uint card9Field;

    private string sum205_226Field;

    private string sum206_225Field;

    private string compareField;

    private string procentField;

    private string debtField;

    /// <remarks/>
    public int number
    {
        get
        {
            return this.numberField;
        }
        set
        {
            this.numberField = value;
        }
    }

    /// <remarks/>
    [System.Xml.Serialization.XmlElementAttribute(DataType = "date")]
    public System.DateTime TransDate
    {
        get
        {
            return this.transDateField;
        }
        set
        {
            this.transDateField = value;
        }
    }

    /// <remarks/>
    public string MID
    {
        get
        {
            return this.mIDField;
        }
        set
        {
            this.mIDField = value;
        }
    }

    /// <remarks/>
    public string Name
    {
        get
        {
            return this.nameField;
        }
        set
        {
            this.nameField = value;
        }
    }

    /// <remarks/>
    public uint card9
    {
        get
        {
            return this.card9Field;
        }
        set
        {
            this.card9Field = value;
        }
    }

    /// <remarks/>
    public string sum205_226
    {
        get
        {
            return this.sum205_226Field;
        }
        set
        {
            this.sum205_226Field = value;
        }
    }

    /// <remarks/>
    public string sum206_225
    {
        get
        {
            return this.sum206_225Field;
        }
        set
        {
            this.sum206_225Field = value;
        }
    }

    /// <remarks/>
    public string compare
    {
        get
        {
            return this.compareField;
        }
        set
        {
            this.compareField = value;
        }
    }

    /// <remarks/>
    public string procent
    {
        get
        {
            return this.procentField;
        }
        set
        {
            this.procentField = value;
        }
    }

    /// <remarks/>
    public string debt
    {
        get
        {
            return this.debtField;
        }
        set
        {
            this.debtField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class DocumentXMLTotals
{

    private string nameCardField;

    private uint card9Field;

    private string sum205_226Field;

    private string sum206_225Field;

    private string compareField;

    private string debtField;

    /// <remarks/>
    public string NameCard
    {
        get
        {
            return this.nameCardField;
        }
        set
        {
            this.nameCardField = value;
        }
    }

    /// <remarks/>
    public uint card9
    {
        get
        {
            return this.card9Field;
        }
        set
        {
            this.card9Field = value;
        }
    }

    /// <remarks/>
    public string sum205_226
    {
        get
        {
            return this.sum205_226Field;
        }
        set
        {
            this.sum205_226Field = value;
        }
    }

    /// <remarks/>
    public string sum206_225
    {
        get
        {
            return this.sum206_225Field;
        }
        set
        {
            this.sum206_225Field = value;
        }
    }

    /// <remarks/>
    public string compare
    {
        get
        {
            return this.compareField;
        }
        set
        {
            this.compareField = value;
        }
    }

    /// <remarks/>
    public string debt
    {
        get
        {
            return this.debtField;
        }
        set
        {
            this.debtField = value;
        }
    }
}

/// <remarks/>
[System.SerializableAttribute()]
[System.ComponentModel.DesignerCategoryAttribute("code")]
[System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true)]
public partial class DocumentXMLResult
{

    private string textField;

    private string sum205_226Field;

    private string sum206_225Field;

    private string compareField;

    private string debtField;

    /// <remarks/>
    public string Text
    {
        get
        {
            return this.textField;
        }
        set
        {
            this.textField = value;
        }
    }

    /// <remarks/>
    public string sum205_226
    {
        get
        {
            return this.sum205_226Field;
        }
        set
        {
            this.sum205_226Field = value;
        }
    }

    /// <remarks/>
    public string sum206_225
    {
        get
        {
            return this.sum206_225Field;
        }
        set
        {
            this.sum206_225Field = value;
        }
    }

    /// <remarks/>
    public string compare
    {
        get
        {
            return this.compareField;
        }
        set
        {
            this.compareField = value;
        }
    }

    /// <remarks/>
    public string debt
    {
        get
        {
            return this.debtField;
        }
        set
        {
            this.debtField = value;
        }
    }
}

