﻿using System;


namespace AutoQueries
{
    public class ConvertForMonth
    {
        public string MonthForName(string month)
        {
            switch (month)
            {
                case "01": month = "1"; break;
                case "02": month = "2"; break;
                case "03": month = "3"; break;
                case "04": month = "4"; break;
                case "05": month = "5"; break;
                case "06": month = "6"; break;
                case "07": month = "7"; break;
                case "08": month = "8"; break;
                case "09": month = "9"; break;
                case "10": month = "A"; break;
                case "11": month = "B"; break;
                case "12": month = "C"; break;
            }
            return month;
        }

        public string DaySwitch(string daySwitch)
        {
            switch (daySwitch)
            {
                case "1": daySwitch = "1"; break;
                case "2": daySwitch = "2"; break;
                case "3": daySwitch = "3"; break;
                case "4": daySwitch = "4"; break;
                case "5": daySwitch = "5"; break;
                case "6": daySwitch = "6"; break;
                case "7": daySwitch = "7"; break;
                case "8": daySwitch = "8"; break;
                case "9": daySwitch = "9"; break;
                case "10": daySwitch = "A"; break;
                case "11": daySwitch = "B"; break;
                case "12": daySwitch = "C"; break;
                case "13": daySwitch = "D"; break;
                case "14": daySwitch = "E"; break;
                case "15": daySwitch = "F"; break;
                case "16": daySwitch = "G"; break;
                case "17": daySwitch = "H"; break;
                case "18": daySwitch = "I"; break;
                case "19": daySwitch = "J"; break;
                case "20": daySwitch = "K"; break;
                case "21": daySwitch = "L"; break;
                case "22": daySwitch = "M"; break;
                case "23": daySwitch = "N"; break;
                case "24": daySwitch = "O"; break;
                case "25": daySwitch = "P"; break;
                case "26": daySwitch = "Q"; break;
                case "27": daySwitch = "R"; break;
                case "28": daySwitch = "S"; break;
                case "29": daySwitch = "T"; break;
                case "30": daySwitch = "U"; break;
                case "31": daySwitch = "V"; break;
            }
            return daySwitch;
        }

        public DateTime FirstDayMonth(DateTime date)
        {
            DateTime answer = new DateTime(date.Year, date.Month, 1);
            return answer;
        }

        public DateTime LastDayMonth(DateTime date)
        {
            DateTime answer = new DateTime(date.Year, date.Month, DateTime.DaysInMonth(date.Year, date.Month));
            //DateTime answer = new DateTime(date.Year, date.Month,15);
            return answer;
        }
    }
}
