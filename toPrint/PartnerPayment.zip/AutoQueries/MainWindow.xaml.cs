﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Diagnostics;
using NLog;
using AutoQueries.Service;

namespace AutoQueries
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public delegate void DisplayHandler(List<View_Work_Exe> list);
        public PartnerPaymentEntities _db;
        public ConvertForMonth _convertForMonth;
        public EschfService _eschfService;
        public XmlService _xmlService;
        public DataUpdateService _dataUpdateService;
        public AktAndReestrService _aktAndReestrService;
        //static mySettingProg setting;

        System.Windows.Threading.DispatcherTimer dt = new System.Windows.Threading.DispatcherTimer();
        TimeSpan tmpInterval = new TimeSpan(0, 0, 0);
        int timerIntervalStep = 1;
        internal static class MyClass
        {
            public static byte flagWork { get; set; } = 0;
        }
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            logger.Info("Старт программы");
            //
            //setting = new mySettingProg();
            //

            lv.ItemsSource = workList();
            // таймер пошаговый
            dt.Interval = new TimeSpan(0, 0, timerIntervalStep);
            dt.Tick += dt_Tick;
            dt.Start();
            this.Closed += MainWindow_Closed;
        }

        void dt_Tick(object sender, EventArgs e)
        {
            List<View_Work_Exe> list = workList();
            TimeSpan procInterval = new TimeSpan(0, 0, 10);
            tmpInterval = tmpInterval + new TimeSpan(0, 0, timerIntervalStep);//таймер увеличение времени
            if (tmpInterval > procInterval) // если таймер больше интервала
            {
                tmpInterval = new TimeSpan(0);// таймер обнулить
                DisplayHandler handler = new DisplayHandler(Processing);
                if (MyClass.flagWork == 0)
                {
                    if (list.Count() > 0)
                    {
                        IAsyncResult resultObj = handler.BeginInvoke(list, null, null);
                    }
                }
            }
            operCount.Text = workList().Count().ToString();
            tbCount.Text = String.Format("{0}({1})", tmpInterval.ToString("ss"), procInterval.ToString("ss"));
            lv.ItemsSource = list;
        }

        void Processing(List<View_Work_Exe> list)
        {
            try
            {
                MyClass.flagWork = 1;
                _eschfService = new EschfService();
                _xmlService = new XmlService();
                _dataUpdateService = new DataUpdateService();
                _aktAndReestrService = new AktAndReestrService();

                foreach (View_Work_Exe data in list)
                {
                    if (data.flagDataUpdateExe == 1 && data.numBonusDog == "UPDATE")
                    //if (true)

                    {
                        logger.Info("Начато обоновление таблицы WorkNew");
                        _dataUpdateService.UpdateData(data);
                        logger.Info("Закончено обоновление таблицы WorkNew");
                        break;
                    }

                    if (data.flagXml == 1)
                    {
                        logger.Info("Начата отправка ПП в Клиент-банк");
                        _xmlService.XmlSend(list.Where(x => x.flagXml == 1).ToList());//----------------------
                        logger.Info("Закончена отправка ПП в Клиент-банк");
                        break;
                    }

                    if (data.flagXmlProsrochka == 1)
                    {
                        logger.Info("Начат процесс выноса на просрочку");
                        _xmlService.XmlProsrochkaSend(list.Where(x => x.flagXmlProsrochka == 1).ToList()); //---------------- Добавить отправку Латарии
                        logger.Info("Закончен процесс выноса на просрочку");
                        break;
                    }

                    if (data.flagPT == 1)
                    {
                        logger.Info("Начат процесс отправки требований");
                        _xmlService.PTSend(list.Where(x => x.flagPT == 1).ToList());     //------------------------
                        logger.Info("Закончен процесс отправки требований");
                        break;
                    }

                    if (data.flagESCHF == 1)
                    {
                        logger.Info("Начат процесс формирования файла с ЭСЧФ");
                        _eschfService.EscfSend(list.Where(x => x.flagESCHF == 1).ToList());   //------------------------
                        logger.Info("Закончен процесс формирования файла с ЭСЧФ");
                        break;
                    }

                    if (data.flagMail == "1")
                    {
                        logger.Info("Начат процесс формирования актов");
                        _aktAndReestrService.PreDoc(list.Where(x => x.flagMail == "1").ToList());
                        logger.Info("Закончен процесс формирования актов");
                        break;
                    }

                    if (data.flagMail == "3")
                    {
                        logger.Info("Начат процесс формирования отправки актов");
                        _aktAndReestrService.PreSend(list.Where(x => x.flagMail == "3").ToList());

                        logger.Info("Закончен процесс формирования отправки актов");
                        break;
                    }
                }
                MyClass.flagWork = 0;
            }
            catch (Exception ex)
            {
                MyClass.flagWork = 0;
                string sds = ex.Message;
                logger.Error("Ошибка работы метода Processing(Определяет какую операцию обрабатывать) +/r/n" + ex.Message + ex.InnerException);


                throw new Exception(ex.Message);
            }
        }

        void MainWindow_Closed(object sender, EventArgs e)
        {
            Process.GetCurrentProcess().Kill();
        }


        List<View_Work_Exe> workList()
        {
            using (_db = new PartnerPaymentEntities())
            {
                var collection = _db.View_Work_Exe.ToList();
                return collection;
            }
        }

        private void Window_Closed(object sender, EventArgs e)
        {
            logger.Info("Выход из программы");
        }
    }
}

//void Method()
//{
//    try
//    {
//        MyClass.flagWork = 1;
//        int result = 0;
//        for (int i = 1; i < 10; i++)
//        {
//            result += i * i;
//        }
//        Thread.Sleep(18000);

//        MyClass.flagWork = 0;
//    }
//    catch (Exception E)
//    {
//        string sdsd = "";
//        throw new Exception(E.Message);
//    }
//}
