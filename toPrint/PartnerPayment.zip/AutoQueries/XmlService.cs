﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Globalization;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using System.Data.Entity.Core.Objects;
using System.Configuration;
using MySql.Data.MySqlClient;
using NLog;
namespace AutoQueries
{
    public class XmlService
    {
        private PartnerPaymentEntities _db;
        private ConvertForMonth _convertForMonth;
        private webclientEntities _dbWeb;
        private MailService _mailService;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public void XmlSend(List<View_Work_Exe> listIn)
        {
            DateTime firstDay = listIn.First().dateFrom;
            DateTime lastDay = listIn.First().dateTo;
            int i = 1;
            _convertForMonth = new ConvertForMonth();
            string daySwitch = DateTime.Today.Day.ToString();
            string year = DateTime.Today.Year.ToString();
            string month = DateTime.Today.Month.ToString();
            string day = _convertForMonth.DaySwitch(daySwitch);
            string period = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(firstDay.Month) + " " + firstDay.Year.ToString();


            var month_for_name = _convertForMonth.MonthForName(month);
            int count = listIn.Count();
            try
            {
                foreach (var item in listIn)
                {
                    GTRM modelGtrm = modelGTRM(item.numBonusDog);
                    long number = numberDocument(month_for_name, day);
                    string filename = "CX" + month_for_name + day + number.ToString("000000") + "X.X47";
                    var p1 = year.Remove(0, 2) + DateTime.Today.Month.ToString("00") + DateTime.Today.Day.ToString("00");
                    string p13 = modelGtrm.account;
                    var p15 = "100325912";
                    var p16 = "Г.МИНСК, ОАО \"АСБ БЕЛАРУСБАНК\"";
                    var p5 = "AKBBBY2X";
                    var p6 = "Г.МИНСК, ОАО \"АСБ БЕЛАРУСБАНК\"";
                    var p22 = "BY29AKBB83708910000090000000";
                    var p23 = "100325912";
                    var p24 = "Г.МИНСК, ОАО \"АСБ БЕЛАРУСБАНК\"";
                    var p20 = "AKBBBY2X";
                    var p21 = "Г.МИНСК, ОАО \"АСБ БЕЛАРУСБАНК\"";
                    var p9 = "BYN";
                    decimal p10 = item.debt;
                    var p25 = "Доходы по консультационным и информационным услугам за участие в партнерской(бонусной) программе банка за " + period + " по договору " + modelGtrm.numBonusDog;
                    XDocument xdoc = new XDocument(new XDeclaration("1.0", "utf-16", "yes"), new XElement("object",
                        new XElement("common",
                            new XElement("doc_type", "20ПО"),
                            new XElement("filename", filename),
                            new XElement("P1", p1),
                            new XElement("P2", number),
                            new XElement("P3", "0401540106"),
                            new XElement("DP61", "123"),
                            new XElement("DP72", "59")),
                        new XElement("payer",
                            new XElement("P13", p13),
                            new XElement("P15", p15),
                            new XElement("P16", p16.ToUpper())),
                        new XElement("sender",
                                new XElement("P5", p5),
                                new XElement("P6", p6.ToUpper())),
                        new XElement("beneficiary",
                            new XElement("P22", p22),
                            new XElement("P23", p23),
                            new XElement("P24", p24)),
                        new XElement("receiver",
                            new XElement("P20", p20),
                            new XElement("P21", p21)),
                        new XElement("amount",
                            new XElement("P9", p9),
                            new XElement("P10", p10)),
                        new XElement("detpay",
                            new XElement("P25", p25),
                            new XElement("DP40", "6"))));
                    var pathf = Directory.GetCurrentDirectory();
                    var pathWay = Path.Combine(pathf, ConfigurationManager.AppSettings["FolderXML"].ToString(), filename);
                    xdoc.Save(pathWay);
                    string finalXML = File.ReadAllText(pathWay);
                    //
                    transferXml(finalXML, number);
                    //
                    saveNumberXML(filename.Remove(10, 5));
                    editStatusXml(item);
                    addCompare(item);
                    File.Delete(pathWay);
                    logger.Info($"Отправлено ПП по договору {item.numBonusDog} {DateTime.Now} период {period}. Записей: {i}/{count}");
                    i += 1;
                }
                logger.Info($"Все ЭД выгружены в Клиент-Банк{DateTime.Now}");
            }
            catch (Exception e)
            {
                logger.Error($"Ошибка отправки ПП {e.Message}-----------------" +
                    $"{e.StackTrace}");
                _mailService = new MailService();
                _mailService.SendErrorMessageLotus($"Ошибка отправки ПП {e.Message}-----------------" +
                    $"{e.StackTrace}");
                throw new Exception(e.Message);
            }
        }

        public void XmlProsrochkaSend(List<View_Work_Exe> listIn)
        {
            DateTime firstDay = listIn.First().dateFrom;
            DateTime lastDay = listIn.First().dateTo;
            _convertForMonth = new ConvertForMonth();
            DateTime date = DateTime.Now.AddMonths(-1);
            string daySwitch = DateTime.Today.Day.ToString();
            string year = DateTime.Today.Year.ToString();
            string month = DateTime.Today.Month.ToString();
            string day = _convertForMonth.DaySwitch(daySwitch);
            var month_for_name = _convertForMonth.MonthForName(month);
            string period = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(listIn.First().dateFrom.Month) + " " + listIn.First().dateFrom.Year.ToString();
            try
            {
                foreach (var item in listIn)
                {
                    //обрати внимание!!!!
                    if (DateTime.Now.AddMonths(-1).Month >= item.dateFrom.Month)
                    {
                        GTRM modelGtrm = modelGTRM(item.numBonusDog);
                        long number = numberDocument(month_for_name, day);
                        string filename = "CX" + month_for_name + day + number.ToString("000000") + "X.X47";
                        var p1 = DateTime.Today.Year.ToString().Remove(0, 2) + DateTime.Today.Month.ToString("00") + DateTime.Today.Day.ToString("00");
                        string p13 = "";
                        if (modelGtrm.account == "BY73AKBB67240000000150000000")
                        {
                            p13 = "BY76AKBB67548977000060000000";
                        }
                        else if (modelGtrm.account == "BY72AKBB67240000000280000000")
                        {
                            p13 = "BY75AKBB67548977000190000000";
                        }
                        var p15 = "100325912";
                        var p16 = "Г.МИНСК, ОАО \"АСБ БЕЛАРУСБАНК\"";
                        var p5 = "AKBBBY2X";
                        var p6 = "Г.МИНСК, ОАО \"АСБ БЕЛАРУСБАНК\"";
                        string p22 = modelGtrm.account;
                        var p23 = "100325912";
                        var p24 = "Г.МИНСК, ОАО \"АСБ БЕЛАРУСБАНК\"";
                        var p20 = "AKBBBY2X";
                        var p21 = "Г.МИНСК, ОАО \"АСБ БЕЛАРУСБАНК\"";
                        var p9 = "BYN";
                        decimal p10 = item.debt - Convert.ToDecimal(item.paymentOts);
                        var p25 = $"Просроченные доходы по консультационным и информационным услугам за участие в партнерской(бонусной) программе банка за {period} по договору {modelGtrm.numBonusDog}";
                        XDocument xdoc = new XDocument(new XDeclaration("1.0", "utf-16", "yes"), new XElement("object",
                            new XElement("common",
                                new XElement("doc_type", "20ПО"),
                                new XElement("filename", filename),
                                new XElement("P1", p1),
                                new XElement("P2", number),
                                new XElement("P3", "0401540106"),
                                new XElement("DP61", "123"),
                                new XElement("DP72", "59")),
                            new XElement("payer",
                                new XElement("P13", p13),
                                new XElement("P15", p15),
                                new XElement("P16", p16.ToUpper())),
                            new XElement("sender",
                                new XElement("P5", p5),
                                new XElement("P6", p6.ToUpper())),
                            new XElement("beneficiary",
                                new XElement("P22", p22),
                                new XElement("P23", p23),
                                new XElement("P24", p24)),
                            new XElement("receiver",
                                new XElement("P20", p20),
                                new XElement("P21", p21)),
                            new XElement("amount",
                                new XElement("P9", p9),
                                new XElement("P10", p10)),
                            new XElement("detpay",
                                new XElement("P25", p25),
                                new XElement("DP40", "6"))));
                        var pathf = Directory.GetCurrentDirectory();
                        var pathWay = Path.Combine(pathf, ConfigurationManager.AppSettings["FolderXML"].ToString(), filename);
                        xdoc.Save(pathWay);
                        logger.Info($"------------------------------------------------------------------------------------------------------------------");
                        logger.Info($"XML-файл создан в директории {pathWay}");
                        string finalXML = File.ReadAllText(pathWay);
                        transferXml(finalXML, number);
                        saveNumberXML(filename.Remove(10, 5));
                        logger.Info($"Изменен номер XML для ЭД");
                        editStatusXmlProsrochka(item);
                        logger.Info($"Изменен статус выноса на просрочку в таблице WorkNew");
                        File.Delete(pathWay);

                        logger.Info($"XML-файл удален из директории {pathWay}");
                        SendDataToReserve(item);
                        logger.Info($"Данные по договору {item.numBonusDog} отправлены в ПК по учету резерва");

                        logger.Info($"Осуществлен вынос на просрочку по договору {item.numBonusDog} {DateTime.Now}");
                        logger.Info($"------------------------------------------------------------------------------------------------------------------");
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error($"Ошибка выноса на просрочку ПП {e.Message}-----------------" +
                                $"{e.StackTrace}");
                _mailService = new MailService();
                _mailService.SendErrorMessageLotus($"Ошибка отправки ПП {e.Message}-----------------" +
                    $"{e.StackTrace}");
                throw new Exception(e.Message);
            }
        }


        public void PTSend(List<View_Work_Exe> listIn)
        {
            _mailService = new MailService();
            Random rnd1 = new Random();
            string numberForname = rnd1.Next(100000, 999999).ToString();
            string text = "";
            try
            {
                logger.Info($"Начало формирования данных для формирования ПТ {DateTime.Now}");
                foreach (var myItem in listIn)
                {
                    long unn = Convert.ToInt64(myItem.unn);
                    string period = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(((DateTime)myItem.dateFrom).Month) + " " + ((DateTime)myItem.dateFrom).Year.ToString();
                    period = period.ToUpper().Replace("СЕНТЯБРЬ 20", "СЕНТЯБРЬ20");
                    GTRM modelGtrm = modelGTRM(myItem.numBonusDog);
                    Random rnd = new Random();
                    DateTime dateDog = modelGtrm.dateBonusDog;
                    string number = rnd.Next(100000, 999999).ToString();
                    decimal p32 = myItem.debt - (decimal)myItem.paymentOts;
                    string p41 = modelGtrm.curNumbAccountOTS ?? "";
                    string p43 = modelGtrm.nameAllOTS != null ? modelGtrm.nameAllOTS.ToUpper() : "";
                    string p51 = modelGtrm.mfoBank ?? "";
                    string p81 = "";
                    string yy = dateDog.ToString("''yy");
                    string mm = dateDog.ToString("''MM");
                    string dd = dateDog.ToString("''dd");
                    if (modelGtrm.account == "BY72AKBB67240000000280000000")
                    {
                        p81 = "BY75AKBB67548977000190000000";
                    }
                    else if (modelGtrm.account == "BY73AKBB67240000000150000000")
                    {
                        p81 = "BY76AKBB67548977000060000000";
                    }
                    string p91 = $"Доходы по консультационным и информационным услугам за участие в партнерской(бонусной) программе банка за {period}";

                    string p92 = $"по договору {modelGtrm.numBonusDog} от {dateDog.ToShortDateString()}";
                    string replasedog = modelGtrm.numBonusDog != null ? modelGtrm.numBonusDog.Replace("-Бонус без эквайринга", "") : "";
                    text = text + "12" + number + "\r\n" +
                        "31BYN\r\n" +
                        $"32{p32}\r\n" +
                        "330\r\n" +
                        $"41{p41}\r\n" +
                        $"42{unn}\r\n" +
                        $"43{p43}\r\n" +
                        $"51{p51}\r\n" +
                        $"81{p81}\r\n" +
                        $"91{p91.ToUpper()}\r\n" +
                        $"92{p92.ToUpper()}\r\n" +
                        "9422\r\n" +
                           $"98{yy}{mm}{dd}\r\n" +
                            $"99{replasedog}\r\n" +
                        "Z12\r\n" +
                        "ZDBY\r\n" + "~\r\n";
                    editStatusPT(myItem);
                }
                var pathf = Directory.GetCurrentDirectory();
                string fileName = "pt" + numberForname + ".txt";
                var pathWay = System.IO.Path.Combine(pathf, ConfigurationManager.AppSettings["FolderPT"].ToString(), fileName);
                using (StreamWriter stream = new StreamWriter(pathWay, true, Encoding.GetEncoding(1251)))
                {
                    stream.Write(text);
                    logger.Info($"Данные с ПТ записаны по пути {pathWay} {DateTime.Now}");
                }
                _mailService.SendMessageLotus(pathWay, "ПТ");
            }
            catch (Exception e)
            {
                logger.Error($"Ошибка отправки ПТ {e.Message}-----------------" +
                              $"{e.StackTrace}");
                _mailService = new MailService();
                _mailService.SendErrorMessageLotus($"Ошибка отправки ПТ {e.Message}-----------------" +
                              $"{e.StackTrace}");
                throw new Exception(e.Message);
            }
        }


        public void SendMessageLotus(string fileName)
        {
            try
            {
                MailMessage message = new MailMessage
                {
                    Subject = "ПО Расчеты по партнерской программе",
                    From = new MailAddress("PartnerPayments@lotus.asb.by"),
                    Body = "Добрый день. Файл для импорта ПТ прилагается."
                };
                using (_db = new PartnerPaymentEntities())
                {
                    foreach (var item in _db.MailAddresses.ToList())
                    {
                        message.To.Add(item.email);
                    }
                }
                Attachment data = new Attachment(fileName, MediaTypeNames.Application.Octet);
                message.Attachments.Add(data);
                SmtpClient client = new SmtpClient(ConfigurationManager.AppSettings["MailAddress"].ToString());
                client.Send(message);
                client.Dispose();
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }
        List<View_Work_Exe> workList()
        {
            using (_db = new PartnerPaymentEntities())
            {
                return _db.View_Work_Exe.ToList();
            }
        }



        public void transferXml(string finalXML, long? number)
        {
            using (_dbWeb = new webclientEntities())
            {
                var outputParameter = new ObjectParameter("ErrorMessage", typeof(string));
                _dbWeb.InsertOrderForPayment(finalXML, "XX47", number, outputParameter);
                if (outputParameter.Value != null && !string.IsNullOrEmpty(outputParameter.Value.ToString()))
                {
                    throw new Exception();
                }
            }
        }
        public void saveNumberXML(string fileName)
        {
            using (_db = new PartnerPaymentEntities())
            {
                XML sda = _db.XML.Find(1);
                sda.number = fileName;
                _db.SaveChanges();
            }
        }
        public void editStatusXml(View_Work_Exe model)
        {
            using (_db = new PartnerPaymentEntities())
            {
                WorkNew sda = _db.WorkNew.Find(model.id);
                sda.flagXml = 2;
                _db.SaveChanges();
            }
        }
        public void addCompare(View_Work_Exe model)
        {
            using (_db = new PartnerPaymentEntities())
            {
                Compare sda = new Compare() { dateFrom = model.dateFrom, sum_kb = model.debt, numBonusDog = model.numBonusDog, ots = model.ots };
                _db.Compare.Add(sda);
                _db.SaveChanges();
            }
        }
        public void editStatusXmlProsrochka(View_Work_Exe model)
        {
            using (_db = new PartnerPaymentEntities())
            {
                WorkNew sda = _db.WorkNew.Find(model.id);
                sda.dateDebt = DateTime.Now.Date;
                sda.flagXmlProsrochka = 2;
                _db.SaveChanges();
            }
        }
        public void editStatusPT(View_Work_Exe model)
        {
            using (_db = new PartnerPaymentEntities())
            {
                WorkNew sda = _db.WorkNew.Find(model.id);
                sda.flagPT = 0;
                _db.SaveChanges();
            }
        }
        public GTRM modelGTRM(string numDog)
        {
            using (_db = new PartnerPaymentEntities())
            {
                //GTRM back = _db.GTRM.Where(x => x.acquiring == 0 && x.numBonusDog == numDog).ToList().Last();
                IQueryable<GTRM> back = _db.GTRM.Where(x => x.acquiring == 0 && x.numBonusDog == numDog);
                if (back.Count() > 0)
                {
                    var gtrmresult = back.ToList().Last();
                    return gtrmresult;
                }
                return new GTRM();
            }
        }
        internal string getNumberXML()
        {
            using (_db = new PartnerPaymentEntities())
            {
                return _db.XML.Select(x => x.number).FirstOrDefault();
            }
        }
        internal long numberDocument(string month_for_name, string day)
        {
            string numberXML = getNumberXML();
            string DayMonth = numberXML.Substring(2, 2);
            var number = 0;
            if (DayMonth == month_for_name + day)
            {
                number = Convert.ToInt32(numberXML.Substring(4, 6)) + 1;
            }
            else
            {
                number = 1;
            }
            string numb = number.ToString("000000");
            return Convert.ToInt64(number);

        }
        MySqlConnection conn = new MySqlConnection("server=cl-sql.bb.asb;database=reserve;user id=b00034509;password=12345678;persistsecurityinfo=True;SslMode=none");
        //MySqlConnection conn = new MySqlConnection("server=10.200.1.162;database=reserve;user id=b00034509;password=swapparol;persistsecurityinfo=True;");

        public void SendDataToReserve(View_Work_Exe model)
        {
            WorkNew listWork = new WorkNew();
            using (_db = new PartnerPaymentEntities())
            {
                listWork = _db.WorkNew.Find(model.id);
            }

            //string ping = conn.Ping().ToString();
            //string state = conn.State.ToString();
            string account = "";
            if (listWork.account == "BY72AKBB67240000000280000000")
            {
                account = "BY75AKBB67548977000190000000";
            }
            else if (listWork.account == "BY73AKBB67240000000150000000")
            {
                account = "BY76AKBB67548977000060000000";
            }
            decimal sum = ((decimal)listWork.paymentOts - listWork.debt) * (-1);
            string sumString = sum.ToString().Replace(",", ".");
            DateTime date = (DateTime)listWork.dateDebt;
            // var dasdas = Convert.ToDateTime(listWork.dateDebt).ToString("yyyy.mm.dd");
            string querry = $"insert into swap6754 set swAccount='{account}',swUnn='{listWork.unn}',swDateOverdue = '{date.ToString("yyyy.MM.dd")}',swSum = {sumString},swPaymentDate='{date.ToString("yyyy.MM.dd")}'";
            conn.Open();
            MySqlCommand cmd = new MySqlCommand(querry, conn);
            cmd.ExecuteReader();
            conn.Close();
        }



    }
}
