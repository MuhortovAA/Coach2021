﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace AutoQueries
{

    public class DataUpdateService
    {
        private PartnerPaymentEntities _db;
        private ConvertForMonth _convertForMonth;
        public MailService _mailService;
        private static Logger logger = LogManager.GetCurrentClassLogger();

        public void UpdateData(View_Work_Exe data)
        {
            _convertForMonth = new ConvertForMonth();
            int count = CountWorkNew();
            if (count < 20)
            //if (true)

            {
                List<sp_MailSettings_Result> spDiffList = listMailSettings();
                List<string> unnList = spDiffList.Select(x => x.NumBonusDog).Distinct().ToList();

                try
                {
                    foreach (string numBonusDog in unnList/*.Where(x => x == "791074422-Бонус без эквайринга")*/)
                    {
                        List<sp_MailSettings_Result> myList = spDiffList.Where(x => x.NumBonusDog == numBonusDog).ToList();
                        Add(myList);
                    }
                    deleteMyFlag("UPDATE");
                }
                catch (Exception e)
                {
                    logger.Error($"Ошибка обновления таблицы WorkNew {e.Message}-----------------" +
                        $"{e.StackTrace}");
                    _mailService = new MailService();
                    _mailService.SendErrorMessageLotus($"Ошибка обновления таблицы WorkNew {e.Message}-----------------" +
                        $"{e.StackTrace}");
                    throw new Exception(e.Message);
                }
            }
            else
            {
                deleteMyFlag("UPDATE");
            }
        }

        private void Add(List<sp_MailSettings_Result> item)
        {
            using (_db = new PartnerPaymentEntities())
            {
                try
                {

                    logger.Error($"Ожидается запись: 1 получено: {item.Count} UNN: {item.Last().UNN}");

                    WorkNew model = new WorkNew();
                    {
                        model.dateFrom = (DateTime)item.Last().dateFrom;
                        model.dateTo = (DateTime)item.Last().dateTo;
                        model.debt = (decimal)item.Last().debt;
                        model.ots = item.Last().OTC;
                        model.unn = item.Last().UNN;
                        model.numBonusDog = item.Last().NumBonusDog;
                        model.sumLastPaymentOts = 0;
                        model.paymentOts = 0;
                        model.flag = "0";
                        model.id = new int();
                        model.C205_226 = item.Sum(x => x.C205_226);
                        model.C206_225 = item.Sum(x => x.C206_225);
                        model.flagMail = item.Last().flag;
                        model.email = item.Last().email;
                        model.nds = Math.Round(model.debt * 20 / 120, 2, MidpointRounding.AwayFromZero);
                        model.loginSender = item.Last().loginSender;
                        model.dateSend = item.Last().dateSend;
                        model.account = item.Last().Account;
                        model.flagXml = 0;
                        model.flagXmlProsrochka = 0;
                        model.flagPT = 0;
                        model.flagESCHF = 0;
                        model.flagDataUpdateExe = 0;
                        model.filialSupport = item.Last().filialSupport.ToString();
                    }
                    if (model.debt > 0)
                    {
                        _db.WorkNew.Add(model);
                        _db.SaveChanges();
                        logger.Info($"Данные по договору {item.Last().NumBonusDog} добавлены в таблицу WorkNew {DateTime.Now}");
                    }
                    else
                    {
                        logger.Info($"Данные по договору {item.Last().NumBonusDog} не добавлены в таблицу WorkNew {DateTime.Now}, т.к. сумма по дебету меньше нуля и равна {model.debt}");

                    }

                }
                catch (Exception e)
                {
                    logger.Error($"Ошибка добавления данных по договору {item.Last().NumBonusDog} в таблицу WorkNew {e.Message}-----------------" +
                     $"{e.StackTrace}");
                    _mailService = new MailService();
                    _mailService.SendErrorMessageLotus($"Ошибка обновления таблицы WorkNew {e.Message}-----------------" +
                        $"{e.StackTrace}");
                    throw new Exception(e.Message);
                }
            }
        }


        private List<sp_MailSettings_Result> listMailSettings()
        {
            using (_db = new PartnerPaymentEntities())
            {
                _db.Database.CommandTimeout = 20000;
                DateTime date = DateTime.Now.Date.AddMonths(-1);
                var firstDay = _convertForMonth.FirstDayMonth(date);
                var lastDay = _convertForMonth.LastDayMonth(date);
                var result = _db.sp_MailSettings(firstDay, lastDay).OrderBy(x => x.NumBonusDog).ToList();
                return result;
            }
        }

        private int CountWorkNew()
        {
            using (_db = new PartnerPaymentEntities())
            {
                DateTime date = DateTime.Now.Date.AddMonths(-1);
                var firstDay = _convertForMonth.FirstDayMonth(date);
                var lastDay = _convertForMonth.LastDayMonth(date);
                return _db.WorkNew.Where(x => x.dateFrom == firstDay && x.dateTo == lastDay).Count();
            }
        }

        public void deleteMyFlag(string type)
        {
            using (_db = new PartnerPaymentEntities())
            {
                _convertForMonth = new ConvertForMonth();
                DateTime date = DateTime.Now.Date.AddMonths(-1);
                var firstDay = _convertForMonth.FirstDayMonth(date);
                var lastDay = _convertForMonth.LastDayMonth(date);
                WorkNew item = _db.WorkNew.Where(x => x.dateFrom == firstDay && x.dateTo == lastDay && x.numBonusDog == type).First();
                _db.WorkNew.Remove(item);
                _db.SaveChanges();
                logger.Info($"Запись-информатор удалена из таблицы WorkNew {DateTime.Now}");
            }
        }

    }

}


