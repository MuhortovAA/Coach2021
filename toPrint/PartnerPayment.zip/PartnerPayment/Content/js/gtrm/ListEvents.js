﻿function OnCreate() {
    $("#NkfoUnitAccountsWindow").kendoWindow().data("kendoWindow").refresh(createNkfoUnitAccountsApiPath);
    $("#NkfoUnitAccountsWindow").kendoWindow().data("kendoWindow").title("Создание записи в справочнике счетов НКФО");
    $("#NkfoUnitAccountsWindow").kendoWindow({
        modal: true
    }).data("kendoWindow").center().open();
}
function OnEdit(e) {
    e.preventDefault();
    var dataItem = this.dataItem($(e.currentTarget).closest("tr")).toJSON();
    $("#ModalWindow").kendoWindow({
        content: {
            url: update,
            type: "POST",
            data: { dataGTRM: dataItem }
        },
        modal: true
    }).data("kendoWindow").title("Редактирование записи").center().open();
}

function OnSave() {
    $("#NkfoUnitAccountsWindow").kendoWindow().data("kendoWindow").refresh(createNkfoUnitAccountsApiPath);
    $("#NkfoUnitAccountsWindow").kendoWindow().data("kendoWindow").title("Создание записи в справочнике счетов НКФО");
    $("#NkfoUnitAccountsWindow").kendoWindow({
        modal: true
    }).data("kendoWindow").center().open();
}