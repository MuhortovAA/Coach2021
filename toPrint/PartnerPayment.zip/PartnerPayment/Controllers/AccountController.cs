﻿using System;
using System.Web.Mvc;
using System.Web.Security;
using PartnerPayment.Infrastructure;
using PartnerPayment.Models;
using NLog;
using PPWorkCore;
using Kendo;
using Kendo.Mvc;
using PPWorkCore.Repository;

namespace PartnerPayment.Controllers
{
    public class AccountController : Controller
    {

        public static string USER = "USER";//
        private readonly UserRepository UserRepository;
        private static Logger logger = NLog.LogManager.GetCurrentClassLogger();
        public AccountController()
        {
            UserRepository = new UserRepository();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Login(UserModel user)
        {
            if (ModelState.IsValid)
            {
                if (user.Name != null && user.Password != null)
                {
                    var login = user?.Name?.Trim();
                    var password = ClassCrypt.StringToHex(ClassCrypt.Coding(user?.Password?.Trim()));
                    PPWorkCore.LUserARM_Result authorizedUser = null;
                    vBankUserInfo userInfo = null;
                    try
                    {
                        userInfo = UserRepository.GetUser(login);
                        if (userInfo != null)
                        {
                            ActionResult view;
                            if (IsAccessDenied(user, userInfo, out view)) return view;
                            authorizedUser = UserRepository.Authorization(login, password);
                            FormsAuthentication.SetAuthCookie(user.Name, true);
                            Session["userinfo"] = authorizedUser;
                            UserRepository.UnblockUserLogin(authorizedUser);
                            if (authorizedUser.DateChangePassword == null && DateTime.Compare(DateTime.Now, authorizedUser.DateCreation.AddDays((double)authorizedUser.PeriodChangePassword)) > 0)
                            {
                                return RedirectToAction("ChangePassword", "Account");
                            }
                            if (authorizedUser.DateChangePassword != null && DateTime.Compare(DateTime.Now, ((DateTime)authorizedUser.DateChangePassword).AddDays((double)authorizedUser.PeriodChangePassword)) > 0)
                            {
                                return RedirectToAction("ChangePassword", "Account");
                            }
                            if (authorizedUser.DateNewChangePassword != null && DateTime.Compare(DateTime.Now, (DateTime)authorizedUser.DateNewChangePassword) > 0)
                            {
                                return RedirectToAction("ChangePassword", "Account");
                            }
                            logger.Info("Пользователь " + login + " авторизировался в системе");
                            return RedirectToAction("Basical", "Home");
                        }
                        logger.Warn("Пользователь не зарегистрирован в системе " + login);
                        ModelState.AddModelError("", "Пользователь не зарегистрирован в системе.");
                    }
                    catch (Exception e)
                    {
                        int errorCode;
                        if (int.TryParse(e.Message, out errorCode))
                        {
                            if (errorCode == 1 || errorCode == 3 || errorCode == 4)
                            {
                                if (userInfo != null)
                                {
                                    UserRepository.BlockUserLogin(userInfo);
                                    ModelState.AddModelError("", ErrorMessage.GetErrorByCode(errorCode));
                                    logger.Error("Ошибка при входе в систему пользователя " + login + "\r\n" + e.Message + "\r\n" + e.StackTrace);
                                }
                            }
                        }
                        else
                        {
                            logger.Error("Ошибка сервера.Ошибка при входе в систему пользователя " + login + "\r\n" + errorCode + "\r\n" + e.Message + "\r\n" + e.InnerException.Message + "\r\n" + e.StackTrace);
                            ModelState.AddModelError("", "Ошибка сервера");
                        }
                    }
                }
                else
                {
                    ModelState.AddModelError("", "Не введен логин или пароль");
                }
            }
            return View(user);
        }

        private bool IsAccessDenied(UserModel user, vBankUserInfo userInfo, out ActionResult view)
        {
            if ((userInfo.bWork != null && !(bool)userInfo.bWork)
                || (DateTime.Now >= userInfo.DateBlock && DateTime.Now <userInfo.LastBlockDate ) == true)
            {
                logger.Error("Доступ пользователю " + userInfo.Login + " запрещен");
                ModelState.AddModelError("", "Доступ запрещен");
                FormsAuthentication.SignOut();
                {
                    view = View(user);
                    return true;
                }
            }
            if (userInfo.DateErrorLoginNo != null && DateTime.Compare(DateTime.Now, ((DateTime)userInfo.DateErrorLoginNo).AddHours(1)) <= 0)
            {
                logger.Error("Учетная запись " + userInfo.Login + $" заблокирована до {((DateTime)userInfo.DateErrorLoginNo).AddHours(1).ToString("dd.MM.yyyy HH: mm:ss")}");
                ModelState.AddModelError("", $"Учетная запись заблокирована до {((DateTime)userInfo.DateErrorLoginNo).AddHours(1).ToString("dd.MM.yyyy HH:mm:ss")}");
                FormsAuthentication.SignOut();
                {
                    view = View(user);
                    return true;
                }
            }
            view = null;
            return false;
        }

        public ActionResult Login()
        {
            return View();
        }

        public ActionResult ChangePassword()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult ChangePassword(ChangePasswordModel model)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var user = UserRepository.GetUser(User.Identity.Name);
                    string newPassword = ClassCrypt.StringToHex(ClassCrypt.Coding(model.NewPassword.Trim()));
                    if (newPassword.Equals(user.Password.Trim()))
                    {
                        logger.Warn("Данный пароль использовался ранее " + model.Login);
                        ModelState.AddModelError("", "Данный пароль использовался ранее.");
                        return View(model);
                    }
                    UserRepository.ChangePassword(user.id, newPassword);
                }
                catch (Exception)
                {
                    logger.Error("Ошибка при изменении пароля пользователя " + model.Login);
                    throw new Exception("Ошибка при изменении пароля");
                }
                logger.Info("Пароль успешно изменен" + model.Login);
                return RedirectToAction("Login", "Account");
            }
            return View(model);
        }

        public ActionResult Logoff()
        {
            string login = User.Identity.Name;
            if (!string.IsNullOrWhiteSpace(login) && !string.IsNullOrEmpty(login))
            {
                FormsAuthentication.SignOut();
                logger.Info("Пользователь вышел из системы " + login);
            }
            return RedirectToAction("Login", "Account");
        }

        public ActionResult Denied()
        {
            return View();
        }


        //public FileResult DownloadGuide()
        //{
        //    byte[] fileBytes = new byte[] { };
        //    string fileName = null;
        //    try
        //    {
        //        string path = Server.MapPath("/Manual/");
        //        fileBytes = System.IO.File.ReadAllBytes(Path.Combine(path, "Руководство потльзователя Akt_mbr_web.pdf"));
        //        fileName = "Руководство потльзователя Akt_mbr_web.pdf";
        //    }
        //    catch (Exception e)
        //    {
        //        throw new Exception("Ошибка скачивания мануала");
        //        // logger.Error("Ошибка при попытке скачать руководство пользователя. " + e.Message + "\r\n" + e.StackTrace);
        //    }
        //    return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        //}



    }


}