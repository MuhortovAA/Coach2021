﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PartnerPayment.Models;
using System.Web.Mvc;
using PPWorkCore;
using NLog;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Kendo.Mvc;
using PPWorkCore.Service;
using PPWorkCore.Repository;
using PartnerPayment.Providers;
using PartnerPayment.Infrastructure;

namespace PartnerPayment.Controllers
{
    public class MailAcqBankController : Controller
    {
        private UniteDataService _uniteDataService;
        private MailBankAcqService _mailBankAcqService;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public MailAcqBankController()
        {
            _uniteDataService = new UniteDataService();
            _mailBankAcqService = new MailBankAcqService();
        }
        public ActionResult MailAcqBank()
        {
            return View();
        }

        public PartialViewResult _MailAcqBankPartial()
        {
            IList<MailBankAcqModel> model = new List<MailBankAcqModel>();
            return PartialView(model);
        }

        [HttpPost]
        public void OnCalendarStartChanged(DateTime dateMonth)
        {
            Session["calendarMail"] = dateMonth;
        }
        public ActionResult MailAcqGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            IList<MailBankAcqModel> list = new List<MailBankAcqModel>();
            DataSourceResult result = null;
            if (Session["calendarMail"] == null)
            {
                Session["calendarMail"] = DateTime.Now;
            }
            if (Session["calendarMail"] != null)
            {
                DateTime date = (DateTime)Session["calendarMail"];
                Session["MailGridRequest"] = request;
                int pageSize = request.PageSize;
                int pageNumber = request.Page;
                SortDescriptor sortParameters = null;
                if (request.Sorts != null)
                {
                    sortParameters = request.Sorts.FirstOrDefault();
                }
                string sortedField = null;
                string sortedType = null;
                if (sortParameters != null)
                {
                    sortedField = sortParameters.Member;
                    sortedType = sortParameters.SortDirection.ToString();
                }

                var listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
                var filters = request.Filters?.FirstOrDefault();
                if (filters != null)
                {
                    listFilter = GetFilterList(filters);
                }

                list = _mailBankAcqService.GetItemsPerPage(date, pageSize, pageNumber, sortedField, sortedType, listFilter).Select<WorkAcqBank, MailBankAcqModel>(x => x).ToList();
                int totalCount = _mailBankAcqService.GetItemsTotal(date, pageSize, pageNumber, listFilter);
                result = new DataSourceResult()
                {
                    Data = list,
                    Total = totalCount,
                };
                return Json(result, JsonRequestBehavior.AllowGet);

            }
            return Json(list.ToDataSourceResult(request));
        }



        public List<KeyValuePair<string, KeyValuePair<string, string>>> GetFilterList(IFilterDescriptor filters)
        {
            List<KeyValuePair<string, KeyValuePair<string, string>>> listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            List<KeyValuePair<string, KeyValuePair<string, string>>> resultListFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            try
            {
                if (filters is FilterDescriptor)
                {
                    var filter = (FilterDescriptor)filters;
                    listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filter.Member, new KeyValuePair<string, string>(filter.Value.ToString().Trim(), filter.Operator.ToString())));
                }
                if (filters is CompositeFilterDescriptor)
                {
                    var filtersl = ((CompositeFilterDescriptor)filters).FilterDescriptors;
                    foreach (var filter in filtersl)
                    {
                        if (filter is FilterDescriptor)
                        {
                            var filterIn = (FilterDescriptor)filter;
                            listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                        }
                        if (filter is CompositeFilterDescriptor)
                        {
                            var itemFilters = ((CompositeFilterDescriptor)filter).FilterDescriptors;
                            foreach (var item in itemFilters)
                            {
                                var filterIn = (FilterDescriptor)item;
                                listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(e.Message + "\r\n" + e.StackTrace);
            }
            return listFilter;
        }

        [AccessDeniedAuthorize(Roles = CustomRoles.PART_USER)]
        public ActionResult DataUpdate()
        {
            TempData["noticeDataAcqUpdate"] = _mailBankAcqService.UpdateWorkAcq();
            logger.Info($"Пользователь {User.Identity.Name} {TempData["noticeDataAcqUpdate"].ToString()} обновил данные для работы в таблице WorkAcqBank");
            return View("MailAcqBank");
        }






        [HttpPost]
        public JsonResult BuildAkt()
        {
            DateTime date = (DateTime)Session["calendar"];
            string answer = _mailBankAcqService.BuildAkt(User.Identity.Name, date);
            logger.Info("Пользователь " + User.Identity.Name + " начал процедуру подготовки актов и реестров");
            return Json(answer, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult MailSend()
        {
            string answer = _mailBankAcqService.MailSend(User.Identity.Name);
            logger.Info("Пользователь " + User.Identity.Name + " отправил почту");
            return Json(answer, JsonRequestBehavior.AllowGet);
        }


        public ActionResult FilterMenuCustomization_Status()
        {
            IList<string> listBack = new List<string>();
            listBack.Add("Без статуса");
            listBack.Add("Подготовка акта");
            listBack.Add("Акт сформирован");
            listBack.Add("Отправка акта");
            listBack.Add("Акт отправлен ОТС");
            return Json(listBack, JsonRequestBehavior.AllowGet);
        }








        [HttpGet]
        public FileResult DownloadAkt(int id)
        {
            byte[] fileBytes = _mailBankAcqService.DownloadAkt(id);
            string fileName = _mailBankAcqService.NameAkt(id);
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }
        public ActionResult preSendAkt(int id)
        {
            WorkAcqBank model = _mailBankAcqService.GetModelById(id);
            return PartialView("_partialSendMailAcq");
        }

        public ActionResult SendAkt(MailBankAcqModel model)
        {
            logger.Info($"Пользователь {User.Identity.Name} пытается повторно отправить акт по id = {model.id} в таблице WorkNew");
            string answer = _mailBankAcqService.OnceSendingMail(model.id);
            return View("Mail");
        }
    }
}