﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PartnerPayment.Models;
using System.Web.Mvc;
using PPWorkCore;
using NLog;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Kendo.Mvc;
using PPWorkCore.Service;
using PPWorkCore.Repository;

namespace PartnerPayment.Controllers
{
    public class CompareController : Controller
    {
        private ConvertForMonth _convertForMonth;
        private UserRepository _userRepository;
            private CompareService _compareService;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public CompareController()
        {
            _convertForMonth = new ConvertForMonth();
            _userRepository = new UserRepository();
            _compareService = new CompareService();
        }

        public ActionResult Compare()
        {
            return View();
        }


        public PartialViewResult _ComparePartial()
        {
            IList<CompareModel> model = new List<CompareModel>();
            return PartialView(model);
        }

        [HttpPost]
        public void OnCalendarStartChanged(DateTime dateMonth)
        {
            Session["calendar"] = dateMonth;
        }
        public ActionResult CompareGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            IList<CompareModel> list = new List<CompareModel>();
            DataSourceResult result = null;
            if (Session["calendar"] == null)
            {
                Session["calendar"] = DateTime.Now;
            }
            if (Session["calendar"] != null)
            {
                DateTime date = (DateTime)Session["calendar"];
                Session["CompareGridRequest"] = request;
                int pageSize = request.PageSize;
                int pageNumber = request.Page;
                SortDescriptor sortParameters = null;
                if (request.Sorts != null)
                {
                    sortParameters = request.Sorts.FirstOrDefault();
                }
                string sortedField = null;
                string sortedType = null;
                if (sortParameters != null)
                {
                    sortedField = sortParameters.Member;
                    sortedType = sortParameters.SortDirection.ToString();
                }

                var listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
                var filters = request.Filters?.FirstOrDefault();
                if (filters != null)
                {
                    listFilter = GetFilterList(filters);
                }

                list = _compareService.GetItemsPerPage(date, pageSize, pageNumber, sortedField, sortedType, listFilter).Select<Compare, CompareModel>(x => x).ToList();
                int totalCount = _compareService.GetItemsTotal(date, pageSize, pageNumber, listFilter);
                result = new DataSourceResult()
                {
                    Data = list,
                    Total = totalCount,
                };
                return Json(result, JsonRequestBehavior.AllowGet);

            }
            return Json(list.ToDataSourceResult(request));
        }



        public List<KeyValuePair<string, KeyValuePair<string, string>>> GetFilterList(IFilterDescriptor filters)
        {
            List<KeyValuePair<string, KeyValuePair<string, string>>> listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            List<KeyValuePair<string, KeyValuePair<string, string>>> resultListFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            try
            {
                if (filters is FilterDescriptor)
                {
                    var filter = (FilterDescriptor)filters;
                    listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filter.Member, new KeyValuePair<string, string>(filter.Value.ToString().Trim(), filter.Operator.ToString())));
                }
                if (filters is CompositeFilterDescriptor)
                {
                    var filtersl = ((CompositeFilterDescriptor)filters).FilterDescriptors;
                    foreach (var filter in filtersl)
                    {
                        if (filter is FilterDescriptor)
                        {
                            var filterIn = (FilterDescriptor)filter;
                            listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                        }
                        if (filter is CompositeFilterDescriptor)
                        {
                            var itemFilters = ((CompositeFilterDescriptor)filter).FilterDescriptors;
                            foreach (var item in itemFilters)
                            {
                                var filterIn = (FilterDescriptor)item;
                                listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(e.Message + "\r\n" + e.StackTrace);
            }
            return listFilter;
        }
        public ActionResult FilterMenuCustomization_Status()
        {
            IList<string> listBack = new List<string>();
            listBack.Add("Ок");
            listBack.Add("Расхождение");
            return Json(listBack, JsonRequestBehavior.AllowGet);
        }

    }
}