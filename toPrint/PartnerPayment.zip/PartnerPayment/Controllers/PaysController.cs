﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PartnerPayment.Models;
using System.Web.Mvc;
using PPWorkCore;
using NLog;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Kendo.Mvc;
using PPWorkCore.Service;
using PPWorkCore.Repository;
namespace PartnerPayment.Controllers
{
    public class PaysController : Controller
    {
        private UniteDataService _uniteDataService;
        private ConvertForMonth _convertForMonth;
        private UserRepository _userRepository;
        private PaysService _paysService;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public PaysController()
        {
            _uniteDataService = new UniteDataService();
            _convertForMonth = new ConvertForMonth();
            _userRepository = new UserRepository();
            _paysService = new PaysService();
        }
        public ActionResult Pays()
        {
            return View();
        }


        public PartialViewResult _PaysPartial()
        {
            IList<OtsPaymentsModel> model = new List<OtsPaymentsModel>();
            return PartialView(model);
        }

        [HttpPost]
        public void OnCalendarStartChanged(DateTime dateMonth)
        {
            Session["calendar"] = dateMonth;
        }
        public ActionResult PaysGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            IList<OtsPaymentsModel> list = new List<OtsPaymentsModel>();
            DataSourceResult result = null;

            Session["GridRequest"] = request;
            int pageSize = request.PageSize;
            int pageNumber = request.Page;
            SortDescriptor sortParameters = null;
            if (request.Sorts != null)
            {
                sortParameters = request.Sorts.FirstOrDefault();
            }
            string sortedField = null;
            string sortedType = null;
            if (sortParameters != null)
            {
                sortedField = sortParameters.Member;
                sortedType = sortParameters.SortDirection.ToString();
            }

            var listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            var filters = request.Filters?.FirstOrDefault();
            if (filters != null)
            {
                listFilter = GetFilterList(filters);
            }

            list = _paysService.GetItemsPerPage( pageSize, pageNumber, sortedField, sortedType, listFilter).Select<OtsPayments, OtsPaymentsModel>(x => x).ToList();
            int totalCount = _paysService.GetItemsTotal( pageSize, pageNumber, listFilter);
            result = new DataSourceResult()
            {
                Data = list,
                Total = totalCount,
            };
            return Json(result, JsonRequestBehavior.AllowGet);



        }



        public List<KeyValuePair<string, KeyValuePair<string, string>>> GetFilterList(IFilterDescriptor filters)
        {
            List<KeyValuePair<string, KeyValuePair<string, string>>> listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            List<KeyValuePair<string, KeyValuePair<string, string>>> resultListFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            try
            {
                if (filters is FilterDescriptor)
                {
                    var filter = (FilterDescriptor)filters;
                    listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filter.Member, new KeyValuePair<string, string>(filter.Value.ToString().Trim(), filter.Operator.ToString())));
                }
                if (filters is CompositeFilterDescriptor)
                {
                    var filtersl = ((CompositeFilterDescriptor)filters).FilterDescriptors;
                    foreach (var filter in filtersl)
                    {
                        if (filter is FilterDescriptor)
                        {
                            var filterIn = (FilterDescriptor)filter;
                            listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                        }
                        if (filter is CompositeFilterDescriptor)
                        {
                            var itemFilters = ((CompositeFilterDescriptor)filter).FilterDescriptors;
                            foreach (var item in itemFilters)
                            {
                                var filterIn = (FilterDescriptor)item;
                                listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(e.Message + "\r\n" + e.StackTrace);
            }
            return listFilter;
        }



        public ActionResult PaysError()
        {
            return View();
        }


        public PartialViewResult _PaysErrorPartial()
        {
            IList<PaymentErrorModel> model = new List<PaymentErrorModel>();
            return PartialView(model);
        }

        public ActionResult PaysErrorGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            IList<PaymentErrorModel> list = new List<PaymentErrorModel>();
            DataSourceResult result = null;

            Session["GridRequest"] = request;
            int pageSize = request.PageSize;
            int pageNumber = request.Page;
            SortDescriptor sortParameters = null;
            if (request.Sorts != null)
            {
                sortParameters = request.Sorts.FirstOrDefault();
            }
            string sortedField = null;
            string sortedType = null;
            if (sortParameters != null)
            {
                sortedField = sortParameters.Member;
                sortedType = sortParameters.SortDirection.ToString();
            }

            var listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            var filters = request.Filters?.FirstOrDefault();
            if (filters != null)
            {
                listFilter = GetFilterList(filters);
            }

            list = _paysService.GetErrorItemsPerPage(pageSize, pageNumber, sortedField, sortedType, listFilter).Select<PaymentError, PaymentErrorModel>(x => x).ToList();
            int totalCount = _paysService.GetErrorItemsTotal(pageSize, pageNumber, listFilter);
            result = new DataSourceResult()
            {
                Data = list,
                Total = totalCount,
            };
            return Json(result, JsonRequestBehavior.AllowGet);
            // return Json(list.ToDataSourceResult(request));
        }



        public ActionResult OnEditErrorPay(int id)
        {
            logger.Info($"Пользователь {User.Identity.Name} открыл окно изменения неустановленного платежа.");
            PaymentErrorModel errorPay = _paysService.GetRequirementById(id);
            return PartialView("_OnEditErrorPay", errorPay);
        }



        public ActionResult ServerFilter_UNP(string unn)
        {
            var unplist = _paysService.GetUnpList(unn).OrderBy(s => s.unn);

            return Json(unplist, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SaveUpdatedErrorPays(string text, string dogIn, PaymentError model)
        {
            //_paysService.ErrorPayToWorkNew(dogIn, model.id, text);
            _paysService.ErrorPayToWorkNew2(dogIn, model.id, text);
            logger.Info($"Пользователь {User.Identity.Name} изменил состояние неустановленного платежа по договору {dogIn}");

            return View("PaysError");
        }
        //public ActionResult SaveUpdatedErrorPays2(string id, string text, string dogIn, PaymentError model)
        //{



        //    _paysService.ErrorPayToWorkNew2(id, dogIn, model.id, text);
        //    logger.Info($"Пользователь {User.Identity.Name} изменил состояние неустановленного платежа по договору {dogIn}");

        //    return View("PaysError");
        //}



    }
}