﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PartnerPayment.Models;
using System.Web.Mvc;
using PPWorkCore;
using NLog;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Kendo.Mvc;
using System.Web.Security;
using PPWorkCore.Service;
using PPWorkCore.Repository;
using PartnerPayment.Providers;
using PartnerPayment.Infrastructure;


namespace PartnerPayment.Controllers
{
    public class HomeController : Controller
    {
        private UniteDataService _uniteDataService;
        private UserRepository _userRepository;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public HomeController()
        {
            _uniteDataService = new UniteDataService();
            _userRepository = new UserRepository();

        }
        [HttpGet]
        public ActionResult Basical()
        {
            // _uniteDataService.getDelayPdf();
            return View();
        }
        [HttpPost]
        public ActionResult Basical(WorkNewModel data)
        {
            return RedirectToAction("Basical");
        }

        [HttpPost]
        public ActionResult Update(WorkNewModel data, string PaymentOTS, string debt)
        {
            try
            {
                var sum1 = Convert.ToDecimal(PaymentOTS.Replace('.',','));
                var sum2 = Convert.ToDecimal(debt.Replace('.', ','));
                var flag = sum1 == sum2 ? "1" : "0";
                TempData["paymentOTS"] = _uniteDataService.UpdateWork(PaymentOTS, data.id.ToString(), flag);
                logger.Info($"Пользователь {User.Identity.Name} обновил данные по сумме платежа {PaymentOTS} для записи {data.id}");
            }
            catch (Exception ex)
            {
                TempData["paymentOTS"] = $"Ошибка при преобразовании данных";
                logger.Info($"Невозможно выполнить преобразование сумм из формы {ex.Message}: {PaymentOTS} и {debt} для записи {data.id}");
            }
            return RedirectToAction("Basical");
        }

        public PartialViewResult _BasicalPartial()
        {
            IList<WorkNewModel> model = new List<WorkNewModel>();
            return PartialView(model);
        }


        [HttpPost]
        public void OnCalendarStartChanged(DateTime dateMonth)
        {
            Session["calendar"] = dateMonth;
        }


        public ActionResult DebtGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            if (User.Identity.IsAuthenticated)
            {
                var user = _userRepository.GetUser(User.Identity.Name);
                IList<WorkNewModel> list = new List<WorkNewModel>();
                DataSourceResult result = null;
                if (Session["calendar"] == null)
                {
                    Session["calendar"] = DateTime.Now.AddDays(-30);
                }
                if (Session["calendar"] != null)
                {
                    if (user.Login != "")
                    {
                        DateTime date = (DateTime)Session["calendar"];
                        Session["DebtGridRequest"] = request;
                        int pageSize = request.PageSize;
                        int pageNumber = request.Page;
                        SortDescriptor sortParameters = null;
                        if (request.Sorts != null)
                        {
                            sortParameters = request.Sorts.FirstOrDefault();
                        }
                        string sortedField = null;
                        string sortedType = null;
                        if (sortParameters != null)
                        {
                            sortedField = sortParameters.Member;
                            sortedType = sortParameters.SortDirection.ToString();
                        }
                        var listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
                        var filters = request.Filters?.FirstOrDefault();
                        if (filters != null)
                        {
                            listFilter = GetFilterList(filters);
                        }
                        var idroly = _userRepository.GetNameRoliByUserId(user.id);
                        string filial = _userRepository.GetUserInfo(user.Login, idroly).Branch;
                        try
                        {
                            //List<WorkNew> list8 = _uniteDataService.GetItemsPerPage(date, pageSize, pageNumber, sortedField, sortedType, listFilter, filial).ToList();
                            list = _uniteDataService.GetItemsPerPage(date, pageSize, pageNumber, sortedField, sortedType, listFilter, filial).Select<WorkNew, WorkNewModel>(x => x).ToList();
                        }
                        catch (Exception e)
                        {
                            string sd = e.ToString();
                        }
                        Session["sumDebt"] = list.Sum(x => x.debt);
                        Session["sumPayments"] = list.Sum(x => x.paymentOts);
                        int totalCount = _uniteDataService.GetItemsTotal(date, pageSize, pageNumber, listFilter, filial);
                        result = new DataSourceResult()
                        {
                            Data = list,
                            Total = totalCount,
                        };
                        return Json(result, JsonRequestBehavior.AllowGet);
                    }
                }
                return Json(list.ToDataSourceResult(request));
            }
            else
            {
                return View("Login", "Account");
            }
        }



        public List<KeyValuePair<string, KeyValuePair<string, string>>> GetFilterList(IFilterDescriptor filters)
        {
            List<KeyValuePair<string, KeyValuePair<string, string>>> listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            List<KeyValuePair<string, KeyValuePair<string, string>>> resultListFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            try
            {
                if (filters is FilterDescriptor)
                {
                    var filter = (FilterDescriptor)filters;
                    listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filter.Member, new KeyValuePair<string, string>(filter.Value.ToString().Trim(), filter.Operator.ToString())));
                }
                if (filters is CompositeFilterDescriptor)
                {
                    var filtersl = ((CompositeFilterDescriptor)filters).FilterDescriptors;
                    foreach (var filter in filtersl)
                    {
                        if (filter is FilterDescriptor)
                        {
                            var filterIn = (FilterDescriptor)filter;
                            listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                        }
                        if (filter is CompositeFilterDescriptor)
                        {
                            var itemFilters = ((CompositeFilterDescriptor)filter).FilterDescriptors;
                            foreach (var item in itemFilters)
                            {
                                var filterIn = (FilterDescriptor)item;
                                listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(e.Message + "\r\n" + e.StackTrace);
            }
            return listFilter;
        }
        public ActionResult FilterMenuCustomization_Accounts()
        {
            return Json(_uniteDataService.AccountsListFilter(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult FilterMenuCustomization_Status()
        {
            IList<string> listBack = new List<string>();
            listBack.Add("Оплачено");
            listBack.Add("Не оплачено");
            listBack.Add("Частично оплачено");
            listBack.Add("Оплачено больше");
            return Json(listBack, JsonRequestBehavior.AllowGet);
        }
        [AccessDeniedAuthorize(Roles = CustomRoles.PART_USER)]
        public ActionResult DataUpdate()
        {
            TempData["noticeDataUpdate"] = _uniteDataService.UpdateWork("UPDATE");
            logger.Info($"Пользователь {User.Identity.Name} {TempData["noticeDataUpdate"].ToString()} обновил данные для работы");
            return View("Basical");
        }
        [AccessDeniedAuthorize(Roles = CustomRoles.PART_USER)]
        public ActionResult XML()
        {
            TempData["notice"] = _uniteDataService.HandlerWork("XML", (DateTime)Session["calendar"]);
            logger.Info("Пользователь " + User.Identity.Name + " выгрузил ЭД в ПК\"Клиент-банк\"");
            return RedirectToAction("Basical");
        }
        [AccessDeniedAuthorize(Roles = CustomRoles.PART_USER)]
        public ActionResult ManagerESCF()
        {
            TempData["noticeESCHF"] = _uniteDataService.HandlerWork("ESCHF", (DateTime)Session["calendar"]);
            logger.Info("Пользователь " + User.Identity.Name + " сформировал файл ЭСЧФ");
            return RedirectToAction("Basical");
        }
        [AccessDeniedAuthorize(Roles = CustomRoles.PART_USER)]
        public ActionResult DocumentsPT()
        {
            DateTime date = (DateTime)Session["calendar"];
            TempData["noticePT"] = _uniteDataService.HandlerWork("PT", (DateTime)Session["calendar"]);
            logger.Info("Пользователь " + User.Identity.Name + " выгрузил ЭД по формированию требований в ПК\"Клиент-банк\"");
            return RedirectToAction("Basical");
        }
        [AccessDeniedAuthorize(Roles = CustomRoles.PART_USER)]
        public ActionResult XmlProsroch()
        {
            DateTime date = (DateTime)Session["calendar"];
            TempData["noticeProsrochka"] = _uniteDataService.HandlerWork("XmlProsroch", (DateTime)Session["calendar"]);
            logger.Info("Пользователь " + User.Identity.Name + " выгрузил ЭД по выносу на просрочку в ПК\"Клиент-банк\"");
            return RedirectToAction("Basical");
        }
        [AccessDeniedAuthorize(Roles = CustomRoles.PART_USER)]
        public ActionResult StatisticsPage(DateTime date)
        {
            logger.Info($"Пользователь {User.Identity.Name} открыл окно статистики.");
            var user = _userRepository.GetUser(User.Identity.Name);
            var idroly = _userRepository.GetNameRoliByUserId(user.id);
            string filial = _userRepository.GetUserInfo(user.Login, idroly).Branch;
            List<WorkNew> workList = _uniteDataService.getWorkList(date, filial);
            List<WorkNew> workListAll = _uniteDataService.getWorkListAll();
            string acc15 = "BY73AKBB67240000000150000000";
            string acc28 = "BY72AKBB67240000000280000000";
            ViewBag.Name1 = "Задолженность за месяц";
            ViewBag.Name2 = "Оплачено";
            ViewBag.Name3 = "Не погашено за месяц";
            ViewBag.Name4 = "Не погашено за все время";
            ViewBag.Acc15_1 = workList.Where(x => x.account == acc15).Sum(x => x.debt);
            ViewBag.Acc15_2 = (decimal)workList.Where(x => x.account == acc15).Sum(x => x.paymentOts);
            ViewBag.Acc15_3 = workList.Where(x => x.account == acc15).Sum(x => x.debt) - (decimal)workList.Where(x => x.account == acc15).Sum(x => x.paymentOts);
            ViewBag.Acc28_1 = workList.Where(x => x.account == acc28).Sum(x => x.debt);
            ViewBag.Acc28_2 = (decimal)workList.Where(x => x.account == acc28).Sum(x => x.paymentOts);
            ViewBag.Acc28_3 = workList.Where(x => x.account == acc28).Sum(x => x.debt) - (decimal)workList.Where(x => x.account == acc28).Sum(x => x.paymentOts);
            ViewBag.All_1 = workList.Sum(x => x.debt);
            ViewBag.All_2 = (decimal)workList.Sum(x => x.paymentOts);
            ViewBag.All_3 = workList.Sum(x => x.debt) - (decimal)workList.Sum(x => x.paymentOts);
            ViewBag.Acc15_4 = workListAll.Where(x => x.account == acc15).Sum(x => x.debt) - (decimal)workListAll.Where(x => x.account == acc15).Sum(x => x.paymentOts);
            ViewBag.Acc28_4 = workListAll.Where(x => x.account == acc28).Sum(x => x.debt) - (decimal)workListAll.Where(x => x.account == acc28).Sum(x => x.paymentOts);
            ViewBag.All_4 = workListAll.Sum(x => x.debt) - (decimal)workListAll.Sum(x => x.paymentOts);
            return PartialView("_Statistics");
        }

        public ActionResult DelayPage()
        {
            List<WorkNew> listWithDelay = _uniteDataService.DelayList45();
            List<DelayModel> workList = new List<DelayModel>();
            foreach (var item in listWithDelay)
            {
                DelayModel sds = new DelayModel()
                {
                    id = item.id,
                    ots = item.ots,
                    numDog = item.numBonusDog,
                    dateDebt = (DateTime)item.dateDebt,
                    firstDay = item.dateFrom,
                    dateDelay = DateTime.Now.Subtract((DateTime)item.dateDebt).Days,
                    debt = item.debt,
                    paymentOts = (decimal)item.paymentOts
                };
                workList.Add(sds);
            }
            return PartialView("_DelayList", workList);
        }

        public ActionResult SendDelayToQueries()
        {
            return View("Basical");
        }


        public ActionResult ForwardPreSend()
        {
            return PartialView("_partialForwardPreSend");
        }
        public ActionResult ForwardPreSendG818()
        {
            return PartialView("_partialForwardG818");
        }
        public ActionResult ForwardPreSendG1030()
        {
            return PartialView("_partialForwardG1030");
        }
        public ActionResult ForwardSendG818()
        {
            _uniteDataService.SendForwardG818();
            TempData["noticeForward"] = "Данные по G818 отправляются в ИАС'Форвард'";
            return View("Basical");
        }
        public ActionResult ForwardSendG1030()
        {
            _uniteDataService.SendForwardG1030();
            TempData["noticeForward"] = "Данные по G1030 отправляются в ИАС'Форвард'";
            return View("Basical");
        }



        //public ActionResult ForwardSend()
        //{
        //   _uniteDataService.SendForward();
        //    TempData["noticeForward"] = "Данные отправляются в ИАС'Форвард'";
        //    return View("Basical");
        //}



    }
}
