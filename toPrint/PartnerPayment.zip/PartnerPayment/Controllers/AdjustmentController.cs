﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PartnerPayment.Models;
using System.Web.Mvc;
using PPWorkCore;
using NLog;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Kendo.Mvc;
using System.Web.Security;
using PPWorkCore.Service;
using PPWorkCore.Repository;
using PartnerPayment.Providers;
using PartnerPayment.Infrastructure;
namespace PartnerPayment.Controllers
{
    public class AdjustmentController : Controller
    {
        private AdjustmentService _adjustmentService;
        private UserRepository _userRepository;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public AdjustmentController()
        {
            _adjustmentService = new AdjustmentService();
            _userRepository = new UserRepository();

        }
        public ActionResult Adjustment()
        {
            _adjustmentService.FileExist();
            return View();
        }
        public PartialViewResult _adjustmentPartial(DateTime? start, DateTime? end, string dog, string MID)
        {
            Session["MID"] = MID;
            Session["dateStart"] = start;
            Session["dateEnd"] = end;
            IList<ReestrModel> model = new List<ReestrModel>();
            return PartialView(model);
        }

        public ActionResult AdjustmentGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            if (Session["dateStart"] == null && (Session["dateEnd"] == null))
            {
                Session["dateStart"] = DateTime.Now;
                Session["dateEnd"] = DateTime.Now;
            }
            //DataSourceResult result = null;
            DateTime dateStart = (DateTime)Session["dateStart"];
            DateTime dateEnd = (DateTime)Session["dateEnd"];
            string numDog = "";
            if (Session["numDogAdj"] != null)
            {
                numDog = Session["numDogAdj"].ToString();
            }
            Session["DebtGridRequest"] = request;
            string MID = "";
            if (Session["MID"] != null)
            {
                MID = Session["MID"].ToString();
            }
            int pageSize = request.PageSize;
            Session["PageSize"] = pageSize;
            int pageNumber = request.Page;
            Session["PageNumber"] = pageNumber;
            IList<ReestrModel> list = _adjustmentService.GetItemsPerPage(numDog, MID, dateStart, dateEnd, pageSize, pageNumber).Select<sp_Reestr_Result, ReestrModel>(x => x).ToList();
            int totalCount = _adjustmentService.GetReestr(numDog, MID, dateStart, dateEnd).Select<sp_Reestr_Result, ReestrModel>(x => x).Count();
            list = TakeId(list);
            DataSourceResult result = new DataSourceResult()
            {
                Data = list,
                Total = totalCount,
            };
            return Json(result, JsonRequestBehavior.AllowGet);
        }


        public ActionResult DogList(string numDog)
        {

            List<string> sds = _adjustmentService.GetDogList(numDog);
            return Json(sds, JsonRequestBehavior.AllowGet);
        }
        public ActionResult MidList(string dog)
        {
            Session["numDogAdj"] = dog;
            List<string> sds = _adjustmentService.GetMidList(dog);
            return Json(sds, JsonRequestBehavior.AllowGet);
        }

        public IList<ReestrModel> TakeId(IList<ReestrModel> inList)
        {
            int i = 1;
            foreach (var item in inList)
            {
                item.id = i;
                i++;
            }
            return inList;
        }
        public ActionResult AdjustmentAccept(int[] array)
        {
            DateTime dateStart = (DateTime)Session["dateStart"];
            DateTime dateEnd = (DateTime)Session["dateEnd"];
            string numDog = Session["numDogAdj"].ToString();
            string MID = Session["MID"].ToString();
            int pageSize = Convert.ToInt32(Session["PageSize"]);
            int pageNumber = Convert.ToInt32(Session["PageNumber"]);
            IList<ReestrModel> list = _adjustmentService.GetItemsPerPage(numDog, MID, dateStart, dateEnd, pageSize, pageNumber).Select<sp_Reestr_Result, ReestrModel>(x => x).ToList();
            List<ReestrModel> NewList = new List<ReestrModel>();
            foreach (int i in array)
            {
                NewList.Add(list[i-1]);
            } 
            _adjustmentService.BuildAktandESCHF(dateStart,dateEnd,numDog,NewList.Select<ReestrModel, sp_Reestr_Result>(x => x).ToList());
            

            string sdas = "";
            return View();
        }
        



    }
}