﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PartnerPayment.Models;
using System.Web.Mvc;
using PPWorkCore;
using NLog;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Kendo.Mvc;
using PPWorkCore.Service;
using PPWorkCore.Repository;
using System.IO;

namespace PartnerPayment.Controllers
{
    public class MailController : Controller
    {
        private MailService _mailService;
        private UserRepository _userRepository;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public MailController()
        {
            _mailService = new MailService();
            _userRepository = new UserRepository();
        }
        public ActionResult Mail()
        {
            return View();
        }

        public PartialViewResult _MailPartial()
        {
            IList<WorkNewModel> model = new List<WorkNewModel>();
            return PartialView(model);
        }

        [HttpPost]
        public void OnCalendarStartChanged(DateTime dateMonth)
        {
            Session["calendarMail"] = dateMonth;
        }
        public ActionResult MailGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            IList<WorkNewModel> list = new List<WorkNewModel>();
            DataSourceResult result = null;
            if (Session["calendarMail"] == null)
            {
                Session["calendarMail"] = DateTime.Now;
            }
            if (Session["calendarMail"] != null)
            {
                DateTime date = (DateTime)Session["calendarMail"];
                Session["MailGridRequest"] = request;
                int pageSize = request.PageSize;
                int pageNumber = request.Page;
                SortDescriptor sortParameters = null;
                if (request.Sorts != null)
                {
                    sortParameters = request.Sorts.FirstOrDefault();
                }
                string sortedField = null;
                string sortedType = null;
                if (sortParameters != null)
                {
                    sortedField = sortParameters.Member;
                    sortedType = sortParameters.SortDirection.ToString();
                }

                var listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
                var filters = request.Filters?.FirstOrDefault();
                if (filters != null)
                {
                    listFilter = GetFilterList(filters);
                }
                vBankUserInfo user = _userRepository.GetUser(User.Identity.Name);
                var idroly = _userRepository.GetNameRoliByUserId(user.id);
                string filial = _userRepository.GetUserInfo(user.Login, idroly).Branch;

                list = _mailService.GetItemsPerPage(date, pageSize, pageNumber, sortedField, sortedType, listFilter, filial).Select<WorkNew, WorkNewModel>(x => x).ToList();
                int totalCount = _mailService.GetItemsTotal(date, pageSize, pageNumber, listFilter, filial);
                result = new DataSourceResult()
                {
                    Data = list,
                    Total = totalCount,
                };
                return Json(result, JsonRequestBehavior.AllowGet);

            }
            return Json(list.ToDataSourceResult(request));
        }



        public List<KeyValuePair<string, KeyValuePair<string, string>>> GetFilterList(IFilterDescriptor filters)
        {
            List<KeyValuePair<string, KeyValuePair<string, string>>> listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            List<KeyValuePair<string, KeyValuePair<string, string>>> resultListFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            try
            {
                if (filters is FilterDescriptor)
                {
                    var filter = (FilterDescriptor)filters;
                    listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filter.Member, new KeyValuePair<string, string>(filter.Value.ToString().Trim(), filter.Operator.ToString())));
                }
                if (filters is CompositeFilterDescriptor)
                {
                    var filtersl = ((CompositeFilterDescriptor)filters).FilterDescriptors;
                    foreach (var filter in filtersl)
                    {
                        if (filter is FilterDescriptor)
                        {
                            var filterIn = (FilterDescriptor)filter;
                            listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                        }
                        if (filter is CompositeFilterDescriptor)
                        {
                            var itemFilters = ((CompositeFilterDescriptor)filter).FilterDescriptors;
                            foreach (var item in itemFilters)
                            {
                                var filterIn = (FilterDescriptor)item;
                                listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(e.Message + "\r\n" + e.StackTrace);
            }
            return listFilter;
        }

        [HttpPost]
        public JsonResult BuildAkt()
        {
            DateTime date = (DateTime)Session["calendar"];
            string answer = _mailService.BuildAkt(User.Identity.Name, date);
            logger.Info("Пользователь " + User.Identity.Name + " начал процедуру подготовки актов и реестров");
            return Json(answer, JsonRequestBehavior.AllowGet);
        }


        [HttpPost]
        public JsonResult MailSend(DateTime dateMonth)
        {
            DateTime date = (DateTime)Session["calendar"];
            string answer = _mailService.MailSend(User.Identity.Name);
            logger.Info("Пользователь " + User.Identity.Name + " отправил почту");
            return Json(answer, JsonRequestBehavior.AllowGet);
        }


        public ActionResult FilterMenuCustomization_Status()
        {
            IList<string> listBack = new List<string>();
            listBack.Add("Без статуса");
            listBack.Add("Подготовка акта");
            listBack.Add("Акт сформирован");
            listBack.Add("Отправка акта");
            listBack.Add("Акт отправлен ОТС");
            return Json(listBack, JsonRequestBehavior.AllowGet);
        }
        [HttpGet]
        public FileResult DownloadAkt(int id)
        {
            byte[] fileBytes =_mailService.DownloadAkt(id);
            string fileName = _mailService.NameAkt(id);
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }


        public ActionResult preSendAkt(int id)
        {
            WorkNewModel model = _mailService.GetModelById(id);
            return PartialView("_partialSendMail", model);
        }

        public ActionResult SendAkt(WorkNewModel model)
        {           
            logger.Info($"Пользователь {User.Identity.Name} пытается повторно отправить акт по id = {model.id} в таблице WorkNew");
           string answer=  _mailService.OnceSendingMail(model.id);
            return View("Mail");
        }

    }
}