﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PartnerPayment.Models;
using System.Web.Mvc;
using PPWorkCore;
using NLog;
using Kendo.Mvc.Extensions;
using Kendo.Mvc.UI;
using Kendo.Mvc;
using PPWorkCore.Service;
using PPWorkCore.Repository;

namespace PartnerPayment.Controllers
{
    public class GTRMController : Controller
    {
        private static Logger logger = LogManager.GetCurrentClassLogger();
        private GtrmService _gtrmService;
        public ActionResult GTRM()
        {
            _gtrmService = new GtrmService();
            return View();
        }
        [HttpPost]
        public ActionResult GTRM([DataSourceRequest] DataSourceRequest dsRequest, GTRMmodel dataGTRM)
        {

            return View();
        }

        public PartialViewResult _GTRMPartial()
        {
            IList<GTRMmodel> model = new List<GTRMmodel>();
            return PartialView(model);
        }

        public ActionResult GTRMGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            _gtrmService = new GtrmService();
            IList<GTRMmodel> list = new List<GTRMmodel>();
            DataSourceResult result = null;

            Session["GTRMGrid"] = request;
            int pageSize = request.PageSize;
            int pageNumber = request.Page;
            SortDescriptor sortParameters = null;
            if (request.Sorts != null)
            {
                sortParameters = request.Sorts.FirstOrDefault();
            }
            string sortedField = null;
            string sortedType = null;
            if (sortParameters != null)
            {
                sortedField = sortParameters.Member;
                sortedType = sortParameters.SortDirection.ToString();
            }

            var listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            var filters = request.Filters?.FirstOrDefault();
            if (filters != null)
            {
                listFilter = GetFilterList(filters);
            }

            list = _gtrmService.GetItemsPerPage(pageSize, pageNumber, sortedField, sortedType, listFilter).Select<GTRM, GTRMmodel>(x => x).ToList();
            int totalCount = _gtrmService.GetItemsTotal(pageSize, pageNumber, listFilter);
            result = new DataSourceResult()
            {
                Data = list,
                Total = totalCount,
            };
            return Json(result, JsonRequestBehavior.AllowGet);


        }

        public List<KeyValuePair<string, KeyValuePair<string, string>>> GetFilterList(IFilterDescriptor filters)
        {
            List<KeyValuePair<string, KeyValuePair<string, string>>> listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            List<KeyValuePair<string, KeyValuePair<string, string>>> resultListFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            try
            {
                if (filters is FilterDescriptor)
                {
                    var filter = (FilterDescriptor)filters;
                    listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filter.Member, new KeyValuePair<string, string>(filter.Value.ToString().Trim(), filter.Operator.ToString())));
                }
                if (filters is CompositeFilterDescriptor)
                {
                    var filtersl = ((CompositeFilterDescriptor)filters).FilterDescriptors;
                    foreach (var filter in filtersl)
                    {
                        if (filter is FilterDescriptor)
                        {
                            var filterIn = (FilterDescriptor)filter;
                            listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                        }
                        if (filter is CompositeFilterDescriptor)
                        {
                            var itemFilters = ((CompositeFilterDescriptor)filter).FilterDescriptors;
                            foreach (var item in itemFilters)
                            {
                                var filterIn = (FilterDescriptor)item;
                                listFilter.Add(new KeyValuePair<string, KeyValuePair<string, string>>(filterIn.Member, new KeyValuePair<string, string>(filterIn.Value.ToString().Trim(), filterIn.Operator.ToString())));
                            }
                        }
                    }
                }
            }
            catch (Exception e)
            {
                logger.Error(e.Message + "\r\n" + e.StackTrace);
            }
            return listFilter;
        }

        public ActionResult FilterMenuCustomization_Works()
        {
            IList<string> listBack = new List<string>();
            listBack.Add("Действующие");
            listBack.Add("Не действующие");
            return Json(listBack, JsonRequestBehavior.AllowGet);
        }
        public ActionResult GTRMAddress()
        {
            return View();
        }

        public PartialViewResult _GTRMAddressPartial()
        {
            IList<GTRMmodel> model = new List<GTRMmodel>();
            return PartialView(model);
        }
        public ActionResult GTRMAddressGrid_Read([DataSourceRequest] DataSourceRequest request)
        {
            _gtrmService = new GtrmService();
            IList<GTRMmodel> list = new List<GTRMmodel>();
            DataSourceResult result = null;

            Session["GTRMAddressGrid"] = request;
            int pageSize = request.PageSize;
            int pageNumber = request.Page;
            SortDescriptor sortParameters = null;
            if (request.Sorts != null)
            {
                sortParameters = request.Sorts.FirstOrDefault();
            }
            string sortedField = null;
            string sortedType = null;
            if (sortParameters != null)
            {
                sortedField = sortParameters.Member;
                sortedType = sortParameters.SortDirection.ToString();
            }

            var listFilter = new List<KeyValuePair<string, KeyValuePair<string, string>>>();
            var filters = request.Filters?.FirstOrDefault();
            if (filters != null)
            {
                listFilter = GetFilterList(filters);
            }

            list = _gtrmService.GetItemsPerPageAddress(pageSize, pageNumber, sortedField, sortedType, listFilter).Select<GTRM, GTRMmodel>(x => x).ToList();
            int totalCount = _gtrmService.GetItemsAddressTotal(pageSize, pageNumber, listFilter);
            result = new DataSourceResult()
            {
                Data = list,
                Total = totalCount,
            };
            return Json(result, JsonRequestBehavior.AllowGet);


        }

        [HttpPost]
        public ActionResult Update(GTRMmodel data)
        {
            //return PartialView("_EditGTRM", new GTRM() { account = dataGTRM.account });
            return PartialView("_EditGTRM", new GTRM() { account = data.account });
        }
        [HttpPost]
        public ActionResult Update2([DataSourceRequest] DataSourceRequest dsRequest, GTRMmodel dataGTRM)
        {
            if (dataGTRM != null && ModelState.IsValid)
            {
                //var toUpdate = persons.FirstOrDefault(p => p.PersonID == person.PersonID);
                //TryUpdateModel(toUpdate);
            }


            //return PartialView("_EditGTRM", new GTRM() { account = dataGTRM.account });
            return PartialView("_EditGTRM", new GTRM() { account = dataGTRM.account });
        }
    }
}