﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PartnerPayment.Providers
{
    public static class CustomRoles
    {
        //public const string CRF_Administrator = "ЦРФ_Администратор";
        public const string PART_USER = "Партнерка_Пользователь";
        public const string PART_GUEST = "Партнерка_Сеть";

    }
}