﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Security;
using PartnerPayment.Enums;
using PPWorkCore;
using PPWorkCore.Repository;

namespace PartnerPayment.Providers
{
    public class CustomRoleProvider : RoleProvider
    {

        private readonly UserRepository UserRepository;

        public CustomRoleProvider()
        {
            UserRepository = new UserRepository();
        }
        public override bool IsUserInRole(string username, string roleName)
        {
            bool outputResult = false;
            // Находим пользователя


            // Получаем пользователя
            vBankUserInfo user = UserRepository.GetUser(username);
            if (user != null)
            {
                if (user.bWork != null && !(bool)user.bWork)
                {
                    FormsAuthentication.SignOut();
                    return false;
                }
                if (user.DateBlock != null && DateTime.Compare(DateTime.Now, (DateTime)user.DateBlock) >= 0)
                {
                    FormsAuthentication.SignOut();
                    return false;
                }
                if (user.DateBlockLogin != null &&
                    DateTime.Compare(DateTime.Now, (DateTime)user.DateBlockLogin) >= 0)
                {
                    FormsAuthentication.SignOut();
                    return false;
                }

                // получаем роль
                string role = null;
                //int roleID = user.IDRoli;

                //if (roleID == 38 || roleID == 57)
                //{
                //    role = CustomRoles.User;
                //}
                //if (roleID == 39 || roleID == 55)
                //{
                //    role = CustomRoles.Administrator;
                //}
                //if (roleID == 40 || roleID == 56)
                //{
                //    role = CustomRoles.Administrator_otdelenia;
                //}
                //if (roleID == 41 || roleID == 59)
                //{
                //    role = CustomRoles.CBY;
                //}
                //if (roleID == 42 || roleID == 58)
                //{
                //    role = CustomRoles.Branch;
                //}
                //if (roleID == 47 || roleID == 55)
                //{
                //    role = CustomRoles.Administrator_Tax;
                //}
                List<int> politic = UserRepository.GetPoliticByIDRoli(user.IDRoli);
                Dictionary<TypeObject, TypeAccess> UserAccess;
                var result = AnalyzePolitic(politic, out UserAccess);
                if (result)
                {
                    role = GetRole(UserAccess);
                }
                //сравниваем
                if (role != null && role == roleName)
                {
                    outputResult = true;
                }
            }
            return outputResult;
        }


        public override string[] GetRolesForUser(string username)
        {
            string[] role = { };
            vBankUserInfo user = UserRepository.GetUser(username);
            if (user != null)
            {
                if (user.bWork != null && !(bool)user.bWork)
                {
                    FormsAuthentication.SignOut();
                }
                if (user.DateBlock != null && DateTime.Compare(DateTime.Now, (DateTime)user.DateBlock) >= 0)
                {
                    FormsAuthentication.SignOut();
                }
                if (user.DateBlockLogin != null &&
                    DateTime.Compare(DateTime.Now, (DateTime)user.DateBlockLogin) >= 0)
                {
                    FormsAuthentication.SignOut();
                }
                string userRole = null;
                //получаем роль
                //if (user.IDRoli == 38 || user.IDRoli == 57)
                //{
                //    userRole = CustomRoles.User;
                //}
                //if (user.IDRoli == 39 || user.IDRoli == 55)
                //{
                //    userRole = CustomRoles.Administrator;
                //}
                //if (user.IDRoli == 40 || user.IDRoli == 56)
                //{
                //    userRole = CustomRoles.Administrator_otdelenia;
                //}
                //if (user.IDRoli == 41 || user.IDRoli == 59)
                //{
                //    userRole = CustomRoles.CBY;
                //}
                //if (user.IDRoli == 42 || user.IDRoli == 58)
                //{
                //    userRole = CustomRoles.Branch;
                //}
                //if (user.IDRoli == 47 || user.IDRoli == 55)
                //{
                //    userRole = CustomRoles.Administrator_Tax;
                //}
                //if (userRole != null)
                //    role = new string[] { userRole };
                List<int> politic = UserRepository.GetPoliticByIDRoli(user.IDRoli);
                Dictionary<TypeObject, TypeAccess> UserAccess;
                var result = AnalyzePolitic(politic, out UserAccess);
                if (result)
                {
                    userRole = GetRole(UserAccess);
                    role = new string[] { userRole };
                }
            }
            return role;
        }

        private string GetRole(Dictionary<TypeObject, TypeAccess> UserAccess)
        {
            string role = null;
            if (UserAccess[TypeObject.GTRM].Equals(TypeAccess.FullRights) &&
                UserAccess[TypeObject.ESCHF].Equals(TypeAccess.FullRights) &&
                UserAccess[TypeObject.MAILSEND].Equals(TypeAccess.FullRights) &&
                UserAccess[TypeObject.ODB].Equals(TypeAccess.FullRights) &&
                UserAccess[TypeObject.OPERATIONS].Equals(TypeAccess.FullRights))
            {
                role = CustomRoles.PART_USER;
            }
            if (UserAccess[TypeObject.GTRM].Equals(TypeAccess.FullRights) &&
                      UserAccess[TypeObject.ESCHF].Equals(TypeAccess.AccessDenied) &&
                      UserAccess[TypeObject.MAILSEND].Equals(TypeAccess.AccessDenied) &&
                      UserAccess[TypeObject.ODB].Equals(TypeAccess.AccessDenied) &&
                      UserAccess[TypeObject.OPERATIONS].Equals(TypeAccess.FullRights))
            {
                role = CustomRoles.PART_GUEST;

            }
            return role;
        }

        public override void CreateRole(string roleName)
        {

        }

        public override bool DeleteRole(string roleName, bool throwOnPopulatedRole)
        {
            throw new NotImplementedException();
        }

        public override bool RoleExists(string roleName)
        {
            throw new NotImplementedException();
        }

        public override void AddUsersToRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override void RemoveUsersFromRoles(string[] usernames, string[] roleNames)
        {
            throw new NotImplementedException();
        }

        public override string[] GetUsersInRole(string roleName)
        {
            throw new NotImplementedException();
        }

        public override string[] GetAllRoles()
        {
            throw new NotImplementedException();
        }

        public override string[] FindUsersInRole(string roleName, string usernameToMatch)
        {
            throw new NotImplementedException();
        }

        public override string ApplicationName { get; set; }

        public bool AnalyzePolitic(IList<int> politic, out Dictionary<TypeObject, TypeAccess> AccessUser)
        {
            AccessUser = new Dictionary<TypeObject, TypeAccess>();
            int y = politic.Count;
            for (int x = 0; x < y; x++)
            {
                int ID_Object = (int)(politic[x] & 255);          //Код объекта |битовая операция И
                int ID_Access = (int)((politic[x] & 65280) >> 8); //Код прав доступа | битовая операция И | битовая операция смещение в право на 8
                if (Enum.IsDefined(typeof(TypeObject), ID_Object) == true && Enum.IsDefined(typeof(TypeAccess), ID_Access) == true)
                {
                    TypeObject to = (TypeObject)Enum.Parse(typeof(TypeObject), ID_Object.ToString(), true);
                    TypeAccess ta = (TypeAccess)Enum.Parse(typeof(TypeAccess), ID_Access.ToString(), true);
                    if (AccessUser.ContainsKey(to) == false)
                        AccessUser.Add(to, ta);
                    else
                        return false;
                }
                else
                    return false;
            }
            return true;
        }
    }
}