﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PartnerPayment.Enums
{
    /// <summary>
    /// Списко вариантов доступа к объектам
    /// </summary>
    public enum TypeAccess
    {
        AccessDenied = 1,   //Доступ запрещен
        View = 2,           //Просмотр
        FullRights = 3      //Полные права
    }
}