﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PartnerPayment.Enums
{
    /// <summary>
    /// Список объектов для доступа
    /// </summary>
    public enum TypeObject
    {
        GTRM = 75, //GTRM
        ESCHF = 76, //ESCHF
        MAILSEND = 77, //отправка почты
        ODB = 73 ,//Пачка в ОДБ
        OPERATIONS=74

        //DOCUMENTS = 44,      //Реестр Документы
        //HANDBOOKS = 45,      //Реестр Справочники
        //PROTOCOL = 46,       //Реестр Протокол
        //UPLOAD_FILES = 47,   //Загрузка файлов
        //REPORTS = 48,        //Создание отчетов
        //UNBLOCK = 49,         //Разблокировка записей
        //UNBLOCK_TAX = 55    //Разблокировка отчета ИМНС
    }
}