﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPWorkCore;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace PartnerPayment.Models
{
    public class OtsPaymentsModel
    {
        public int id { get; set; }
        public System.DateTime datePayment { get; set; }
        public long? unnRecipient { get; set; }
        public long? unnPayer { get; set; }
        public string customer { get; set; }
        public string detPay { get; set; }
        public decimal sumPayment { get; set; }
        public string accountPay { get; set; }
        public string numDoc { get; set; }
        public DateTime dateFrom { get; set; }
        public DateTime dateTo { get; set; }
        public string numBonusDog { get; set; }
        public string ots { get; set; }
        public string datePaymentFormat { get; set; }
        public string dateFromFormat { get; set; }
        public string dateToFormat { get; set; }
        public string period { get; set; }


        public static implicit operator OtsPaymentsModel(OtsPayments value)
        {
            OtsPaymentsModel item = new OtsPaymentsModel();
            {
                item.id = value.id;
                item.ots = value.ots;
                item.unnRecipient = value.unnRecipient;
                item.unnPayer = value.unnPayer;
                item.datePayment = value.datePayment;
                item.sumPayment = value.sumPayment;
                item.dateFrom = value.dateFrom;
                item.dateTo = value.dateTo;
                item.detPay = value.detPay;
                item.numDoc = value.numDoc;
                item.customer = value.customer;
                item.numBonusDog = value.numBonusDog;
                item.accountPay = value.accountPay;
                item.datePaymentFormat = value.datePayment.ToShortDateString();
                item.dateFromFormat = value.dateFrom.ToShortDateString();
                item.dateToFormat = value.dateTo.ToShortDateString();
                item.period = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(value.dateFrom.Month) + " " + value.dateFrom.Year.ToString();
            }
            return item;
        }
        public static implicit operator OtsPayments(OtsPaymentsModel value)
        {
            return new OtsPayments()
            {
                id = value.id,
                ots = value.ots,
                unnRecipient = value.unnRecipient,
                unnPayer = value.unnPayer,
                datePayment = value.datePayment,
                sumPayment = value.sumPayment,
                dateFrom = value.dateFrom,
                dateTo = value.dateTo,
                detPay = value.detPay,
                numBonusDog = value.numBonusDog,
                customer = value.customer,
                accountPay = value.accountPay,
                numDoc= value.numDoc
            };
        }
    }
}


