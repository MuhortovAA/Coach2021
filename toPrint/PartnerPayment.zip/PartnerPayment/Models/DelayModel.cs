﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PartnerPayment.Models
{
    public class DelayModel
    {
        public int id { get; set; }
        public string ots { get; set; }
        public string numDog { get; set; }
        public DateTime dateDebt { get; set; }
        public DateTime firstDay { get; set; }
        public int dateDelay { get; set; }
        public decimal debt { get; set; }
        public decimal paymentOts { get; set; }
    }
}