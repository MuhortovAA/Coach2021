﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPWorkCore;
using System.ComponentModel.DataAnnotations;

namespace PartnerPayment.Models
{
    public class WorkNewModel
    {
        public int id { get; set; }
        //[UIHint("Number")]
        public string unn { get; set; }
        public string ots { get; set; }
        public decimal C205_226 { get; set; }
        public string numBonusDog { get; set; }
        public decimal C206_225 { get; set; }
        public decimal proc { get; set; }
        public decimal Base_payment { get; set; }
        [Display(Name = "Долг", Description = "Укажите долг")]
        [UIHint("debt")]
        public decimal debt { get; set; }
        public System.DateTime dateFrom { get; set; }
        public System.DateTime dateTo { get; set; }
        public string flag { get; set; }
        [Display(Name = "Оплата", Description = "Укажите оплату")]
        public Nullable<decimal> paymentOts { get; set; }
        public Nullable<decimal> sumLastPaymentOts { get; set; }
        public Nullable<System.DateTime> dateLastPayment { get; set; }
        public Nullable<System.DateTime> dateNullPayment { get; set; }
        public string loginSender { get; set; }
        public Nullable<System.DateTime> dateSend { get; set; }
        public string flagMail { get; set; }
        public string email { get; set; }
        public decimal nds { get; set; }
        public string account { get; set; }
        public short flagXml { get; set; }
        public short flagXmlProsrochka { get; set; }
        public string dateFromFormat { get; set; }
        public string dateToFormat { get; set; }
        public string dateLastPaymentFormat { get; set; }
        public string dateNullPaymentFormat { get; set; }
        public string dateSendFormat { get; set; }

        public Nullable<System.DateTime> dateDebt { get; set; }

        public string typeDebt { get; set; }
        public decimal diff { get; set; }
        public string statusMail { get; set; }
        public string filialSupport { get; set; }

        public static implicit operator WorkNewModel(WorkNew value)
        {
            WorkNewModel item = new WorkNewModel();
            {
                item.id = value.id;
                item.unn = value.unn;
                item.ots = value.ots;
                item.C205_226 = value.C205_226;
                item.C206_225 = value.C206_225;
                item.debt = value.debt;
                item.dateFrom = value.dateFrom;
                item.dateTo = value.dateTo;
                item.flag = value.flag;
                item.paymentOts = value.paymentOts;
                item.sumLastPaymentOts = value.sumLastPaymentOts;
                item.dateLastPayment = value.dateLastPayment;
                item.dateNullPayment = value.dateNullPayment;
                item.loginSender = value.loginSender;
                item.dateSend = value.dateSend;
                item.flagMail = value.flagMail;
                item.email = value.email;
                item.nds = value.nds;
                item.account = value.account;
                item.flagXml = value.flagXml;
                item.flagXmlProsrochka = value.flagXmlProsrochka;
                item.dateDebt = value.dateDebt;
                item.numBonusDog = value.numBonusDog;
                item.dateFromFormat = value.dateFrom.ToShortDateString();
                item.dateToFormat = value.dateTo.ToShortDateString();
      

                if (value.dateLastPayment == (DateTime?)null)
                {
                    item.dateLastPaymentFormat = "Нет платежей";
                }
                else
                {
                    item.dateLastPaymentFormat = Convert.ToDateTime(value.dateLastPayment).ToShortDateString();

                }
                if (value.dateSend == (DateTime?)null)
                {
                    item.dateSendFormat = "Не отправлено";
                }
                else
                {
                    item.dateSendFormat = Convert.ToDateTime(value.dateSend).ToShortDateString();

                }
                item.dateNullPaymentFormat = Convert.ToDateTime(value.dateNullPayment).ToShortDateString();

                item.diff = item.debt - (decimal)item.paymentOts;
                if (item.diff == 0)
                {
                    item.typeDebt = "Оплачено";
                }
                else if (item.paymentOts == 0)
                {
                    item.typeDebt = "Не оплачено";
                }
                else if (item.debt > item.paymentOts && item.paymentOts > 0)
                {
                    item.typeDebt = "Частично оплачено";
                }
                else if (item.paymentOts > item.debt)
                {
                    item.typeDebt = "Оплачено больше";
                }

                switch (item.flagMail)
                {
                    case "0": item.statusMail = "Без статуса"; break;
                    case "1": item.statusMail = "Подготовка акта"; break;
                    case "2": item.statusMail = "Акт сформирован"; break;
                    case "3": item.statusMail = "Отправка акта"; break;
                    case "4": item.statusMail = "Акт отправлен ОТС"; break;
                }
                item.filialSupport = value.filialSupport;

            }
            return item;

        }
        public static implicit operator WorkNew(WorkNewModel value)
        {
            return new WorkNew
            {
                id = value.id,
                unn = value.unn,
                ots = value.ots,
                C205_226 = value.C205_226,
                C206_225 = value.C206_225,
                numBonusDog = value.numBonusDog,
                debt = value.debt,
                dateFrom = value.dateFrom,
                dateTo = value.dateTo,
                flag = value.flag,
                paymentOts = value.paymentOts,
                sumLastPaymentOts = value.sumLastPaymentOts,
                dateLastPayment = value.dateLastPayment,
                dateNullPayment = value.dateNullPayment,
                loginSender = value.loginSender,
                dateSend = value.dateSend,
                flagMail = value.flagMail,
                email = value.email,
                nds = value.nds,
                account = value.account,
                dateDebt = value.dateDebt,
                flagXml = value.flagXml,
                flagXmlProsrochka = value.flagXmlProsrochka,
                filialSupport = value.filialSupport
        };
        }
    }
}