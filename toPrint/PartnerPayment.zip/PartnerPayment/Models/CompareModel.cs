﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPWorkCore;
using System.ComponentModel.DataAnnotations;

namespace PartnerPayment.Models
{
    public class CompareModel
    {
        public int id { get; set; }
        public Nullable<decimal> sum_akt { get; set; }
        public Nullable<decimal> sum_eschf { get; set; }
        public string numBonusDog { get; set; }
        public string ots { get; set; }
        public Nullable<decimal> nds_akt { get; set; }
        public Nullable<decimal> nds_eschf { get; set; }
        public Nullable<System.DateTime> dateFrom { get; set; }
        public string dateFromFormat { get; set; }
        public decimal debtSum { get; set; }
        public decimal debtNds { get; set; }
        public string status { get; set; }

        public static implicit operator CompareModel(Compare value)
        {
            CompareModel item = new CompareModel();
            {
                item.id = value.id;
                item.dateFrom = value.dateFrom;
                item.sum_akt = value.sum_akt;
                item.sum_eschf = value.sum_eschf;
                item.numBonusDog = value.numBonusDog;
                item.ots = value.ots;
                item.nds_akt = value.nds_akt;
                item.nds_eschf = value.nds_eschf;
                item.dateFromFormat = ((DateTime)value.dateFrom).ToShortDateString();
                item.debtSum = (decimal)value.sum_akt - (decimal)value.sum_eschf;
                item.debtNds = (decimal)value.nds_akt - (decimal)value.nds_eschf;
                if (item.debtSum ==0 && item.debtNds == 0)
                {
                    item.status = "Ок";
                }
                else
                {
                    item.status = "Расхождение";
                }
            }
            return item;
        }
        public static implicit operator Compare(CompareModel value)
        {
            return new Compare()
            {
                id = value.id,
                sum_akt = value.sum_akt,
                sum_eschf = value.sum_eschf,
                numBonusDog = value.numBonusDog,
                ots = value.ots,
                nds_akt = value.nds_akt,
                nds_eschf = value.nds_eschf,
                dateFrom = value.dateFrom
            };
        }
    }
}