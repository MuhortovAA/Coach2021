﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPWorkCore;
using System.ComponentModel.DataAnnotations;


namespace PartnerPayment.Models
{
    public class ReestrModel
    {
        public int id{ get; set; }
        public string Date { get; set; }
        public string UNN { get; set; }
        public string MID { get; set; }
        public string OTC { get; set; }
        public string Card9 { get; set; }
        public Nullable<decimal> proc { get; set; }
        public Nullable<decimal> SumWithProc { get; set; }
        public Nullable<decimal> C205_226 { get; set; }
        public Nullable<decimal> C206_225 { get; set; }


        public static implicit operator ReestrModel(sp_Reestr_Result value)
        {
            return new ReestrModel()
            {
                id= new int(),
                Date = value.Date,
                UNN = value.UNN,
                MID = value.MID,
                OTC = value.OTC,
                Card9 = value.Card9,
                proc = value.proc,
                SumWithProc = value.SumWithProc,
                C205_226 = value.C205_226,
                C206_225 = value.C206_225
            };

        }
        public static implicit operator sp_Reestr_Result(ReestrModel value)
        {
            return new sp_Reestr_Result()
            {
                Date = value.Date,
                UNN = value.UNN,
                MID = value.MID,
                OTC = value.OTC,
                Card9 = value.Card9,
                proc = value.proc,
                SumWithProc = value.SumWithProc,
                C205_226 = value.C205_226,
                C206_225 = value.C206_225
            };
        }
    }
}
