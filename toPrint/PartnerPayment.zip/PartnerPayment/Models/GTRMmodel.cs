﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPWorkCore;

namespace PartnerPayment.Models
{
    public class GTRMmodel
    {
        public int id { get; set; }
        public System.DateTime dateDocument { get; set; }
        public System.DateTime dateDownload { get; set; }
        public string nameAllOTS { get; set; }
        public short filialSign { get; set; }
        public short filialSupport { get; set; }
        public byte acquiring { get; set; }
        public long unn { get; set; }
        public string numDogAcquiring { get; set; }
        public string typeBonusDog { get; set; }
        public string numBonusDog { get; set; }
        public System.DateTime dateBonusDog { get; set; }
        public string MID { get; set; }
        public short MCC { get; set; }
        public string field_098 { get; set; }
        public Nullable<System.DateTime> dateDownloadGTRM { get; set; }
        public Nullable<System.DateTime> dateStartCredit { get; set; }
        public Nullable<System.DateTime> dateFinishCredit { get; set; }
        public Nullable<System.DateTime> dateDeleteInGTRM { get; set; }
        public short creditTime { get; set; }
        public Nullable<decimal> procentAcqASB { get; set; }
        public Nullable<decimal> procentRez { get; set; }
        public Nullable<decimal> procentNotRez { get; set; }
        public Nullable<decimal> procentASBwithBonus { get; set; }
        public decimal procentCashBack { get; set; }
        public decimal procentNonAcq { get; set; }
        public string nameOTS { get; set; }
        public string rangeCodes { get; set; }
        public string typeProducts { get; set; }
        public string tarif { get; set; }
        public string region { get; set; }
        public string district { get; set; }
        public string cityType { get; set; }
        public string cityName { get; set; }
        public string streetType { get; set; }
        public string streetName { get; set; }
        public string houseNumber { get; set; }
        public string category { get; set; }
        public string siteOTS { get; set; }
        public string email { get; set; }
        public string linkDiscontProg { get; set; }
        public string bankOTSAccount { get; set; }
        public string curNumbAccountOTS { get; set; }
        public string mfoBank { get; set; }
        public string account { get; set; }
        public Nullable<decimal> penalty { get; set; }
        public string notes { get; set; }
        public string prim { get; set; }
        public string addressOts { get; set; }
        public string dateStartCreditFormat { get; set; }
        public string dateFinishCreditFormat { get; set; }
        public string typeWorking { get; set; }
        public string unnString { get; set; }

        public static implicit operator GTRMmodel(GTRM value)
        {
            GTRMmodel model = new GTRMmodel();
            {
                model.dateDocument = value.dateDocument;
                model.dateDownload = value.dateDownload;
                model.nameAllOTS = value.nameAllOTS;
                model.filialSign = value.filialSign;
                model.filialSupport = value.filialSupport;
                model.acquiring = value.acquiring;
                model.unn = value.unn;
                model.numDogAcquiring = value.numDogAcquiring;
                model.typeBonusDog = value.typeBonusDog;
                model.numBonusDog = value.numBonusDog;
                model.dateBonusDog = value.dateBonusDog;
                model.MID = value.MID;
                model.MCC = value.MCC;
                model.field_098 = value.field_098;
                model.dateDownloadGTRM = (DateTime)value.dateDownloadGTRM;
                model.dateStartCredit = (DateTime)value.dateStartCredit;
                model.dateFinishCredit = value.dateFinishCredit;
                model.dateDeleteInGTRM = value.dateDeleteInGTRM;
                model.creditTime = value.creditTime;
                model.procentAcqASB = value.procentAcqASB;
                model.procentRez = value.procentRez;
                model.procentNotRez = value.procentNotRez;
                model.procentASBwithBonus = value.procentASBwithBonus;
                model.procentCashBack = value.procentCashBack;
                model.procentNonAcq = value.procentNonAcq;
                model.nameOTS = value.nameOTS;
                model.rangeCodes = value.rangeCodes;
                model.typeProducts = value.typeProducts;
                model.tarif = value.tarif;
                model.region = value.region;
                model.district = value.district;
                model.cityType = value.cityType;
                model.cityName = value.cityName;
                model.streetType = value.streetType;
                model.streetName = value.streetName;
                model.houseNumber = value.houseNumber;
                model.siteOTS = value.siteOTS;
                model.email = value.email;
                model.linkDiscontProg = value.linkDiscontProg;
                model.bankOTSAccount = value.bankOTSAccount;
                model.curNumbAccountOTS = value.curNumbAccountOTS;
                model.mfoBank = value.mfoBank;
                model.account = value.account;
                model.penalty = value.penalty;
                model.notes = value.notes;
                model.prim = value.prim;
                model.addressOts = value.addressOts;
                model.dateStartCreditFormat = ((DateTime)value.dateStartCredit).ToShortDateString();

                if (value.dateFinishCredit == (DateTime?)null)
                {
                    model.dateFinishCreditFormat = "Не определено";
                    model.typeWorking = "Действующий";
                }
                else
                {
                    model.dateFinishCreditFormat = ((DateTime)value.dateFinishCredit).ToShortDateString();
                    model.typeWorking = "Не действующий";

                }
                model.unnString = value.unn.ToString();

            }
            return model;
        }






        public static implicit operator GTRM(GTRMmodel value)
        {
            return new GTRM
            {
                dateDocument = value.dateDocument,
                dateDownload = value.dateDownload,
                nameAllOTS = value.nameAllOTS,
                filialSign = value.filialSign,
                filialSupport = value.filialSupport,
                acquiring = value.acquiring,
                unn = value.unn,
                numDogAcquiring = value.numDogAcquiring,
                typeBonusDog = value.typeBonusDog,
                numBonusDog = value.numBonusDog,
                dateBonusDog = value.dateBonusDog,
                MID = value.MID,
                MCC = value.MCC,
                field_098 = value.field_098,
                dateDownloadGTRM = value.dateDownloadGTRM,
                dateStartCredit = value.dateStartCredit,
                dateFinishCredit = value.dateFinishCredit,
                dateDeleteInGTRM = value.dateDeleteInGTRM,
                creditTime = value.creditTime,
                procentAcqASB = value.procentAcqASB,
                procentRez = value.procentRez,
                procentNotRez = value.procentNotRez,
                procentASBwithBonus = value.procentASBwithBonus,
                procentCashBack = value.procentCashBack,
                procentNonAcq = value.procentNonAcq,
                nameOTS = value.nameOTS,
                rangeCodes = value.rangeCodes,
                typeProducts = value.typeProducts,
                tarif = value.tarif,
                region = value.region,
                district = value.district,
                cityType = value.cityType,
                cityName = value.cityName,
                streetType = value.streetType,
                streetName = value.streetName,
                houseNumber = value.houseNumber,
                siteOTS = value.siteOTS,
                email = value.email,
                linkDiscontProg = value.linkDiscontProg,
                bankOTSAccount = value.bankOTSAccount,
                curNumbAccountOTS = value.curNumbAccountOTS,
                mfoBank = value.mfoBank,
                account = value.account,
                penalty = value.penalty,
                notes = value.notes,
                prim = value.prim,
                addressOts = value.addressOts
            };
        }
    }

}