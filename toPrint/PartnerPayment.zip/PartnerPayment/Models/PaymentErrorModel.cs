﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPWorkCore;
using System.ComponentModel.DataAnnotations;
using System.Globalization;

namespace PartnerPayment.Models
{
    public class PaymentErrorModel
    {
        public int id { get; set; }
        public System.DateTime dateFrom { get; set; }
        public long unnRecipient { get; set; }
        public long unnPayer { get; set; }
        public string detPay { get; set; }
        public string customer { get; set; }
        public decimal sum { get; set; }
        public System.DateTime datePayment { get; set; }
        public string decision { get; set; }
        public string dateFromFormat { get; set; }
        public string datePaymentFormat { get; set; }
        public string period { get; set; }

        public static implicit operator PaymentErrorModel(PaymentError value)
        {
            PaymentErrorModel item = new PaymentErrorModel();
            {
                item.id = value.id;
                item.dateFrom = value.dateFrom;
                item.unnRecipient = value.unnRecipient;
                item.unnPayer = value.unnPayer;
                item.detPay = value.detPay;
                item.customer = value.customer;
                item.sum = value.sum;
                item.datePayment = value.datePayment;
                item.decision = value.decision;
                item.dateFromFormat = value.dateFrom.ToShortDateString();
                item.datePaymentFormat = value.datePayment.ToShortDateString();
                item.period = CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(value.dateFrom.Month) + " " + value.dateFrom.Year.ToString();

            }
            return item;
        }
        public static implicit operator PaymentError(PaymentErrorModel value)
        {
            return new PaymentError()
            {
                id = value.id,
                dateFrom = value.dateFrom,
                unnRecipient = value.unnRecipient,
                unnPayer = value.unnPayer,
                detPay = value.detPay,
                customer = value.customer,
                sum = value.sum,
                datePayment = value.datePayment,
                decision = value.decision
            };
        }
    }
}