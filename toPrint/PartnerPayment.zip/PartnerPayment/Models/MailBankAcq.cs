﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using PPWorkCore;
using System.ComponentModel.DataAnnotations;
namespace PartnerPayment.Models
{
    public class MailBankAcqModel
    {
        public int id { get; set; }
        public string unn { get; set; }
        public string ots { get; set; }
        public string numBonusDog { get; set; }
        public System.DateTime dateFrom { get; set; }
        public System.DateTime dateTo { get; set; }
        public string loginSender { get; set; }
        public Nullable<System.DateTime> dateSend { get; set; }
        public string flagMail { get; set; }
        public string email { get; set; }
        public string statusMail { get; set; }
        public string dateSendFormat { get; set; }
        public static implicit operator MailBankAcqModel(WorkAcqBank value)
        {
            MailBankAcqModel item = new MailBankAcqModel();
            {
                item.id = value.id;
                item.unn = value.unn;
                item.ots = value.ots;
                item.numBonusDog = value.numBonusDog;
                item.dateFrom = value.dateFrom;
                item.dateTo = value.dateTo;
                item.loginSender = value.loginSender;
                item.dateSend = value.dateSend;
                item.flagMail = value.flagMail;
                item.email = value.email;

                if (value.dateSend == (DateTime?)null)
                {
                    item.dateSendFormat = "Не отправлено";
                }
                else
                {
                    item.dateSendFormat = Convert.ToDateTime(value.dateSend).ToShortDateString();
                }

                switch (item.flagMail)
                {
                    case "0": item.statusMail = "Без статуса"; break;
                    case "1": item.statusMail = "Подготовка акта"; break;
                    case "2": item.statusMail = "Акт сформирован"; break;
                    case "3": item.statusMail = "Отправка акта"; break;
                    case "4": item.statusMail = "Акт отправлен ОТС"; break;
                }
            }
            return item;
        }
        public static implicit operator WorkAcqBank(MailBankAcqModel value)
        {
            return new WorkAcqBank
            {
                id = value.id,
                unn = value.unn,
                ots = value.ots,
                numBonusDog = value.numBonusDog,
                dateFrom = value.dateFrom,
                dateTo = value.dateTo,
                loginSender = value.loginSender,
                dateSend = value.dateSend,
                flagMail = value.flagMail,
                email = value.email
            };
        }
    }
}