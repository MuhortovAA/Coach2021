﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace PartnerPayment.Infrastructure
{
    public static class ErrorMessage
    {
        public static string errorMessage;
        public static string GetErrorByCode(int code)
        {
            switch (code)
            {
                case 1:
                    errorMessage = "Введён неверный пароль";
                    break;
                case 3:
                    errorMessage = "Введён неверный пароль";
                    break;
                //case 2:
                //        errMessage = "Доступ временно закрыт!";
                //    break;
                //case 3:
                //        errMessage = "Неверен формат данных";
                //    break;
                case 4:
                    errorMessage = "Введён неверный логин или пароль";
                    break;
                case 5:
                    errorMessage = "Нет данных для записи в базу";
                    break;
                case 6:
                    errorMessage = "Нет прав на работу с содержимым документа";
                    break;
                case 7:
                    errorMessage = "Нет прав на просмотр документов";
                    break;
                case 8:
                    errorMessage = "Нет прав на просмотр информации";
                    break;
                case 9:
                    errorMessage = "Неверный формат входных данных";
                    break;
                case 10:
                    errorMessage = "Нет прав на выполнение операции";
                    break;
                case 11:
                    errorMessage = "Переданы неверные данные";
                    break;
                case 12:
                    errorMessage = "Проверьте состояние документа";
                    break;
                case 15:
                    errorMessage = "Принудительная смена пароля";
                    break;
                case 16:
                    errorMessage = "Срок действия пароля истек";
                    break;
                case 17:
                    errorMessage = "Учетная запись заблокирована до ";
                    break;
                case 18:
                    errorMessage = "Учетная запись заблокирована.Попытка подбора пароля.\nТелефон 309-04-04";
                    break;
                case 19:
                    errorMessage = "Учетная запись заблокирована администратором.\nТелефон 309-04-04";
                    break;
                case 21:
                    errorMessage = "Нарушена целостность и подлинность документа";
                    break;
                case 22:
                    errorMessage = "Дублирование референса в налоговом платеже";
                    break;
                case 99:
                    errorMessage = "Ошибка службы доступа!";
                    break;
                case 9999:
                    errorMessage = "Незарегистрированная ошибка";
                    break;
                default:
                    errorMessage = "Незарегистрированная ошибка";
                    break;
            }
            return errorMessage;
        }
    }
}