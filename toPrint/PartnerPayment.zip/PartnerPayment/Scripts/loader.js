﻿function skm_LockScreen() {
    var lock = document.getElementById('skm_LockPane');
    if (lock)
        lock.className = 'LockOn';

}
function skm_UnLockScreen() {
    var lock = document.getElementById('skm_LockPane');
    if (lock)
        lock.className = 'LockOff';

}