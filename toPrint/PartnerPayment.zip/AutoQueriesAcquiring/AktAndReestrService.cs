﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using NLog;
using System.IO;
using System.Xml.Serialization;
using System.Xml.Xsl;
using System.Xml;
using System.Net.Mail;
using System.Net;
using NPOI.SS.UserModel;
using NPOI.XSSF.UserModel;
using NPOI.SS.Util;
using System.Threading;
using System.Threading.Tasks;
using System.Diagnostics;

namespace AutoQueriesAcquiring
{
    public class AktAndReestrService
    {
        private static PartnerPaymentEntities _db;
        //private static Logger logger = LogManager.GetCurrentClassLogger();

        public void PreDoc(List<WorkAcqBank> modelView)
        {
            var firstDay = modelView.FirstOrDefault().dateFrom;
            var lastDay = modelView.FirstOrDefault().dateTo;
            List<GTRM> gtrm = GetGTRMList();

            foreach (var item in modelView)
            {
                WordRead(item, firstDay, lastDay, gtrm);
            }
        }

        public void PreSend(List<WorkAcqBank> modelView)
        {
            var firstDay = modelView.Last().dateFrom;
            var lastDay = modelView.FirstOrDefault().dateTo;
            List<GTRM> gtrm = GetGTRMList();
            foreach (var item in modelView)
            {
                GTRM modelGTRM = gtrm.Where(x => x.numBonusDog == item.numBonusDog).Last();
                SendMail(modelGTRM, item.dateFrom, item.id);
            }
        }

        public void SendMail(GTRM model, DateTime firstDay, int id)
        {
            try
            {
                var month = firstDay.Month.ToString("00");
                var year = firstDay.Year.ToString();
                SmtpClient Smtp = new SmtpClient("mail2.asb.by", 25);
                Smtp.Credentials = new NetworkCredential("tech.user@belarusbank.by", "di82BJ77");
                MailMessage Message = new MailMessage();
                Message.From = new MailAddress("tech.user@belarusbank.by");
                Message.To.Add(new MailAddress(model.emailPartners));
                Message.Subject = $"Акт и реестр по договору {model.numBonusDog}";
                Message.Body = $"Добрый день. Вам направляется письмо с реестром по договору {model.numBonusDog}.";
                var sFile = @"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\Реестр по договору " + $"{model.numBonusDog} за " + $"{year}{month}.xls";
                App.logger.Info($"Присоединяем файл: {sFile}");
                Message.Attachments.Add(new Attachment(sFile));
                App.logger.Info($"Начат процесс отправки письма по договору: {model.numBonusDog} на адрес: {model.emailPartners} GTRMid:{model.id}");
                Smtp.Send(Message);
                App.logger.Info($"Письмо успешно отправлено");
                using (_db = new PartnerPaymentEntities())
                {
                    WorkAcqBank ss = _db.WorkAcqBank.Where(x => x.id == id).First();
                    //WorkAcqBank ss = _db.WorkAcqBank.Where(x => x.numBonusDog == model.numBonusDog && x.dateFrom == firstDay && x.email== model.emailPartners).First();
                    {
                        ss.flagMail = "4";
                        ss.dateSend = DateTime.Now;
                        _db.SaveChanges();
                        App.logger.Info($"Изменен статус на 'Отправлено' по договору {model.numBonusDog} и WABid:{ss.id}");
                    }
                }
            }
            catch (Exception e)
            {
                App.logger.Info($"!!! Ошибка {e.Message}");
            }
        }

        static void WordRead(WorkAcqBank item, DateTime firstDay, DateTime lastDay, List<GTRM> gtrm)
        {
            try
            {
                List<sp_Reestr_Acquiring_Result> spList = getReestrList(item.numBonusDog, firstDay, lastDay);
                string dateDog = gtrm.Where(x => x.numBonusDog == item.numBonusDog).Select(x => x.dateBonusDog).Last().ToShortDateString();
                int countList = spList.Count();

                var workbook = new XSSFWorkbook();
                var sheet = (XSSFSheet)workbook.CreateSheet("Лист 1");


                #region Заголовок таблицы              
                var font = workbook.CreateFont();
                font.IsBold = true;
                font.FontHeightInPoints = 16;
                var styleTop = workbook.CreateCellStyle();
                styleTop.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Center;
                styleTop.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                styleTop.SetFont(font);
                styleTop.WrapText = true;

                var row = sheet.CreateRow(0);
                row.HeightInPoints = 25;
                var cell = row.CreateCell(0);
                cell.SetCellValue($"ОТЧЕТ (выписка) по операциям с карточками ОАО «АСБ Беларусбанк» в ОТС субъекта хозяйствования {item.ots} (УНП {item.unn})");
                cell.CellStyle = styleTop;
                var cra = new NPOI.SS.Util.CellRangeAddress(0, 0, 0, 12);
                sheet.AddMergedRegion(cra);

                var row1 = sheet.CreateRow(1);
                row1.HeightInPoints = 25;
                var cell1 = row1.CreateCell(0);
                cell1.SetCellValue($"в рамках партнерского (бонусного) договора  от {dateDog} №{item.numBonusDog} и договора по расчетному обслуживанию (эквайринга)");
                cell1.CellStyle = styleTop;
                var cra1 = new NPOI.SS.Util.CellRangeAddress(1, 1, 0, 12);
                sheet.AddMergedRegion(cra1);
                #endregion

                #region Название столбцов
                var fontColumnsTop = workbook.CreateFont();
                fontColumnsTop.FontHeightInPoints = 12;
                var styleColumnsTop = workbook.CreateCellStyle();
                styleColumnsTop.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Center;
                styleColumnsTop.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                styleColumnsTop.SetFont(fontColumnsTop);
                styleColumnsTop.WrapText = true;

                var row2 = sheet.CreateRow(2);
                row2.HeightInPoints = 50;
                var row3 = sheet.CreateRow(3);
                row3.HeightInPoints = 105;

                var cell20 = row2.CreateCell(0);
                cell20.SetCellValue("№ п/п");
                cell20.CellStyle = styleColumnsTop;
                var cra20 = new NPOI.SS.Util.CellRangeAddress(2, 3, 0, 0);
                sheet.AddMergedRegion(cra20);

                var cell21 = row2.CreateCell(1);
                cell21.SetCellValue("Дата транзакции");
                cell21.CellStyle = styleColumnsTop;
                var cra21 = new NPOI.SS.Util.CellRangeAddress(2, 3, 1, 1);
                sheet.AddMergedRegion(cra21);

                var cell22 = row2.CreateCell(2);
                cell22.SetCellValue("MID торгового объекта");
                cell22.CellStyle = styleColumnsTop;
                var cra22 = new NPOI.SS.Util.CellRangeAddress(2, 3, 2, 2);
                sheet.AddMergedRegion(cra22);

                var cell23 = row2.CreateCell(3);
                cell23.SetCellValue("Наименование торгового объекта");
                cell23.CellStyle = styleColumnsTop;
                var cra23 = new NPOI.SS.Util.CellRangeAddress(2, 3, 3, 3);
                sheet.AddMergedRegion(cra23);

                var cell24 = row2.CreateCell(4);
                cell24.SetCellValue("Тип карточки, участвующей в партнерской (бонусной) программе банка (BIN, рендж)");
                cell24.CellStyle = styleColumnsTop;
                var cra24 = new NPOI.SS.Util.CellRangeAddress(2, 3, 4, 4);
                sheet.AddMergedRegion(cra24);

                var cell25 = row2.CreateCell(5);
                cell25.SetCellValue("База для расчета сумм вознаграждений, бел. руб. (оборот '+', возврат '-')");
                cell25.CellStyle = styleColumnsTop;
                var cra25 = new NPOI.SS.Util.CellRangeAddress(2, 3, 5, 5);
                sheet.AddMergedRegion(cra25);

                var cell26 = row2.CreateCell(6);
                cell26.SetCellValue("Расчет вознагражд. Банку в рамках (партнерского) бонусного договора");
                cell26.CellStyle = styleColumnsTop;
                var cra26 = new NPOI.SS.Util.CellRangeAddress(2, 2, 6, 7);
                sheet.AddMergedRegion(cra26);

                var cell27 = row2.CreateCell(8);
                cell27.SetCellValue("Расчет вознагражд. Банку в рамках договора эквайринга");
                cell27.CellStyle = styleColumnsTop;
                var cra27 = new NPOI.SS.Util.CellRangeAddress(2, 2, 8, 10);
                sheet.AddMergedRegion(cra27);

                var cell211 = row2.CreateCell(11);
                cell211.SetCellValue("ИТОГО");
                cell211.CellStyle = styleColumnsTop;
                var cra211 = new NPOI.SS.Util.CellRangeAddress(2, 2, 11, 12);
                sheet.AddMergedRegion(cra211);

                var cell36 = row3.CreateCell(6);
                cell36.SetCellValue("Ставка вознагражд., %");
                cell36.CellStyle = styleColumnsTop;

                var cell37 = row3.CreateCell(7);
                cell37.SetCellValue("Сумма вознагражд. (графа 6 х графа 7), бел.руб.");
                cell37.CellStyle = styleColumnsTop;

                var cell38 = row3.CreateCell(8);
                cell38.SetCellValue("№ и дата дог. Эквайринга");
                cell38.CellStyle = styleColumnsTop;

                var cell39 = row3.CreateCell(9);
                cell39.SetCellValue("Ставка вознагражд., %");
                cell39.CellStyle = styleColumnsTop;

                var cell310 = row3.CreateCell(10);
                cell310.SetCellValue("Сумма вознагражд.(графа 6 х графа 10), бел. руб.");
                cell310.CellStyle = styleColumnsTop;

                var cell311 = row3.CreateCell(11);
                cell311.SetCellValue("Сумма вознагражд. Банку (графа 8 + графа 11), бел.руб.");
                cell311.CellStyle = styleColumnsTop;

                var cell312 = row3.CreateCell(12);
                cell312.SetCellValue("Доход ОТС, бел.руб. (графа 6 - графа 12), бел.руб.");
                cell312.CellStyle = styleColumnsTop;

                var row4 = sheet.CreateRow(4);

                var fontColumnsTop1 = workbook.CreateFont();
                fontColumnsTop1.FontHeightInPoints = 12;
                fontColumnsTop1.IsBold = true;
                var styleColumnsTop1 = workbook.CreateCellStyle();
                styleColumnsTop1.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Center;
                styleColumnsTop1.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                styleColumnsTop1.SetFont(fontColumnsTop1);
                styleColumnsTop1.WrapText = true;
                for (int k = 1; k < 14; k++)
                {
                    var myCell = row4.CreateCell(k - 1);
                    myCell.SetCellValue(k);
                    myCell.CellStyle = styleColumnsTop1;

                }
                #endregion

                #region Заполнение таблицы
                var fontTable = workbook.CreateFont();
                fontTable.FontHeightInPoints = 12;
                var styleTable = workbook.CreateCellStyle();
                styleTable.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                styleTable.SetFont(fontTable);

                int i = 1;
                foreach (var data in spList)
                {
                    var currentRow = sheet.CreateRow(4 + i);

                    var myCell_1 = currentRow.CreateCell(0);
                    myCell_1.CellStyle = styleTable;
                    myCell_1.SetCellValue(i);

                    var myCell_2 = currentRow.CreateCell(1);
                    myCell_2.CellStyle = styleTable;
                    myCell_2.SetCellValue(data.Date);

                    var myCell_3 = currentRow.CreateCell(2);
                    myCell_3.CellStyle = styleTable;
                    myCell_3.SetCellValue(data.MID);

                    var myCell_4 = currentRow.CreateCell(3);
                    myCell_4.CellStyle = styleTable;
                    myCell_4.SetCellValue(data.nameOTS);

                    var myCell_5 = currentRow.CreateCell(4);
                    myCell_5.CellStyle = styleTable;
                    myCell_5.SetCellValue(data.Card9);

                    var myCell_6 = currentRow.CreateCell(5);
                    myCell_6.CellStyle = styleTable;
                    myCell_6.SetCellValue(Convert.ToDouble(data.SumOper));

                    var myCell_7 = currentRow.CreateCell(6);
                    myCell_7.CellStyle = styleTable;
                    myCell_7.SetCellValue(Convert.ToDouble(data.procNonAcq));

                    var myCell_8 = currentRow.CreateCell(7);
                    myCell_8.CellStyle = styleTable;
                    myCell_8.SetCellValue(Convert.ToDouble(data.SumNonAcq));

                    var myCell_9 = currentRow.CreateCell(8);
                    myCell_9.CellStyle = styleTable;
                    myCell_9.SetCellValue(data.numDogAcq);

                    var myCell_10 = currentRow.CreateCell(9);
                    myCell_10.CellStyle = styleTable;
                    myCell_10.SetCellValue(Convert.ToDouble(data.procAcq));

                    var myCell_11 = currentRow.CreateCell(10);
                    myCell_11.CellStyle = styleTable;
                    myCell_11.SetCellValue(Convert.ToDouble(data.SumAcq));

                    var myCell_12 = currentRow.CreateCell(11);
                    myCell_12.CellStyle = styleTable;
                    myCell_12.SetCellValue(Convert.ToDouble(data.SumAcq + data.SumNonAcq));

                    var myCell_13 = currentRow.CreateCell(12);
                    myCell_13.CellStyle = styleTable;
                    myCell_13.SetCellValue(Convert.ToDouble(data.SumOper - data.SumAcq - data.SumNonAcq));
                    i++;
                }
                #endregion

                #region Итоги  
                var fontTotals = workbook.CreateFont();
                fontTotals.IsBold = true;
                fontTotals.FontHeightInPoints = 14;
                var styleTotals = workbook.CreateCellStyle();
                styleTotals.VerticalAlignment = NPOI.SS.UserModel.VerticalAlignment.Center;
                styleTotals.Alignment = NPOI.SS.UserModel.HorizontalAlignment.Center;
                styleTotals.SetFont(fontTotals);

                int totalsCards = countList + 5;
                foreach (var dat in spList.Select(x => x.Card9).Distinct().ToList())
                {
                    var currentRow = sheet.CreateRow(totalsCards);

                    var myCell_1 = currentRow.CreateCell(0);

                    var strCard = GetTarifFromCard9(dat);
                    if (strCard == null)
                    {
                        App.logger.Info($"Данные по карте {dat} клиента {item.numBonusDog} из справочника тарифов не найдены ");
                    }
                    else
                    {
                        //myCell_1.SetCellValue($"ИТОГО по карточкам {GetTarifFromCard9(dat)}:");
                        myCell_1.SetCellValue($"ИТОГО по карточкам {strCard}:");
                        myCell_1.CellStyle = styleTotals;
                        var craMyTotalCell = new NPOI.SS.Util.CellRangeAddress(totalsCards, totalsCards, 0, 3);
                        sheet.AddMergedRegion(craMyTotalCell);

                        var myCell_5 = currentRow.CreateCell(4);
                        myCell_5.CellStyle = styleTotals;
                        myCell_5.SetCellValue(dat);

                        var myCell_6 = currentRow.CreateCell(5);
                        myCell_6.CellStyle = styleTotals;
                        myCell_6.SetCellValue(Convert.ToDouble(spList.Where(x => x.Card9 == dat).Sum(x => x.SumOper)));

                        var myCell_8 = currentRow.CreateCell(7);
                        myCell_8.CellStyle = styleTotals;
                        myCell_8.SetCellValue(Convert.ToDouble(spList.Where(x => x.Card9 == dat).Sum(x => x.SumNonAcq)));

                        var myCell_11 = currentRow.CreateCell(10);
                        myCell_11.CellStyle = styleTotals;
                        myCell_11.SetCellValue(Convert.ToDouble(spList.Where(x => x.Card9 == dat).Sum(x => x.SumAcq)));

                        var myCell_12 = currentRow.CreateCell(11);
                        myCell_12.CellStyle = styleTotals;
                        myCell_12.SetCellValue(Convert.ToDouble(spList.Where(x => x.Card9 == dat).Sum(x => x.SumAcq) + spList.Where(x => x.Card9 == dat).Sum(x => x.SumNonAcq)));

                        var myCell_13 = currentRow.CreateCell(12);
                        myCell_13.CellStyle = styleTotals;
                        myCell_13.SetCellValue(Convert.ToDouble(spList.Where(x => x.Card9 == dat).Sum(x => x.SumOper)
                            - spList.Where(x => x.Card9 == dat).Sum(x => x.SumAcq) - spList.Where(x => x.Card9 == dat).Sum(x => x.SumNonAcq)));
                        totalsCards++;
                    }
                }


                var totalRow = sheet.CreateRow(totalsCards);

                var totalCell_1 = totalRow.CreateCell(0);
                totalCell_1.SetCellValue("ИТОГО:");
                totalCell_1.CellStyle = styleTop;
                var craTotalCell = new NPOI.SS.Util.CellRangeAddress(totalsCards, totalsCards, 0, 3);
                sheet.AddMergedRegion(craTotalCell);

                var totalCell_6 = totalRow.CreateCell(5);
                totalCell_6.CellStyle = styleTop;
                totalCell_6.SetCellValue(Convert.ToDouble(spList.Sum(x => x.SumOper)));

                var totalCell_8 = totalRow.CreateCell(7);
                totalCell_8.CellStyle = styleTop;
                totalCell_8.SetCellValue(Convert.ToDouble(spList.Sum(x => x.SumNonAcq)));

                var totalCell_11 = totalRow.CreateCell(10);
                totalCell_11.CellStyle = styleTop;
                totalCell_11.SetCellValue(Convert.ToDouble(spList.Sum(x => x.SumAcq)));

                var totalCell_12 = totalRow.CreateCell(11);
                totalCell_12.CellStyle = styleTop;
                totalCell_12.SetCellValue(Convert.ToDouble(spList.Sum(x => x.SumAcq) + spList.Sum(x => x.SumNonAcq)));

                var totalCell_13 = totalRow.CreateCell(12);
                totalCell_13.CellStyle = styleTop;
                totalCell_13.SetCellValue(Convert.ToDouble(spList.Sum(x => x.SumOper) - spList.Sum(x => x.SumAcq) - spList.Sum(x => x.SumNonAcq)));
                #endregion                

                sheet.SetColumnWidth(1, 3500);
                sheet.SetColumnWidth(2, 3500);
                sheet.SetColumnWidth(3, 4500);
                sheet.SetColumnWidth(4, 5500);
                sheet.SetColumnWidth(5, 7000);
                sheet.SetColumnWidth(6, 5000);
                sheet.SetColumnWidth(7, 5000);
                sheet.SetColumnWidth(8, 4000);
                sheet.SetColumnWidth(9, 4000);
                sheet.SetColumnWidth(10, 4000);
                sheet.SetColumnWidth(11, 4000);
                sheet.SetColumnWidth(12, 4000);

                //запишем всё в файл
                //using (var fs = new FileStream(@"d:\Реестр по договору " + $"{item.numBonusDog} за " + $"{item.dateFrom.Year}{item.dateFrom.Month.ToString("00")}.xls", FileMode.Create, FileAccess.Write))

                using (var fs = new FileStream(@"\\sca-rotsbp-db\mssqlserver\PartnerPayments\Akts\Реестр по договору " + $"{item.numBonusDog} за " + $"{item.dateFrom.Year}{item.dateFrom.Month.ToString("00")}.xls", FileMode.Create, FileAccess.Write))
                {
                    workbook.Write(fs);
                }
                //ChangeStatus(item.numBonusDog, firstDay, item.email);
                ChangeStatus(item.id);
                Console.WriteLine($"Реестр сформирован для {item.numBonusDog}");
                App.logger.Info($"Реестр сформирован для договор:{item.numBonusDog} id:{item.id}");
            }
            catch (Exception e)
            {
                App.logger.Error($"Ошибка формирования реестра для {item.numBonusDog}\n" + e.StackTrace);
            }

        }



        static List<sp_Reestr_Acquiring_Result> getReestrList(string numDog, DateTime firstDay, DateTime lastDay)
        {
            using (_db = new PartnerPaymentEntities())
            {
                _db.Database.CommandTimeout = 20000;
                List<sp_Reestr_Acquiring_Result> spList = _db.sp_Reestr_Acquiring(firstDay, lastDay, numDog).ToList();
                return spList;
            }
        }


        //static void ChangeStatus(string numDog, DateTime dateFrom, string email)
        static void ChangeStatus(int id)
        {
            using (_db = new PartnerPaymentEntities())
            {
                //WorkAcqBank asda = _db.WorkAcqBank.Where(x => x.numBonusDog == numDog && x.dateFrom == dateFrom && x.email==email).FirstOrDefault();
                WorkAcqBank asda = _db.WorkAcqBank.Where(x => x.id == id).FirstOrDefault();
                if (asda != null)
                {
                    asda.flagMail = "2";

                }
                _db.SaveChanges();
                App.logger.Info($"Изменен статус на 2 - сформирован для id:{id}\n");
            }
        }

        static List<sprFilials> GetListFilials()
        {
            using (_db = new PartnerPaymentEntities())
            {
                List<sprFilials> spList = _db.sprFilials.ToList();
                return spList;
            }
        }
        static List<GTRM> GetGTRMList()
        {
            using (_db = new PartnerPaymentEntities())
            {
                List<GTRM> spList = _db.GTRM.Where(x => x.acquiring == 1).ToList();
                return spList;
            }
        }

        static string GetTarifFromCard9(string card9)
        {
            using (_db = new PartnerPaymentEntities())
            {
                //string card9Out = _db.sprTarif.Where(x => x.range == card9).Select(x => x.tarif).Single();
                string card9Out = _db.sprTarif.Where(x => x.range == card9).Select(x => x.tarif).FirstOrDefault();
                return card9Out;
            }
        }
    }
}
