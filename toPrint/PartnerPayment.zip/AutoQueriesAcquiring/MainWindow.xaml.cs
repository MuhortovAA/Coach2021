﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Diagnostics;
using System.IO;
using NPOI.XSSF.UserModel;
using NLog;

namespace AutoQueriesAcquiring
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        //private static Logger logger = new Logger();
        public static Logger logger = LogManager.GetCurrentClassLogger();
        public delegate void DisplayHandler(List<WorkAcqBank> list);
        public PartnerPaymentEntities _db;
        public DataUpdateService _dataUpdateService;
        public AktAndReestrService _aktAndReestrService;

        System.Windows.Threading.DispatcherTimer dt = new System.Windows.Threading.DispatcherTimer();
        TimeSpan tmpInterval = new TimeSpan(0, 0, 0);
        int timerIntervalStep = 1;
        internal static class MyClass
        {
            public static byte flagWork { get; set; } = 0;
        }
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Grid_Loaded(object sender, RoutedEventArgs e)
        {
            App.logger.Info("Запуск программы");
            //logger.Info("Запуск программы");


            lv.ItemsSource = workList();
            //таймер пошаговый
            dt.Interval = new TimeSpan(0, 0, timerIntervalStep);
            dt.Tick += dt_Tick;
          //WordRead();
            dt.Start();
            this.Closed += MainWindow_Closed;
        }
     

        void dt_Tick(object sender, EventArgs e)
        {
            List<WorkAcqBank> list = workList();
            TimeSpan procInterval = new TimeSpan(0, 0, 10);
            tmpInterval = tmpInterval + new TimeSpan(0, 0, timerIntervalStep);//таймер увеличение времени
            if (tmpInterval > procInterval) // если таймер больше интервала
            {
                tmpInterval = new TimeSpan(0);// таймер обнулить
                DisplayHandler handler = new DisplayHandler(Processing);
                if (MyClass.flagWork == 0)
                {
                    if (list.Count() > 0)
                    {
                        IAsyncResult resultObj = handler.BeginInvoke(list, null, null);
                    }
                }
            }
            operCount.Text = workList().Count().ToString();
            tbCount.Text = String.Format("{0}({1})", tmpInterval.ToString("ss"), procInterval.ToString("ss"));
            lv.ItemsSource = list;
        }

        void Processing(List<WorkAcqBank> list)
        {
            try
            {
                MyClass.flagWork = 1;
                _dataUpdateService = new DataUpdateService();
                _aktAndReestrService = new AktAndReestrService();

                foreach (var data in list)
                {
                    if (data.flagMail == "1")
                    {
                        App.logger.Info("Начат процесс подготовки актов, с флагом 1");
                        _aktAndReestrService.PreDoc(list.Where(x => x.flagMail == "1").ToList());
                        App.logger.Info("Закончен процесс подготовки");
                        break;
                    }

                    if (data.flagMail == "3")
                    {
                        App.logger.Info("Начат процесс формирования отправки актов, с флагом 3");
                        _aktAndReestrService.PreSend(list.Where(x => x.flagMail == "3").ToList());
                        App.logger.Info("Закончен процесс формирования отправки актов");
                        break;
                    }
                }
                MyClass.flagWork = 0;
            }
            catch (Exception EXC)
            {
                string sds = EXC.Message;
                App.logger.Error($"Ошибка работы метода Processing(){EXC.Message}");
                throw new Exception(EXC.Message);
            }
        }

        void MainWindow_Closed(object sender, EventArgs e)
        {
            Process.GetCurrentProcess().Kill();
        }

        List<WorkAcqBank> workList()
        {
            using (_db = new PartnerPaymentEntities())
            {
                return _db.WorkAcqBank.Where(x => x.numBonusDog == "UPDATEAcq" || x.flagMail == "1" || x.flagMail == "3").ToList();
            }
        }
    }
}

//void Method()
//{
//    try
//    {
//        MyClass.flagWork = 1;
//        int result = 0;
//        for (int i = 1; i < 10; i++)
//        {
//            result += i * i;
//        }
//        Thread.Sleep(18000);

//        MyClass.flagWork = 0;
//    }
//    catch (Exception E)
//    {
//        string sdsd = "";
//        throw new Exception(E.Message);
//    }
//}
