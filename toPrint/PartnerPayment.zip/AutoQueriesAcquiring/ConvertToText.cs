﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AutoQueriesAcquiring
{
    public class ConvertToText
    {
        private static string[] hundreds = { " сто", " двести", " триста",
                                            " четыреста", " пятьсот", " шестьсот",
                                            " семьсот", " восемьсот", " девятьсот" };

        private static string[] scores = { " двадцать", " тридцать", " сорок", " пятьдесят", " шестьдесят",
                                           " семьдесят", " восемьдесят", " девяносто" };

        private static string[] tenUnit = { " десять", " одинадцать", " двенадцать", " тринадцать",
                                            " четырнадцать" , " пятнадцать" , " шестнадцать" ,
                                            " семнадцать" , " восемнадцать" , " девятнадцать"};

        private static string[] unit = { " один" ," два"," три", " четыре", " пять", " шесть",
                                         " семь", " восемь", " девять"};

        private static string IntToStr(int inLonProp)
        {
            string result = "";
            int Sot = inLonProp / 100;
            int Des = (inLonProp - (Sot * 100)) / 10;
            int Edin = inLonProp - (Sot * 100) - (Des * 10);
            if (Sot > 0 && Sot < 10)
                result = hundreds[Sot - 1];
            if (Des > 0 && Des < 10)
            {
                if (Des == 1)
                    result = result.Trim() + tenUnit[Edin];
                else
                    result = result.Trim() + scores[Des - 2];
            }
            if (Des != 1)
            {
                if (Edin > 0 && Edin < 10)
                    result = result.Trim() + unit[Edin - 1];
            }
            return result;
        }

        private static int Sclonenie(int mmte)
        {
            int des = mmte % 100;
            if (des > 20)
                des = des % 10;
            return des;
        }


        public static string strCop(decimal LonProp)
        {
            string result_part = "";

            if (LonProp == 0)
            {
                result_part = "0 копеек";
            }
            else
            {
                string h1 = LonProp.ToString();
                string h2 = h1.Substring(h1.Length - 1, 1);
                int h3 = Convert.ToInt16(h2);
                if (h3 == 1)
                {
                    result_part = " " + LonProp + " копейка";
                }
                if (h3 == 2)
                {
                    result_part = " " + LonProp + " копейки";
                }
                if (h3 >= 3 && h3 <= 4)
                {
                    result_part = " " + LonProp + " копейки";
                }
                if (h3 >= 5 && h3 <= 9 || h3 == 0)
                {
                    result_part = " " + LonProp + " копеек";
                }
            }
            return result_part;
        }

        public static string StrPropSum(decimal LonProp)
        {
            string result = "";

            if (LonProp == 0)
                result = "Ноль белорусских рублей)";
            else
            {
                int des = 0;
                int kvad = (int)(LonProp / 1000000000000000);
                LonProp = LonProp % 1000000000000000;
                if (kvad > 0 && kvad < 1000)
                {
                    des = Sclonenie(kvad);
                    result = string.Format("{0} {1}", result.Trim(), IntToStr(kvad).Trim());
                    if (des == 1)
                        result = result.Trim() + " квадриллион";
                    else if (des > 1 && des < 5)
                        result = result.Trim() + " квадриллиона";
                    else
                        result = result.Trim() + " квадриллионов";
                }
                int tril = (int)(LonProp / 1000000000000);
                LonProp = LonProp % 1000000000000;
                if (tril > 0 && tril < 1000)
                {
                    des = Sclonenie(tril);
                    result = string.Format("{0} {1}", result.Trim(), IntToStr(tril).Trim());
                    if (des == 1)
                        result = result.Trim() + " триллион";
                    else if (des > 1 && des < 5)
                        result = result.Trim() + " триллиона";
                    else
                        result = result.Trim() + " триллионов";
                }
                int mmte = (int)(LonProp / 1000000000);
                LonProp = LonProp % 1000000000;
                if (mmte > 0 && mmte < 1000)
                {
                    des = Sclonenie(mmte);
                    result = string.Format("{0} {1}", result.Trim(), IntToStr(mmte).Trim());
                    if (des == 1)
                        result = result.Trim() + " миллиард";
                    else if (des > 1 && des < 5)
                        result = result.Trim() + " миллиарда";
                    else
                        result = result.Trim() + " миллиардов";
                }
                //                int mil = (int)((LonProp - mmte * 1000000000) / 1000000);
                int mil = (int)(LonProp / 1000000);
                LonProp = LonProp % 1000000;
                if (mil > 0 && mil < 1000)
                {
                    des = Sclonenie(mil);
                    result = string.Format("{0} {1}", result.Trim(), IntToStr(mil).Trim());
                    if (des == 1)
                        result = result.Trim() + " миллион";
                    else if (des > 1 && des < 5)
                        result = result.Trim() + " миллиона";
                    else
                        result = result.Trim() + " миллионов";
                }
                //int tis = (int)((LonProp - mmte * 1000000000 - mil * 1000000) / 1000);
                int tis = (int)(LonProp / 1000);
                LonProp = LonProp % 1000;
                if (tis > 0 && tis < 1000)
                {
                    des = Sclonenie(tis);
                    result = string.Format("{0} {1}", result.Trim(), IntToStr(tis).Trim());
                    if (des == 1)
                        result = result.Substring(0, result.Length - 2) + "на тысяча";
                    else if (des == 2)
                        result = result.Substring(0, result.Length - 1) + "е тысячи";
                    else if (des > 1 && des < 5)
                        result = result.Trim() + " тысячи";
                    else
                        result = result.Trim() + " тысяч";
                }
                //tis = (int)(LonProp - mmte * 1000000000 - mil * 1000000 - tis * 1000);
                tis = (int)(LonProp);
                if (tis > 0 && tis < 1000)
                {
                    string h1 = LonProp.ToString();
                    string h2 = h1.Substring(h1.Length - 1, 1);

                    int h3 = Convert.ToInt16(h2);

                    if (h3 == 1)
                    {
                        result = string.Format("{0} {1}) белорусский рубль", result.Trim(), IntToStr(tis).Trim());
                    }
                    if (h3 >= 2 && h3 <= 4)
                    {
                        result = string.Format("{0} {1}) белорусских рубля", result.Trim(), IntToStr(tis).Trim());
                    }
                    if (h3 >= 5 && h3 <= 9 || h3 == 0)
                    {
                        result = string.Format("{0} {1}) белорусских рублей", result.Trim(), IntToStr(tis).Trim());
                    }
                }
                else
                {
                    result = result + " " + "белорусских рублей";
                }
            }

            return result.Remove(0, 1);
        }

    }
}


