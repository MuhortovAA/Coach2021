﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NLog;

namespace AutoQueriesAcquiring
{
    public class DataUpdateService
    {
        private PartnerPaymentEntities _db;
        private ConvertForMonth _convertForMonth;
        public MailService _mailService;
        private static Logger logger = LogManager.GetCurrentClassLogger();


        private List<sp_MailSettingsAcquiring_Result> listMailSettings()
        {
            using (_db = new PartnerPaymentEntities())
            {
                DateTime date = DateTime.Now.Date.AddMonths(-1);
                var firstDay = _convertForMonth.FirstDayMonth(date);
                var lastDay = _convertForMonth.LastDayMonth(date);
                return _db.sp_MailSettingsAcquiring().OrderBy(x => x.numBonusDog).ToList();
            }
        }

        private int CountWorkNew()
        {
            using (_db = new PartnerPaymentEntities())
            {
                DateTime date = DateTime.Now.Date.AddMonths(-1);
                var firstDay = _convertForMonth.FirstDayMonth(date);
                var lastDay = _convertForMonth.LastDayMonth(date);
                return _db.WorkAcqBank.Where(x => x.dateFrom == firstDay && x.dateTo == lastDay).Count();
            }
        }

        public void deleteMyFlag(string type)
        {
            using (_db = new PartnerPaymentEntities())
            {
                _convertForMonth = new ConvertForMonth();
                DateTime date = DateTime.Now.Date.AddMonths(-1);
                var firstDay = _convertForMonth.FirstDayMonth(date);
                var lastDay = _convertForMonth.LastDayMonth(date);
                WorkAcqBank item = _db.WorkAcqBank.Where(x => x.dateFrom == firstDay && x.dateTo == lastDay && x.numBonusDog == type).First();
                _db.WorkAcqBank.Remove(item);
                _db.SaveChanges();
                logger.Info($"Запись-информатор удалена из таблицы WorkNewAcq {DateTime.Now}");
            }
        }
    }
}
