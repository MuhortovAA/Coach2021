﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Linq;
using System.Globalization;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using System.Data.Entity.Core.Objects;
using System.Configuration;
using NLog;

namespace AutoQueriesAcquiring
{
    public class MailService
    {
        public PartnerPaymentEntities _db;
        public ConvertForMonth _convertForMonth;
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public void SendMessageLotus(string fileName, string type)
        {
            try
            {
                MailMessage message = new MailMessage
                {
                    Subject = "ПО Расчеты по партнерской программе",
                    From = new MailAddress("PartnerPayments@lotus.asb.by"),
                    Body = $"Добрый день. Файл для импорта {type} прилагается."
                };
                List<string> addresses = new List<string>();
                using (_db = new PartnerPaymentEntities())
                {
                    foreach (var item in _db.MailAddresses.Where(x => x.isWork >= 1))
                    {
                        message.To.Add(item.email);
                        addresses.Add(item.email);
                    }
                }
                Attachment data = new Attachment(fileName, MediaTypeNames.Application.Octet);
                message.Attachments.Add(data);
                SmtpClient client = new SmtpClient(ConfigurationManager.AppSettings["MailAddress"].ToString());
                client.Send(message);
                client.Dispose();

                StringBuilder builder = new StringBuilder();
                foreach (string address in addresses)
                {
                    builder.Append(address).Append(" | ");
                }
                string result = builder.ToString();
                logger.Info($"Письмо с типом - {type} отправлено на ящики: {result}");
            }
            catch (Exception e)
            {
                logger.Error($"Ошибка отправки письма с типом {type}------- {e.Message}-----------------" +
                    $"{e.StackTrace}");
                throw new Exception(e.Message);
            }
        }
        public void SendErrorMessageLotus(string error)
        {
            try
            {
                MailMessage message = new MailMessage
                {
                    Subject = "ПО Расчеты по партнерской программе",
                    From = new MailAddress("PartnerPayments@lotus.asb.by"),
                    Body = $"Добрый день. {error}"
                };
                List<string> addresses = new List<string>();
                using (_db = new PartnerPaymentEntities())
                {
                    foreach (var item in _db.MailAddresses.Where(x => x.isWork == 2))
                    {
                        message.To.Add(item.email);
                        addresses.Add(item.email);
                    }
                }
                //Attachment data = new Attachment(fileName, MediaTypeNames.Application.Octet);
                // message.Attachments.Add(data);
                SmtpClient client = new SmtpClient(ConfigurationManager.AppSettings["MailAddress"].ToString());
                client.Send(message);
                client.Dispose();
                StringBuilder builder = new StringBuilder();
                foreach (string address in addresses)
                {
                    builder.Append(address).Append(" | ");
                }
                string result = builder.ToString();
                logger.Info($"Письмо с ошибкой ПО отправлено на ящики:{result}");

            }
            catch (Exception e)
            {
                logger.Error($"Ошибка отправки письма с ошибкой ------- {e.Message}-----------------" +
                   $"{e.StackTrace}");
                throw new Exception(e.Message);
            }
        }
    }
}
