﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
using System.Diagnostics;
using Microsoft.VisualBasic.FileIO;
using SharpCompress.Archives;
using SharpCompress.Common;
using SharpCompress.Readers;
using DataTable = System.Data.DataTable;
using FileProcessingPP.Core;
using FileProcessingPP.Service;
using NLog;
using static System.Net.Mime.MediaTypeNames;
using System.Reflection;
using System.Data.Entity.Validation;

namespace FileProcessingPP
{
    public class Program
    {
        //
        private static Logger logger = LogManager.GetCurrentClassLogger();
        public static PartnerPaymentEntities _db;
        static RepositoryPartnerPayment rep;
        static mySettingProg setting;

        static void Main(string[] args)
        {
            //
            var version = System.Reflection.Assembly.GetExecutingAssembly().GetName().Version;
            string Description = ((AssemblyDescriptionAttribute)Attribute.GetCustomAttribute(Assembly.GetExecutingAssembly(), typeof(AssemblyDescriptionAttribute), false)).Description;

            //БД
            rep = new RepositoryPartnerPayment();
            //настройка
            setting = new mySettingProg();
            //
            //logger.
            Console.WriteLine($"{DateTime.Now} Текущая версия {version.Major}.{version.Minor}.{version.Build}.{version.Revision} {Description}");
            //

            Console.WriteLine($"{DateTime.Now} ***текущий сервер СУБД: {myInformator.GetDataSource()}");
            //Console.WriteLine($"***путь к каталогу протоколирования: {setting.sPathLog}");
            Console.WriteLine($"{DateTime.Now} ***путь к каталогу CMS обработки: {setting.CMSPath}");
            Console.WriteLine($"{DateTime.Now} ***путь к каталогу GTRM обработки: {setting.GTRMPath}");
            Console.WriteLine($"{DateTime.Now} ***подробное протоколирование: {setting.DetailLog}");
            //
            logger.Info("Старт программы");
            //
            //myWriteLog.BeginLog(setting.sPathLog);
            //
            ImportCms2();
            //
            ImportGTRM2();
            Console.WriteLine();
            Console.WriteLine($"{DateTime.Now} Загрузка завершена! Нажмите любую клавишу для закрытия программы.");
            Console.ReadKey();
        }

        public static void ImportCms2()
        {
            //myWriteLog.DoWriteLog("***Загрузка файла CMS...");
            logger.Info("Загрузка файла CMS");
            string InternalNo = "";

            try
            {
                #region работа с файлом
                string fileName = "";
                var FileCollection = Directory.GetFiles(setting.CMSPath, setting.SFileNameRARCMS);

                foreach (var item in FileCollection)
                {
                    fileName = Path.GetFileNameWithoutExtension(item);
                    logger.Info($"разархивирование файла: {item} в каталог {setting.CMSWorkDir}");
                    //myWriteLog.DoWriteLog($"*** разархивирование файла: {item} в каталог {setting.CMSWorkDir}");
                    using (var compressed = ArchiveFactory.Open(item))
                    {
                        foreach (var entry in compressed.Entries)
                        {
                            if (!entry.IsDirectory)
                            {
                                entry.WriteToDirectory(setting.CMSWorkDir);
                            }
                        }
                    }
                    try
                    {
                        var sourceFile = item;
                        var destFile = setting.CMSPathArc + Path.GetFileName(item);
                        File.Move(sourceFile, destFile);
                        //myWriteLog.DoWriteLog($"*** файл перемещен: {destFile}");
                        logger.Info($"файл перемещен: {destFile}");
                    }
                    catch (Exception e)
                    {
                        //myWriteLog.DoWriteLog($"***...Ошибка перемещения: {e.Message}");
                        logger.Info($"...Ошибка перемещения: {e.Message}");
                    }
                }
                #endregion
                var directory = new DirectoryInfo(setting.CMSPath);

                foreach (string dir in Directory.GetFiles(setting.CMSWorkDir, setting.SFileNameTXTCMS))
                {
                    logger.Info($"запись в таблицу файла: {dir}");

                    var fs = File.Open(dir, FileMode.Open);
                    Console.WriteLine("Время начало загрузки: " + DateTime.Now.ToString("F"));
                    Console.WriteLine($"Обрабатывается файл: {fs.Name} \t Размер: {fs.Length} байт");


                    var handler = new HandlerBigFile(fs);
                    var cd = new ConvertData();
                    var list = new List<CMSNew>();
                    var dateDoc = DateTime.Now;
                    int number = 0;
                    int CountNoError = 0;

                    using (BinaryReader reader = new BinaryReader(fs, Encoding.Default))
                    {
                        while (handler.fEOF == 0)
                        {
                            string[] resultStr = handler.GetStr(reader).Split(';');//получить текущую строку из файла
                            if (handler.fEOF == 0)
                            {
                                dateDoc = Convert.ToDateTime(resultStr[2]).Date;//дата файла
                                CMSNew cms = cd.GetCMSNew(resultStr);//преобразуем в данные для CMS
                                if (!cd.fError) list.Add(cms);//список данных для CMS
                                Console.Write($"\r1(3):Обработка строки: {list.Count()} Выполнено: {handler.fsPosition * 100 / fs.Length}%");
                            }
                            else
                            {
                                int currentLineCursor = Console.CursorTop;
                                Console.SetCursorPosition(0, Console.CursorTop);
                                Console.Write(new string(' ', Console.WindowWidth));
                                Console.SetCursorPosition(0, currentLineCursor);
                                Console.Write($"\r1(3):Всего обработано строк: {list.Count()} Выполнено: 100%");
                                Console.WriteLine();
                            }
                            CountNoError = cd.CountNoError;
                            number = handler.CountRows;//текущее количество записей в файле
                        }

                    }
                    //сохранение в базу
                    Save(list);
                    logger.Info($"удаление файла: {dir}");
                    File.Delete(dir);
                    Console.Write("Сохранено\nВремя окончания загрузки: " + DateTime.Now.ToString("F"));
                    if (setting.DetailLog)
                    {
                        logger.Info($"Всего строк в файле:               {number}");
                        logger.Info($"Количество строк без ошибок:       {CountNoError}");
                    }
                    Console.WriteLine();
                    Console.WriteLine($"Всего строк в файле: {number}");
                    Console.WriteLine($"Количество строк без ошибок: {CountNoError}");
                }

            }
            catch (Exception e)
            {
                logger.Error($"Ошибка загрузки: {e.Message}");
                Console.WriteLine($"Ошибка загрузки: {e.Message}");
            }
            logger.Info("загрузка завершена");
        }

        private static void Handler_Changed(object sender, EventArgs e)
        {

        }

        public static void ImportCms()
        {
            myWriteLog.DoWriteLog("***Загрузка файла CMS...");
            string InternalNo = "";
            try
            {

                string fileName = "";
                var FileCollection = Directory.GetFiles(setting.CMSPath, setting.SFileNameRARCMS);

                foreach (var item in FileCollection)
                {

                    //var fileres = Path.GetFileNameWithoutExtension(item);
                    //fileName = item.Remove(0, 7).Remove(20, 4);
                    fileName = Path.GetFileNameWithoutExtension(item);
                    //var pathfile = $"{setting.CMSPath}{Path.GetFileName(item)}";
                    myWriteLog.DoWriteLog($"*** разархивирование файла: {item} в каталог {setting.CMSWorkDir}");
                    //fileName = item.Remove(0, 20).Remove(20, 4);
                    using (var compressed = ArchiveFactory.Open(item))
                    {
                        //var compressed = ArchiveFactory.Open(item);
                        foreach (var entry in compressed.Entries)
                        {
                            if (!entry.IsDirectory)
                            {
                                entry.WriteToDirectory(setting.CMSWorkDir);
                            }
                        }
                    }
                    myWriteLog.DoWriteLog($"*** удаление файла: {item}");
                    File.Delete(item);
                }

                foreach (string dir in Directory.GetFiles(setting.CMSWorkDir, setting.SFileNameTXTCMS))
                {
                    //var filetxt = $"{setting.CMSWorkDir}{Path.GetFileName(dir)}";
                    myWriteLog.DoWriteLog($"*** запись в таблицу файла: {dir}");
                    List<CMSNew> list = new List<CMSNew>();
                    int number = 0;
                    int j = 0;
                    // string nameTable = CreateNewCmsTable(dir);
                    string[] stringFile = File.ReadAllLines(dir, Encoding.Default);
                    DateTime dateDoc = DateTime.Now;
                    foreach (string str in stringFile)
                    {
                        number = number + 1;
                        var k = str.Split(';');
                        if (k[3] == "BYN")
                        {
                            j = j + 1;
                            InternalNo = k[20];
                            CMSNew fileIn = new CMSNew()
                            {
                                Card = k[0],
                                TransDateTime = Convert.ToDateTime(k[1]),
                                CMSDate = Convert.ToDateTime(k[2]).Date,
                                TransVal = k[3],
                                TransSum = Convert.ToDecimal(k[4]),
                                AccountVal = k[5],
                                AccountSum = Convert.ToDecimal(k[6]),
                                TransType = Convert.ToInt32(k[7]),
                                TransName = k[8],
                                MID = k[9],
                                TID = k[10],
                                MCC = k[11],
                                Field98 = k[12],
                                POSCode = k[13],
                                OTSName = k[14],
                                EventArea = k[15],
                                Filial = Convert.ToInt32(k[16]),
                                CBU = (k[17] == "   ") ? 0 : int.Parse(k[17]),
                                AccountInCMS = k[18],
                                AccountInScCard = (k[19] == "") ? 0 : Convert.ToDecimal(k[19]),
                                InternalNo = Convert.ToInt64(k[20]),
                                FIO = k[21]
                            };
                            list.Add(fileIn);
                        }
                        dateDoc = Convert.ToDateTime(k[2]).Date;
                    }

                    Console.WriteLine($"\n{DateTime.Now} Сохранение в базу данных файла за {dateDoc}");
                    Save(list);
                    myWriteLog.DoWriteLog($"*** удаление файла: {dir}");
                    File.Delete(dir);
                    Console.WriteLine("{DateTime.Now} Сохранено\nВремя окончания загрузки: " + DateTime.Now.ToString("F"));
                    if (setting.DetailLog)
                    {
                        myWriteLog.DoWriteLog($"*** Всего строк в файле:               {number}");
                        myWriteLog.DoWriteLog($"*** Количество строк без ошибок:       {j}");
                        myWriteLog.DoWriteLog($"*** Количество строк в исходном файле: {stringFile.Length}");
                    }

                    Console.WriteLine($"{DateTime.Now} Всего строк в файле {number}");
                    Console.WriteLine($"{DateTime.Now} Количество строк без ошибок: {j}");
                    Console.WriteLine($"{DateTime.Now} Количество строк в исходном файле: {stringFile.Length}");
                }
            }
            catch (Exception e)
            {
                string InternalNoError = InternalNo;
                myWriteLog.DoWriteLog("***...Ошибка загрузки!" + e.Message);
                Console.WriteLine("{DateTime.Now} Ошибка загрузки \n" + e.Message);
                Console.ReadKey();
            }
            myWriteLog.DoWriteLog("***...загрузка завершена!");
        }
        public static void ImportGTRM()
        {

            //var SPath = @"S:\GTRM\";
            //var SPath = @"D:\GTRM\";
            //var SPathArc = @"D:\Work\Archive\";

            try
            {
                foreach (var dir in Directory.GetFiles(setting.GTRMPath, "Бонусы *.xml"))
                {
                    var dateDoc = dir.Remove(0, 15).Remove(6, 4);
                    var dd = Convert.ToInt32(dateDoc.Remove(2, 4));
                    var mm = Convert.ToInt32(dateDoc.Remove(0, 2).Remove(2, 2));
                    var yyyy = Convert.ToInt32("20" + dateDoc.Remove(0, 4));
                    var dmy = new DateTime(yyyy, mm, dd);
                    DateTime? myTime = null;
                    var serializer = new XmlSerializer(typeof(Workbook));
                    using (var fs = new FileStream(dir, FileMode.Open))
                    {
                        var input = (Workbook)serializer.Deserialize(fs);
                        var length = input.Worksheet.Table.Row.Length;
                        if (length > 0)
                        {
                            //очистка таблицы

                            truncateTableGTRM();
                            //загрузка данных
                            for (int i = 1; i < length; i++)
                            {
                                Console.Clear();
                                Console.WriteLine($"{DateTime.Now} загрузка записей GTRM: {i * 100 / length}% : {length - i} из {length}");

                                var record = input.Worksheet.Table.Row[i].Cell;

                                if (record[6].Data.Value != "Штрихкодирование" && record[6].Data.Value != "")
                                {
                                    GTRMSave(record, dmy, myTime, i);
                                }
                            }
                        }
                    }
                }
                var directory1 = new DirectoryInfo(setting.GTRMPath);
                foreach (var f1 in directory1.GetFiles())
                {
                    f1.MoveTo(setting.SPathArc + f1);
                }
            }
            catch (Exception e)
            {
                //string sd = "";
                throw new Exception(e.Message);
            }

        }
        public static void ImportGTRM2()
        {
            logger.Info("Загрузка файла GTRM");
            //myWriteLog.DoWriteLog("***Загрузка файла GTRM...");
            try
            {
                #region выполнить
                foreach (var dir in Directory.GetFiles(setting.GTRMPath, setting.SFileNameGTRM))
                {
                    var serializer = new XmlSerializer(typeof(Workbook));
                    using (var fs = new FileStream(dir, FileMode.Open))
                    {
                        var input = (Workbook)serializer.Deserialize(fs);
                        rep.SaveData(
                            input,
                            myHandler.GetDate(Path.GetFileNameWithoutExtension(dir)),
                            null,
                            setting);
                    }
                }
                var directory = new DirectoryInfo(setting.GTRMPath);
                foreach (var file in directory.GetFiles())
                {
                    file.MoveTo(setting.SPathArc + file);
                    logger.Info($"файл перемещен: {setting.SPathArc + file}");
                    //myWriteLog.DoWriteLog($"*** файл перемещен: {setting.SPathArc + file}");
                }
                #endregion
            }
            catch (DbEntityValidationException e)
            {
                logger.Error($"Ошибка: {e.Message}");
                Console.WriteLine();
                foreach (var errors in e.EntityValidationErrors)
                {
                    foreach (var validationError in errors.ValidationErrors)
                    {
                        logger.Error($"Ошибка: {validationError.ErrorMessage} {validationError.PropertyName}");
                        Console.WriteLine($"{DateTime.Now} Ошибка: {validationError.ErrorMessage} {validationError.PropertyName}");
                    }
                }

            }
            catch (Exception e)
            {
                logger.Error($"Ошибка: {e.Message}");
                //myWriteLog.DoWriteLog($"***Ошибка: {e.Message}");
                throw new Exception(e.Message);
            }
            logger.Info("загрузка завершена!");
            //myWriteLog.DoWriteLog("***...загрузка завершена!");
        }


        public static void GTRMSave(WorkbookWorksheetTableRowCell[] record, DateTime dmy, DateTime? myTime, int i)
        {
            try
            {
                using (_db = new PartnerPaymentEntities())
                {
                    GTRM model = new GTRM();
                    {
                        model.dateDocument = dmy;
                        model.dateDownload = DateTime.Now;
                        model.nameAllOTS = record[0].Data.Value;
                        model.filialSign = Convert.ToInt16(record[1].Data.Value);
                        model.filialSupport = Convert.ToInt16((record[2].Data == null || record[2].Data.Value == null) ? record[1].Data.Value : record[2].Data.Value);
                        model.acquiring = Convert.ToByte(record[3].Data.Value);
                        model.unn = Convert.ToInt64(record[4].Data.Value);
                        model.numDogAcquiring = record[5].Data.Value;
                        model.typeBonusDog = record[6].Data.Value;
                        model.numBonusDog = record[7].Data.Value;
                        model.dateBonusDog = Convert.ToDateTime(record[8].Data.Value);
                        model.MCC = Convert.ToInt16(record[9].Data.Value);
                        model.MID = record[10].Data.Value;
                        model.field_098 = (record[11].Data == null) ? "" : record[11].Data.Value;
                        model.dateDownloadGTRM = (record[12].Data.Value == null)
                                ? myTime
                                : Convert.ToDateTime(record[12].Data.Value);
                        model.dateStartCredit = (record[13].Data.Value == null)
                                ? myTime
                                : Convert.ToDateTime(record[13].Data.Value);
                        //Дата регистрации ОТС в БПЦ по включению в партнерскую программу банка
                        model.dateFinishCredit = (record[14].Data.Value == null)
                                ? myTime
                                : Convert.ToDateTime(record[14].Data.Value);
                        //Дата внесения в ПК GTRM информации об исключении ОТС из участия в патнерской программе банка
                        model.dateDeleteInGTRM = (record[15].Data.Value == null)
                            ? myTime
                            : Convert.ToDateTime(record[15].Data.Value);
                        model.creditTime = Convert.ToInt16(record[16].Data.Value);
                        model.procentAcqASB = (record[17].Data.Value == null) ? 0 : Convert.ToDecimal(record[17].Data.Value.Replace(".", ","));
                        model.procentRez = (record[18].Data.Value == null) ? 0 : Convert.ToDecimal(record[18].Data.Value.Replace(".", ","));
                        model.procentNotRez = (record[19].Data.Value == null) ? 0 : Convert.ToDecimal(record[19].Data.Value.Replace(".", ","));
                        model.procentASBwithBonus = (record[20].Data.Value == null) ? 0 : Convert.ToDecimal(record[20].Data.Value.Replace(".", ","));
                        model.procentCashBack = Convert.ToDecimal(record[21].Data.Value.Replace(".", ","));
                        model.procentNonAcq = Convert.ToDecimal(record[22].Data.Value.Replace(".", ","));
                        model.nameOTS = (record[23].Data == null) ? "" : record[23].Data.Value;
                        model.typeProducts = (record[24].Data == null) ? "" : record[24].Data.Value;
                        model.rangeCodes = record[25].Data.Value;
                        model.tarif = (record[26].Data == null) ? "" : record[26].Data.Value;
                        model.region = (record[27].Data == null) ? "" : record[27].Data.Value;
                        model.district = (record[28].Data == null) ? "" : record[28].Data.Value;
                        model.cityType = (record[29].Data == null) ? "" : record[29].Data.Value;
                        model.cityName = (record[30].Data == null) ? "" : record[30].Data.Value;
                        model.streetType = (record[31].Data == null) ? "" : record[31].Data.Value;
                        model.streetName = (record[32].Data == null) ? "" : record[32].Data.Value;
                        model.houseNumber = (record[33].Data == null) ? "" : record[33].Data.Value;
                        model.category = (record[34].Data == null) ? "" : record[34].Data.Value;
                        model.siteOTS = (record[35].Data == null) ? "" : record[35].Data.Value;
                        model.email = (record[36].Data == null) ? "" : record[36].Data.Value;
                        model.linkDiscontProg = (record[37].Data == null) ? "" : record[37].Data.Value;
                        model.bankOTSAccount = (record[38].Data == null) ? "" : record[38].Data.Value;
                        model.curNumbAccountOTS = (record[39].Data == null) ? "" : record[39].Data.Value;
                        model.mfoBank = (record[40].Data == null) ? "" : record[40].Data.Value;
                        model.account = (record[41].Data == null) ? "" : record[41].Data.Value;
                        model.penalty = (record[42].Data == null || record[42].Data.Value == null) ? 0 : Convert.ToDecimal(record[42].Data.Value.Replace(".", ","));
                        model.notes = (record[43].Data == null) ? "" : record[43].Data.Value;
                        model.prim = (record[44].Data == null) ? "" : record[44].Data.Value;
                        model.addressOts = (record[51].Data == null) ? "" : record[51].Data.Value;
                        model.emailPartners = (record[54].Data == null) ? "" : record[54].Data.Value;
                        //Console.WriteLine(i + " " + model.nameAllOTS);
                        //if (record.Length == 53)
                        //{
                        //    model.addressOts = (record[51].Data == null) ? "" : record[51].Data.Value;
                        //}

                    }
                    _db.GTRM.Add(model);
                    _db.SaveChanges();
                }
            }
            catch (Exception e)
            {
                string dsd = e.Message;
                throw new Exception(e.Message);
            }
        }

        public static void Save<TEntity>(List<TEntity> list) where TEntity : class
        {
            string entityConnectionString = ConfigurationManager.ConnectionStrings["PartnerPaymentEntities"].ConnectionString;
            string providerConnectionString = new EntityConnectionStringBuilder(entityConnectionString).ProviderConnectionString;
            using (var loader = new SqlBulkCopy(providerConnectionString, SqlBulkCopyOptions.Default))
            {
                loader.DestinationTableName = "CMSNew";
                loader.BatchSize = list.Count;
                loader.BulkCopyTimeout = 100000;
                var table = new DataTable();
                var columns = TypeDescriptor.GetProperties(typeof(TEntity))
                    .Cast<PropertyDescriptor>()
                    .Where(propertyInfo => propertyInfo.PropertyType.Namespace.Equals("System"))
                    .ToArray();
                var con = new SqlConnection(providerConnectionString);
                con.Open();

                foreach (var entityColumn in columns)
                {
                    loader.ColumnMappings.Add(entityColumn.Name, entityColumn.Name);
                    table.Columns.Add(entityColumn.Name,
                        Nullable.GetUnderlyingType(entityColumn.PropertyType) ?? entityColumn.PropertyType);
                }
                con.Close();
                var values = new object[columns.Length];

                var countitem = 0;
                var length = 0;

                foreach (var item in list)
                {
                    countitem++;

                    for (var i = 0; i < values.Length; i++)
                    {
                        values[i] = columns[i].GetValue(item);
                    }

                    if (table.Rows.Count == 2097152)//контроль max значения
                    {
                        Console.WriteLine();
                        Console.Write($"\r3(3):Cохранение данных ({table.Rows.Count})...");
                        loader.WriteToServer(table);
                        int currentLineCursor2 = Console.CursorTop;
                        Console.SetCursorPosition(0, Console.CursorTop);
                        Console.SetCursorPosition(0, currentLineCursor2);
                        Console.Write($"3(3):Cохранение данных ({table.Rows.Count})... выполнено!");

                        //
                        Console.WriteLine();
                        Console.Write($"\r3(3):Очистка буфера ...");
                        table.Rows.Clear();
                        currentLineCursor2 = Console.CursorTop;
                        Console.SetCursorPosition(0, Console.CursorTop);
                        Console.SetCursorPosition(0, currentLineCursor2);
                        Console.Write($"3(3):Очистка буфера ... выполнено!");

                    }
                    table.Rows.Add(values);

                    string str = $"\r2(3):Подготовлено строк: {countitem} осталось: {list.Count() - countitem} Выполнено: {countitem * 100 / list.Count()}%";
                    if (str.Length != length)
                    {
                        int currentLineCursor2 = Console.CursorTop;
                        Console.SetCursorPosition(0, Console.CursorTop);
                        Console.Write(new string(' ', Console.WindowWidth));
                        Console.SetCursorPosition(0, currentLineCursor2);
                        length = str.Length;
                    }
                    Console.Write(str);
                }
                if (table.Rows.Count > 0)
                {
                    Console.WriteLine();
                    Console.Write($"\r3(3):Cохранение данных ({table.Rows.Count})...");
                    loader.WriteToServer(table);
                    Console.Write($"3(3):Cохранение данных ({table.Rows.Count})... выполнено!");
                }
                loader.Close();
                Console.WriteLine();
                Console.Write($"\r3(3):Процесс завершен");
            }

        }

        //public static string CreateNewCmsTable(string dir)
        //{
        //    string dateDoc = dir.Remove(0, 24).Remove(8, 4);
        //    string dd = dateDoc.Remove(0, 6);
        //    string mm = dateDoc.Remove(0, 4).Remove(2, 2);
        //    string yyyy = dateDoc.Remove(4, 4);
        //    string nameTable = "CMS" + yyyy + mm + dd;
        //    using (_db = new PartnerPaymentEntities())
        //    {
        //        _db.Database.ExecuteSqlCommand($"CREATE TABLE {nameTable} ([Id] [int] IDENTITY(1,1) NOT NULL," +
        //                                       "[Card] [nvarchar](16) NOT NULL," +
        //                                       "[TransDateTime] [datetime] NOT NULL," +
        //                                       "[CMSDate] [date] NOT NULL," +
        //                                       "[TransVal] [char](3) NOT NULL," +
        //                                       "[TransSum] [decimal](10, 2) NOT NULL," +
        //                                       "[AccountVal] [char](3) NOT NULL," +
        //                                       "[AccountSum] [decimal](10, 2) NOT NULL," +
        //                                       "[TransType] [int] NOT NULL," +
        //                                       "[TransName] [nvarchar](23) NOT NULL," +
        //                                       "[MID] [nvarchar](15) NOT NULL," +
        //                                       "[TID] [char](8) NOT NULL," +
        //                                       "[MCC] [char](4) NOT NULL," +
        //                                       "[Field98] [nvarchar](25) NULL," +
        //                                       "[POSCode] [nvarchar](50) NOT NULL," +
        //                                       "[OTSName] [nvarchar](27) NOT NULL," +
        //                                       "[EventArea] [nvarchar](20) NOT NULL," +
        //                                       "[Filial] [int] NOT NULL," +
        //                                       "[CBU] [int] NULL," +
        //                                       "[AccountInCMS] [nvarchar](20) NOT NULL," +
        //                                       "[AccountInScCard] [decimal](20, 0) NULL," +
        //                                       "[InternalNo] [bigint] NOT NULL," +
        //                                       "[FIO] [nvarchar](121) NOT NULL," +
        //                                       "[DateInProg] [datetime] NOT NULL)" +
        //                                       "ON [PRIMARY];" +
        //                                       $"CREATE NONCLUSTERED INDEX [Key_MT] ON[dbo].[{nameTable}] ([MID],[TransType]) INCLUDE([Card],[TransDateTime],[TransSum])");
        //    }
        //    return nameTable;
        //}

        public static void truncateTableGTRM()
        {
            using (_db = new PartnerPaymentEntities())
            {
                _db.Database.ExecuteSqlCommand("TRUNCATE TABLE [dbo].[GTRM]");
            }
        }
    }
}
