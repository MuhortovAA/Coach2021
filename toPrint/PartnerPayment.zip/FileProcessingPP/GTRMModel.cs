﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace FileProcessingPP
{
    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:schemas-microsoft-com:office:spreadsheet", IsNullable = false)]
    public partial class Workbook
    {

        private DocumentProperties documentPropertiesField;

        private OfficeDocumentSettings officeDocumentSettingsField;

        private ExcelWorkbook excelWorkbookField;

        private WorkbookStyle[] stylesField;

        private WorkbookNamedRange[] namesField;

        private WorkbookWorksheet worksheetField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:schemas-microsoft-com:office:office")]
        public DocumentProperties DocumentProperties
        {
            get
            {
                return this.documentPropertiesField;
            }
            set
            {
                this.documentPropertiesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:schemas-microsoft-com:office:office")]
        public OfficeDocumentSettings OfficeDocumentSettings
        {
            get
            {
                return this.officeDocumentSettingsField;
            }
            set
            {
                this.officeDocumentSettingsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:schemas-microsoft-com:office:excel")]
        public ExcelWorkbook ExcelWorkbook
        {
            get
            {
                return this.excelWorkbookField;
            }
            set
            {
                this.excelWorkbookField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Style", IsNullable = false)]
        public WorkbookStyle[] Styles
        {
            get
            {
                return this.stylesField;
            }
            set
            {
                this.stylesField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("NamedRange", IsNullable = false)]
        public WorkbookNamedRange[] Names
        {
            get
            {
                return this.namesField;
            }
            set
            {
                this.namesField = value;
            }
        }

        /// <remarks/>
        public WorkbookWorksheet Worksheet
        {
            get
            {
                return this.worksheetField;
            }
            set
            {
                this.worksheetField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:office")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:schemas-microsoft-com:office:office", IsNullable = false)]
    public partial class DocumentProperties
    {

        private string authorField;

        private string lastAuthorField;

        private System.DateTime createdField;

        private System.DateTime lastSavedField;

        private decimal versionField;

        /// <remarks/>
        public string Author
        {
            get
            {
                return this.authorField;
            }
            set
            {
                this.authorField = value;
            }
        }

        /// <remarks/>
        public string LastAuthor
        {
            get
            {
                return this.lastAuthorField;
            }
            set
            {
                this.lastAuthorField = value;
            }
        }

        /// <remarks/>
        public System.DateTime Created
        {
            get
            {
                return this.createdField;
            }
            set
            {
                this.createdField = value;
            }
        }

        /// <remarks/>
        public System.DateTime LastSaved
        {
            get
            {
                return this.lastSavedField;
            }
            set
            {
                this.lastSavedField = value;
            }
        }

        /// <remarks/>
        public decimal Version
        {
            get
            {
                return this.versionField;
            }
            set
            {
                this.versionField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:office")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:schemas-microsoft-com:office:office", IsNullable = false)]
    public partial class OfficeDocumentSettings
    {

        private object allowPNGField;

        /// <remarks/>
        public object AllowPNG
        {
            get
            {
                return this.allowPNGField;
            }
            set
            {
                this.allowPNGField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:schemas-microsoft-com:office:excel", IsNullable = false)]
    public partial class ExcelWorkbook
    {

        private ushort windowHeightField;

        private ushort windowWidthField;

        private byte windowTopXField;

        private byte windowTopYField;

        private string protectStructureField;

        private string protectWindowsField;

        /// <remarks/>
        public ushort WindowHeight
        {
            get
            {
                return this.windowHeightField;
            }
            set
            {
                this.windowHeightField = value;
            }
        }

        /// <remarks/>
        public ushort WindowWidth
        {
            get
            {
                return this.windowWidthField;
            }
            set
            {
                this.windowWidthField = value;
            }
        }

        /// <remarks/>
        public byte WindowTopX
        {
            get
            {
                return this.windowTopXField;
            }
            set
            {
                this.windowTopXField = value;
            }
        }

        /// <remarks/>
        public byte WindowTopY
        {
            get
            {
                return this.windowTopYField;
            }
            set
            {
                this.windowTopYField = value;
            }
        }

        /// <remarks/>
        public string ProtectStructure
        {
            get
            {
                return this.protectStructureField;
            }
            set
            {
                this.protectStructureField = value;
            }
        }

        /// <remarks/>
        public string ProtectWindows
        {
            get
            {
                return this.protectWindowsField;
            }
            set
            {
                this.protectWindowsField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookStyle
    {

        private WorkbookStyleAlignment alignmentField;

        private WorkbookStyleBorder[] bordersField;

        private WorkbookStyleFont fontField;

        private object interiorField;

        private WorkbookStyleNumberFormat numberFormatField;

        private object protectionField;

        private string idField;

        private string nameField;

        /// <remarks/>
        public WorkbookStyleAlignment Alignment
        {
            get
            {
                return this.alignmentField;
            }
            set
            {
                this.alignmentField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlArrayItemAttribute("Border", IsNullable = false)]
        public WorkbookStyleBorder[] Borders
        {
            get
            {
                return this.bordersField;
            }
            set
            {
                this.bordersField = value;
            }
        }

        /// <remarks/>
        public WorkbookStyleFont Font
        {
            get
            {
                return this.fontField;
            }
            set
            {
                this.fontField = value;
            }
        }

        /// <remarks/>
        public object Interior
        {
            get
            {
                return this.interiorField;
            }
            set
            {
                this.interiorField = value;
            }
        }

        /// <remarks/>
        public WorkbookStyleNumberFormat NumberFormat
        {
            get
            {
                return this.numberFormatField;
            }
            set
            {
                this.numberFormatField = value;
            }
        }

        /// <remarks/>
        public object Protection
        {
            get
            {
                return this.protectionField;
            }
            set
            {
                this.protectionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string ID
        {
            get
            {
                return this.idField;
            }
            set
            {
                this.idField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookStyleAlignment
    {

        private string verticalField;

        private string horizontalField;

        private byte wrapTextField;

        private bool wrapTextFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Vertical
        {
            get
            {
                return this.verticalField;
            }
            set
            {
                this.verticalField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Horizontal
        {
            get
            {
                return this.horizontalField;
            }
            set
            {
                this.horizontalField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte WrapText
        {
            get
            {
                return this.wrapTextField;
            }
            set
            {
                this.wrapTextField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool WrapTextSpecified
        {
            get
            {
                return this.wrapTextFieldSpecified;
            }
            set
            {
                this.wrapTextFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookStyleBorder
    {

        private string positionField;

        private string lineStyleField;

        private byte weightField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Position
        {
            get
            {
                return this.positionField;
            }
            set
            {
                this.positionField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string LineStyle
        {
            get
            {
                return this.lineStyleField;
            }
            set
            {
                this.lineStyleField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte Weight
        {
            get
            {
                return this.weightField;
            }
            set
            {
                this.weightField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookStyleFont
    {

        private string fontNameField;

        private string colorField;

        private byte charSetField;

        private bool charSetFieldSpecified;

        private string familyField;

        private byte sizeField;

        private bool sizeFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string FontName
        {
            get
            {
                return this.fontNameField;
            }
            set
            {
                this.fontNameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Color
        {
            get
            {
                return this.colorField;
            }
            set
            {
                this.colorField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified, Namespace = "urn:schemas-microsoft-com:office:excel")]
        public byte CharSet
        {
            get
            {
                return this.charSetField;
            }
            set
            {
                this.charSetField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool CharSetSpecified
        {
            get
            {
                return this.charSetFieldSpecified;
            }
            set
            {
                this.charSetFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified, Namespace = "urn:schemas-microsoft-com:office:excel")]
        public string Family
        {
            get
            {
                return this.familyField;
            }
            set
            {
                this.familyField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte Size
        {
            get
            {
                return this.sizeField;
            }
            set
            {
                this.sizeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool SizeSpecified
        {
            get
            {
                return this.sizeFieldSpecified;
            }
            set
            {
                this.sizeFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookStyleNumberFormat
    {

        private string formatField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Format
        {
            get
            {
                return this.formatField;
            }
            set
            {
                this.formatField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookNamedRange
    {

        private string nameField;

        private string refersToField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string RefersTo
        {
            get
            {
                return this.refersToField;
            }
            set
            {
                this.refersToField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheet
    {

        private WorkbookWorksheetNames namesField;

        private WorkbookWorksheetTable tableField;

        private WorksheetOptions worksheetOptionsField;

        private Sorting sortingField;

        private string nameField;

        /// <remarks/>
        public WorkbookWorksheetNames Names
        {
            get
            {
                return this.namesField;
            }
            set
            {
                this.namesField = value;
            }
        }

        /// <remarks/>
        public WorkbookWorksheetTable Table
        {
            get
            {
                return this.tableField;
            }
            set
            {
                this.tableField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:schemas-microsoft-com:office:excel")]
        public WorksheetOptions WorksheetOptions
        {
            get
            {
                return this.worksheetOptionsField;
            }
            set
            {
                this.worksheetOptionsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute(Namespace = "urn:schemas-microsoft-com:office:excel")]
        public Sorting Sorting
        {
            get
            {
                return this.sortingField;
            }
            set
            {
                this.sortingField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheetNames
    {

        private WorkbookWorksheetNamesNamedRange namedRangeField;

        /// <remarks/>
        public WorkbookWorksheetNamesNamedRange NamedRange
        {
            get
            {
                return this.namedRangeField;
            }
            set
            {
                this.namedRangeField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheetNamesNamedRange
    {

        private string nameField;

        private string refersToField;

        private byte hiddenField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string RefersTo
        {
            get
            {
                return this.refersToField;
            }
            set
            {
                this.refersToField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte Hidden
        {
            get
            {
                return this.hiddenField;
            }
            set
            {
                this.hiddenField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheetTable
    {

        private WorkbookWorksheetTableColumn[] columnField;

        private WorkbookWorksheetTableRow[] rowField;

        private byte expandedColumnCountField;

        private ushort expandedRowCountField;

        private byte fullColumnsField;

        private byte fullRowsField;

        private string styleIDField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Column")]
        public WorkbookWorksheetTableColumn[] Column
        {
            get
            {
                return this.columnField;
            }
            set
            {
                this.columnField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Row")]
        public WorkbookWorksheetTableRow[] Row
        {
            get
            {
                return this.rowField;
            }
            set
            {
                this.rowField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte ExpandedColumnCount
        {
            get
            {
                return this.expandedColumnCountField;
            }
            set
            {
                this.expandedColumnCountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public ushort ExpandedRowCount
        {
            get
            {
                return this.expandedRowCountField;
            }
            set
            {
                this.expandedRowCountField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified, Namespace = "urn:schemas-microsoft-com:office:excel")]
        public byte FullColumns
        {
            get
            {
                return this.fullColumnsField;
            }
            set
            {
                this.fullColumnsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified, Namespace = "urn:schemas-microsoft-com:office:excel")]
        public byte FullRows
        {
            get
            {
                return this.fullRowsField;
            }
            set
            {
                this.fullRowsField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string StyleID
        {
            get
            {
                return this.styleIDField;
            }
            set
            {
                this.styleIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheetTableColumn
    {

        private string styleIDField;

        private byte autoFitWidthField;

        private decimal widthField;

        private byte spanField;

        private bool spanFieldSpecified;

        private byte indexField;

        private bool indexFieldSpecified;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string StyleID
        {
            get
            {
                return this.styleIDField;
            }
            set
            {
                this.styleIDField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte AutoFitWidth
        {
            get
            {
                return this.autoFitWidthField;
            }
            set
            {
                this.autoFitWidthField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public decimal Width
        {
            get
            {
                return this.widthField;
            }
            set
            {
                this.widthField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte Span
        {
            get
            {
                return this.spanField;
            }
            set
            {
                this.spanField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool SpanSpecified
        {
            get
            {
                return this.spanFieldSpecified;
            }
            set
            {
                this.spanFieldSpecified = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte Index
        {
            get
            {
                return this.indexField;
            }
            set
            {
                this.indexField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlIgnoreAttribute()]
        public bool IndexSpecified
        {
            get
            {
                return this.indexFieldSpecified;
            }
            set
            {
                this.indexFieldSpecified = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheetTableRow
    {

        private WorkbookWorksheetTableRowCell[] cellField;

        private byte autoFitHeightField;

        private decimal heightField;

        private string styleIDField;

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("Cell")]
        public WorkbookWorksheetTableRowCell[] Cell
        {
            get
            {
                return this.cellField;
            }
            set
            {
                this.cellField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public byte AutoFitHeight
        {
            get
            {
                return this.autoFitHeightField;
            }
            set
            {
                this.autoFitHeightField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public decimal Height
        {
            get
            {
                return this.heightField;
            }
            set
            {
                this.heightField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string StyleID
        {
            get
            {
                return this.styleIDField;
            }
            set
            {
                this.styleIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheetTableRowCell
    {

        private WorkbookWorksheetTableRowCellData dataField;

        private WorkbookWorksheetTableRowCellNamedCell[] namedCellField;

        private string styleIDField;

        /// <remarks/>
        public WorkbookWorksheetTableRowCellData Data
        {
            get
            {
                return this.dataField;
            }
            set
            {
                this.dataField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlElementAttribute("NamedCell")]
        public WorkbookWorksheetTableRowCellNamedCell[] NamedCell
        {
            get
            {
                return this.namedCellField;
            }
            set
            {
                this.namedCellField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string StyleID
        {
            get
            {
                return this.styleIDField;
            }
            set
            {
                this.styleIDField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheetTableRowCellData
    {

        private string typeField;

        private string valueField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Type
        {
            get
            {
                return this.typeField;
            }
            set
            {
                this.typeField = value;
            }
        }

        /// <remarks/>
        [System.Xml.Serialization.XmlTextAttribute()]
        public string Value
        {
            get
            {
                return this.valueField;
            }
            set
            {
                this.valueField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:spreadsheet")]
    public partial class WorkbookWorksheetTableRowCellNamedCell
    {

        private string nameField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Name
        {
            get
            {
                return this.nameField;
            }
            set
            {
                this.nameField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:schemas-microsoft-com:office:excel", IsNullable = false)]
    public partial class WorksheetOptions
    {

        private WorksheetOptionsPageSetup pageSetupField;

        private WorksheetOptionsPrint printField;

        private object selectedField;

        private ushort topRowVisibleField;

        private byte leftColumnVisibleField;

        private WorksheetOptionsPanes panesField;

        private string protectObjectsField;

        private string protectScenariosField;

        /// <remarks/>
        public WorksheetOptionsPageSetup PageSetup
        {
            get
            {
                return this.pageSetupField;
            }
            set
            {
                this.pageSetupField = value;
            }
        }

        /// <remarks/>
        public WorksheetOptionsPrint Print
        {
            get
            {
                return this.printField;
            }
            set
            {
                this.printField = value;
            }
        }

        /// <remarks/>
        public object Selected
        {
            get
            {
                return this.selectedField;
            }
            set
            {
                this.selectedField = value;
            }
        }

        /// <remarks/>
        public ushort TopRowVisible
        {
            get
            {
                return this.topRowVisibleField;
            }
            set
            {
                this.topRowVisibleField = value;
            }
        }

        /// <remarks/>
        public byte LeftColumnVisible
        {
            get
            {
                return this.leftColumnVisibleField;
            }
            set
            {
                this.leftColumnVisibleField = value;
            }
        }

        /// <remarks/>
        public WorksheetOptionsPanes Panes
        {
            get
            {
                return this.panesField;
            }
            set
            {
                this.panesField = value;
            }
        }

        /// <remarks/>
        public string ProtectObjects
        {
            get
            {
                return this.protectObjectsField;
            }
            set
            {
                this.protectObjectsField = value;
            }
        }

        /// <remarks/>
        public string ProtectScenarios
        {
            get
            {
                return this.protectScenariosField;
            }
            set
            {
                this.protectScenariosField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    public partial class WorksheetOptionsPageSetup
    {

        private WorksheetOptionsPageSetupHeader headerField;

        private WorksheetOptionsPageSetupFooter footerField;

        /// <remarks/>
        public WorksheetOptionsPageSetupHeader Header
        {
            get
            {
                return this.headerField;
            }
            set
            {
                this.headerField = value;
            }
        }

        /// <remarks/>
        public WorksheetOptionsPageSetupFooter Footer
        {
            get
            {
                return this.footerField;
            }
            set
            {
                this.footerField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    public partial class WorksheetOptionsPageSetupHeader
    {

        private string dataField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Data
        {
            get
            {
                return this.dataField;
            }
            set
            {
                this.dataField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    public partial class WorksheetOptionsPageSetupFooter
    {

        private string dataField;

        /// <remarks/>
        [System.Xml.Serialization.XmlAttributeAttribute(Form = System.Xml.Schema.XmlSchemaForm.Qualified)]
        public string Data
        {
            get
            {
                return this.dataField;
            }
            set
            {
                this.dataField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    public partial class WorksheetOptionsPrint
    {

        private object validPrinterInfoField;

        private byte paperSizeIndexField;

        private ushort horizontalResolutionField;

        private ushort verticalResolutionField;

        private object gridlinesField;

        /// <remarks/>
        public object ValidPrinterInfo
        {
            get
            {
                return this.validPrinterInfoField;
            }
            set
            {
                this.validPrinterInfoField = value;
            }
        }

        /// <remarks/>
        public byte PaperSizeIndex
        {
            get
            {
                return this.paperSizeIndexField;
            }
            set
            {
                this.paperSizeIndexField = value;
            }
        }

        /// <remarks/>
        public ushort HorizontalResolution
        {
            get
            {
                return this.horizontalResolutionField;
            }
            set
            {
                this.horizontalResolutionField = value;
            }
        }

        /// <remarks/>
        public ushort VerticalResolution
        {
            get
            {
                return this.verticalResolutionField;
            }
            set
            {
                this.verticalResolutionField = value;
            }
        }

        /// <remarks/>
        public object Gridlines
        {
            get
            {
                return this.gridlinesField;
            }
            set
            {
                this.gridlinesField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    public partial class WorksheetOptionsPanes
    {

        private WorksheetOptionsPanesPane paneField;

        /// <remarks/>
        public WorksheetOptionsPanesPane Pane
        {
            get
            {
                return this.paneField;
            }
            set
            {
                this.paneField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    public partial class WorksheetOptionsPanesPane
    {

        private byte numberField;

        private ushort activeRowField;

        private byte activeColField;

        /// <remarks/>
        public byte Number
        {
            get
            {
                return this.numberField;
            }
            set
            {
                this.numberField = value;
            }
        }

        /// <remarks/>
        public ushort ActiveRow
        {
            get
            {
                return this.activeRowField;
            }
            set
            {
                this.activeRowField = value;
            }
        }

        /// <remarks/>
        public byte ActiveCol
        {
            get
            {
                return this.activeColField;
            }
            set
            {
                this.activeColField = value;
            }
        }
    }

    /// <remarks/>
    [System.SerializableAttribute()]
    [System.ComponentModel.DesignerCategoryAttribute("code")]
    [System.Xml.Serialization.XmlTypeAttribute(AnonymousType = true, Namespace = "urn:schemas-microsoft-com:office:excel")]
    [System.Xml.Serialization.XmlRootAttribute(Namespace = "urn:schemas-microsoft-com:office:excel", IsNullable = false)]
    public partial class Sorting
    {

        private string sortField;

        /// <remarks/>
        public string Sort
        {
            get
            {
                return this.sortField;
            }
            set
            {
                this.sortField = value;
            }
        }
    }




}


