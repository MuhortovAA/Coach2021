﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.Entity.Core.EntityClient;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingPP.Service
{
    public static class myInformator
    {


        public static string GetDataSource()
        {
            var connectionString = ConfigurationManager.ConnectionStrings["PartnerPaymentEntities"].ConnectionString;
            var builder = new EntityConnectionStringBuilder(connectionString);
            var count = 0;
            foreach (var item in builder.Values)
            {
                count++;
                if (count == 4)
                {
                    var cs = new SqlConnectionStringBuilder(item.ToString());
                    return cs.DataSource;
                }

            }
            return String.Empty;
        }
        public static string GetList(GTRM g)
        {
            var PropG = g.GetType().GetProperties();
            var str = "";
            for (int i = 1; i < PropG.Count(); i++)
            {
                str = i == 1 ? $"{i}:{PropG[i].Name}: {PropG[i].GetValue(g, null)}\r" : $"{str}, {i}:{PropG[i].Name}: {PropG[i].GetValue(g, null)}\r";
            }
            return str;
        }
    }
}
