﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingPP.Service.Interfaces
{
    interface IRepositoryPartnerPayment<T> : IDisposable
          where T : class
    {

        void DeleteAllWorkContract();
        void SaveData(GTRM contract);
        void SaveData(WorkbookWorksheetTableRowCell[] record, DateTime dmy, DateTime? myTime, int i);
        void SaveData(Workbook table, DateTime dmy, DateTime? myTime, mySettingProg setting);
        bool OnCheck(GTRM contract);
        //IEnumerable<T> GetAll(string idUser);
        //T Get(int id);
        //void Create(T item);
        //void Update(T item);
        //void Delete(int id);
        void Save();

    }
}
