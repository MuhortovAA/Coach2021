﻿using FileProcessingPP.Core;
using FileProcessingPP.Service.Interfaces;
using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;


namespace FileProcessingPP.Service
{


    class RepositoryPartnerPayment : IRepositoryPartnerPayment<PartnerPaymentEntities>
    {

        private static Logger logger = LogManager.GetCurrentClassLogger();

        PartnerPaymentEntities db;

        public RepositoryPartnerPayment()
        {
            //db = new PartnerPaymentEntities();
        }

        public bool OnCheck(GTRM contract)
        {
            int? resultCount = db.GTRM.Where(s => s.dateFinishCredit != null
            && s.dateDeleteInGTRM != null
            && s.numDogAcquiring == contract.numDogAcquiring
            && s.unn == contract.unn
            && s.MCC == contract.MCC
            && s.MID == contract.MID
            && s.numBonusDog == contract.numBonusDog
            //new
            && s.dateStartCredit==contract.dateStartCredit
            && s.dateFinishCredit== contract.dateFinishCredit
            && s.dateDeleteInGTRM == contract.dateDeleteInGTRM
            && s.rangeCodes == contract.rangeCodes
            && s.tarif == contract.tarif


            ).Count();

            var check = resultCount == 0 ? false : true;

            return check;

        }

        /// <summary>
        /// удаление рабочих контрактов
        /// </summary>
        public void DeleteAllWorkContract()
        {
            //myWriteLog.DoWriteLog($"***старт процесса удаления данных из GTRM ...");

            //string sql = "delete from [PartnerPayment].[dbo].[GTRM] where [dateFinishCredit] is not null and [dateDeleteInGTRM] is not null";



            //using (db = new PartnerPaymentEntities())
            //{
            //    db.Database.ExecuteSqlCommand(sql);
            //}

            //myWriteLog.DoWriteLog($"***...удаление выполнено!");
            using (db = new PartnerPaymentEntities())
            {

                ////все контракты рабочие
                ///
                //db = new PartnerPaymentEntities();
                var contracts = db.GTRM.Where(s => s.dateFinishCredit == null && s.dateDeleteInGTRM == null).AsEnumerable<GTRM>();

                if (contracts != null)
                {
                    logger.Info($"старт процесса удаления данных из GTRM ...");
                    //myWriteLog.DoWriteLog($"***старт процесса удаления данных из GTRM ...");
                    //
                    var sql = "delete from [PartnerPayment].[dbo].[GTRM] where [dateFinishCredit] is null and [dateDeleteInGTRM] is null";
                    //тайм аут 
                    db.Database.CommandTimeout = 20000;
                    //
                    db.Database.ExecuteSqlCommand(sql);
                    logger.Info($"***...удаление выполнено!");
                    //myWriteLog.DoWriteLog($"***...удаление выполнено!");
                    // удаление контракта
                    //using (db = new PartnerPaymentEntities())
                    //{
                    //db.GTRM.RemoveRange(contracts);
                    //}
                    //myWriteLog.DoWriteLog($"***...удаление {contracts.Count()} выполнено!");
                }
                else
                {
                    //myWriteLog.DoWriteLog($"***Нет записей для удаления!");
                    logger.Info($"***Нет записей для удаления!");
                }
            }

        }



        public void Dispose()
        {
            throw new NotImplementedException();
        }

        public void Save()
        {
            db.SaveChanges();
            //myWriteLog.DoWriteLog($"***...добавление выполнено!");
        }

        public void SaveData(GTRM contract)
        {
            //
            db.GTRM.Add(contract);
            //
            this.Save();
        }

        public void SaveData(WorkbookWorksheetTableRowCell[] record, DateTime dmy, DateTime? myTime, int i)
        {
            try
            {
                var contract = new GTRM()
                {
                    dateDocument = dmy,
                    dateDownload = DateTime.Now,
                    nameAllOTS = record[0].Data.Value,
                    filialSign = Convert.ToInt16(record[1].Data.Value),
                    filialSupport = Convert.ToInt16((record[2].Data == null || record[2].Data.Value == null) ? record[1].Data.Value : record[2].Data.Value),
                    acquiring = Convert.ToByte(record[3].Data.Value),
                    unn = Convert.ToInt64(record[4].Data.Value),
                    numDogAcquiring = record[5].Data.Value,
                    typeBonusDog = record[6].Data.Value,
                    numBonusDog = record[7].Data.Value,
                    dateBonusDog = Convert.ToDateTime(record[8].Data.Value),
                    MCC = Convert.ToInt16(record[9].Data.Value),
                    MID = record[10].Data.Value,
                    field_098 = (record[11].Data == null) ? "" : record[11].Data.Value,
                    dateDownloadGTRM = (record[12].Data.Value == null) ? myTime : Convert.ToDateTime(record[12].Data.Value),
                    dateStartCredit = (record[13].Data.Value == null) ? myTime : Convert.ToDateTime(record[13].Data.Value),
                    //Дата регистрации ОТС в БПЦ по включению в партнерскую программу банка
                    dateFinishCredit = (record[14].Data.Value == null) ? myTime : Convert.ToDateTime(record[14].Data.Value),
                    //Дата внесения в ПК GTRM информации об исключении ОТС из участия в патнерской программе банка
                    dateDeleteInGTRM = (record[15].Data.Value == null) ? myTime : Convert.ToDateTime(record[15].Data.Value),
                    creditTime = Convert.ToInt16(record[16].Data.Value),
                    procentAcqASB = (record[17].Data.Value == null) ? 0 : Convert.ToDecimal(record[17].Data.Value.Replace(".", ",")),
                    procentRez = (record[18].Data.Value == null) ? 0 : Convert.ToDecimal(record[18].Data.Value.Replace(".", ",")),
                    procentNotRez = (record[19].Data.Value == null) ? 0 : Convert.ToDecimal(record[19].Data.Value.Replace(".", ",")),
                    procentASBwithBonus = (record[20].Data.Value == null) ? 0 : Convert.ToDecimal(record[20].Data.Value.Replace(".", ",")),
                    procentCashBack = Convert.ToDecimal(record[21].Data.Value.Replace(".", ",")),
                    procentNonAcq = Convert.ToDecimal(record[22].Data.Value.Replace(".", ",")),
                    nameOTS = (record[23].Data == null) ? "" : record[23].Data.Value,
                    typeProducts = (record[24].Data == null) ? "" : record[24].Data.Value,
                    rangeCodes = record[25].Data.Value,
                    tarif = (record[26].Data == null) ? "" : record[26].Data.Value,
                    region = (record[27].Data == null) ? "" : record[27].Data.Value,
                    district = (record[28].Data == null) ? "" : record[28].Data.Value,
                    cityType = (record[29].Data == null) ? "" : record[29].Data.Value,
                    cityName = (record[30].Data == null) ? "" : record[30].Data.Value,
                    streetType = (record[31].Data == null) ? "" : record[31].Data.Value,
                    streetName = (record[32].Data == null) ? "" : record[32].Data.Value,
                    houseNumber = (record[33].Data == null) ? "" : record[33].Data.Value,
                    category = (record[34].Data == null) ? "" : record[34].Data.Value,
                    siteOTS = (record[35].Data == null) ? "" : record[35].Data.Value,
                    email = (record[36].Data == null) ? "" : record[36].Data.Value,
                    linkDiscontProg = (record[37].Data == null) ? "" : record[37].Data.Value,
                    bankOTSAccount = (record[38].Data == null) ? "" : record[38].Data.Value,
                    curNumbAccountOTS = (record[39].Data == null) ? "" : record[39].Data.Value,
                    mfoBank = (record[40].Data == null) ? "" : record[40].Data.Value,
                    account = (record[41].Data == null) ? "" : record[41].Data.Value,
                    penalty = (record[42].Data == null || record[42].Data.Value == null) ? 0 : Convert.ToDecimal(record[42].Data.Value.Replace(".", ",")),
                    notes = (record[43].Data == null) ? "" : record[43].Data.Value,
                    prim = (record[44].Data == null) ? "" : record[44].Data.Value,
                    addressOts = (record[51].Data == null) ? "" : record[51].Data.Value,
                    //54 - 55 записей в строке
                    emailPartners = record.Count() == 54 ?
                       record[53].Data == null ? "" : record[53].Data.Value : record.Count() == 55 ? record[54].Data == null ? "" : record[54].Data.Value
                       : ""
                };
                var collections = contract.GetType().GetProperties();
                myWriteLog.DoWriteLog($"Процесс добавления записи ...");
                var countColl = 1;
                foreach (var coll in collections)
                {
                    myWriteLog.DoWriteLog($"{countColl++}:[{coll.Name}]:{coll.GetValue(contract)}");
                }
                db.GTRM.Add(contract);
                db.SaveChanges();
                //this.Save();
                myWriteLog.DoWriteLog($"***...добавление выполнено!");
            }
            catch (Exception e)
            {
                myWriteLog.DoWriteLog($"***Ошибка: {e.Message}");
                throw new Exception(e.Message);
            }
        }

        public void SaveData(Workbook wb, DateTime dmy, DateTime? myTime, mySettingProg setting)
        {

            //загрузка из файла
            var length = wb.Worksheet.Table.Row.Length;

            var countRecords = 55;

            if (length > 0)
            {
                #region выполнить
                //удаляем рабочие контракты
                this.DeleteAllWorkContract();
                //проверка записей
                bool result = CheckRecord(wb.Worksheet.Table.Row, countRecords);

                //результат - проверка выполнена успешено - убрать если нужно делать автоматически
                //result = true;

                if (result)
                {
                    //перебор всех строк
                    int countRow = 0;
                    int counterr = 0;
                    foreach (var row in wb.Worksheet.Table.Row)
                    {
                        if (countRow > 0)
                        {
                            var cursor = Console.CursorTop;
                            var messprot = $"{DateTime.Now} загрузка записей GTRM: {countRow * 100 / (length)}% текущая: {countRow} осталось:{length - countRow} из {length} ошибки:{counterr}";
                            Console.WriteLine(messprot);
                            Console.CursorTop = cursor;
                            if (setting.DetailLog) myWriteLog.DoWriteLog(messprot);
                            if (row.Cell[6].Data.Value != "Штрихкодирование" && row.Cell[6].Data.Value != "")
                            {
                                var record = row.Cell;

                                if (record.Count() != countRecords)
                                {
                                    logger.Error($"В строке {countRow} ожидается {countRecords} записей а получено {record.Count()}");
                                }

                                var contract = new GTRM();

                                contract.dateDocument = dmy;
                                contract.dateDownload = DateTime.Now;
                                contract.nameAllOTS = record[0].Data.Value;
                                contract.filialSign = Convert.ToInt16(record[1].Data.Value);
                                contract.filialSupport = Convert.ToInt16((record[2].Data == null || record[2].Data.Value == null) ? record[1].Data.Value : record[2].Data.Value);
                                contract.acquiring = Convert.ToByte(record[3].Data.Value);
                                contract.unn = Convert.ToInt64(record[4].Data.Value);
                                contract.numDogAcquiring = record[5].Data.Value;
                                contract.typeBonusDog = record[6].Data.Value;
                                contract.numBonusDog = record[7].Data.Value;
                                contract.dateBonusDog = Convert.ToDateTime(record[8].Data.Value);
                                contract.MCC = Convert.ToInt16(record[9].Data.Value);
                                contract.MID = record[10].Data == null ? "" : record[10].Data.Value == null ? "" : record[10].Data.Value;
                                contract.field_098 = record[11].Data == null ? "" : record[11].Data.Value == null ? "" : record[11].Data.Value;
                                contract.dateDownloadGTRM = record[12].Data == null ? myTime : record[12].Data.Value == null ? myTime : Convert.ToDateTime(record[12].Data.Value);
                                contract.dateStartCredit = record[13].Data == null ? myTime : record[13].Data.Value == null ? myTime : Convert.ToDateTime(record[13].Data.Value);
                                //Дата регистрации ОТС в БПЦ по включению в партнерскую программу банка
                                contract.dateFinishCredit = record[14].Data == null ? myTime : record[14].Data.Value == null ? myTime : Convert.ToDateTime(record[14].Data.Value);
                                //Дата внесения в ПК GTRM информации об исключении ОТС из участия в патнерской программе банка
                                contract.dateDeleteInGTRM = record[15].Data == null ? myTime : record[15].Data.Value == null ? myTime : Convert.ToDateTime(record[15].Data.Value);
                                contract.creditTime = Convert.ToInt16(record[16].Data.Value);
                                contract.procentAcqASB = record[17].Data == null ? 0 : record[17].Data.Value == null ? 0 : Convert.ToDecimal(record[17].Data.Value.Replace(".", ","));
                                contract.procentRez = record[18].Data == null ? 0 : record[18].Data.Value == null ? 0 : Convert.ToDecimal(record[18].Data.Value.Replace(".", ","));
                                contract.procentNotRez = record[19].Data == null ? 0 : record[19].Data.Value == null ? 0 : Convert.ToDecimal(record[19].Data.Value.Replace(".", ","));
                                contract.procentASBwithBonus = record[20].Data == null ? 0 : record[20].Data.Value == null ? 0 : Convert.ToDecimal(record[20].Data.Value.Replace(".", ","));
                                contract.procentCashBack = Convert.ToDecimal(record[21].Data.Value.Replace(".", ","));
                                contract.procentNonAcq = Convert.ToDecimal(record[22].Data.Value.Replace(".", ","));
                                contract.nameOTS = record[23].Data == null ? "" : record[23].Data.Value == null ? "" : record[23].Data.Value;
                                contract.typeProducts = record[24].Data == null ? "" : record[24].Data.Value == null ? "" : record[24].Data.Value;
                                contract.rangeCodes = record[25].Data == null ? "" : record[25].Data.Value == null ? "" : record[25].Data.Value;
                                contract.tarif = record[26].Data == null ? "" : record[26].Data.Value == null ? "" : record[26].Data.Value;
                                contract.region = record[27].Data == null ? "" : record[27].Data.Value == null ? "" : record[27].Data.Value;
                                contract.district = record[28].Data == null ? "" : record[28].Data.Value == null ? "" : record[28].Data.Value;
                                contract.cityType = record[29].Data == null ? "" : record[29].Data.Value == null ? "" : record[29].Data.Value;
                                contract.cityName = record[30].Data == null ? "" : record[30].Data.Value == null ? "" : record[30].Data.Value;
                                contract.streetType = record[31].Data == null ? "" : record[31].Data.Value == null ? "" : record[31].Data.Value;
                                contract.streetName = record[32].Data == null ? "" : record[32].Data.Value == null ? "" : record[32].Data.Value;
                                contract.houseNumber = record[33].Data == null ? "" : record[33].Data.Value == null ? "" : record[33].Data.Value;
                                contract.category = record[34].Data == null ? "" : record[34].Data.Value == null ? "" : record[34].Data.Value;
                                contract.siteOTS = record[35].Data == null ? "" : record[35].Data.Value == null ? "" : record[35].Data.Value;
                                contract.email = record[36].Data == null ? "" : record[36].Data.Value == null ? "" : record[36].Data.Value;
                                contract.linkDiscontProg = record[37].Data == null ? "" : record[37].Data.Value == null ? "" : record[37].Data.Value;
                                contract.bankOTSAccount = record[38].Data == null ? "" : record[38].Data.Value == null ? "" : record[38].Data.Value;
                                contract.curNumbAccountOTS = record[39].Data == null ? "" : record[39].Data.Value == null ? "" : record[39].Data.Value;
                                contract.mfoBank = record[40].Data == null ? "" : record[40].Data.Value == null ? "" : record[40].Data.Value.Length > 11 ? "" : record[40].Data.Value;
                                contract.account = record[41].Data == null ? "" : record[41].Data.Value == null ? "" : record[41].Data.Value;
                                contract.penalty = record[42].Data == null ? 0 : record[42].Data.Value == null ? 0 : Convert.ToDecimal(myHandler.GetDecimal(record[42].Data.Value.Replace(".", ",").ToString()));
                                contract.notes = record[43].Data == null ? "" : record[43].Data.Value == null ? "" : record[43].Data.Value;
                                contract.prim = record[44].Data == null ? "" : record[44].Data.Value == null ? "" : record[44].Data.Value;
                                contract.addressOts = record[51].Data == null ? "" : record[51].Data.Value == null ? "" : record[51].Data.Value;
                                //54 - 55 записей в строке
                                contract.emailPartners = record.Count() == 55 ? record[54].Data == null ? "" : record[54].Data.Value == null ? "" : record[54].Data.Value : "";
                                //
                                if (setting.DetailLog) logger.Info($"N{countRow} " + myInformator.GetList(contract));
                                //
                                //проверка на дублирование
                                using (db = new PartnerPaymentEntities())
                                {
                                    if (contract.dateFinishCredit != null && contract.dateDeleteInGTRM != null)
                                    {
                                        var res = this.OnCheck(contract);
                                        if (!res)
                                        //if (true)
                                        {
                                            //
                                            db.GTRM.Add(contract);
                                            db.SaveChanges();
                                            //
                                            if (setting.DetailLog) logger.Info($"N{countRow} загружена ");
                                        }
                                        else
                                        {
                                            counterr++;
                                            if (setting.DetailLog) logger.Info($"N{countRow} не загружена, всего: {counterr}");
                                        }
                                    }
                                    else
                                    {
                                        //
                                        db.GTRM.Add(contract);
                                        db.SaveChanges();
                                        //
                                        //this.Save();
                                    }
                                }
                            }
                            else
                            {
                                //myWriteLog.DoWriteLog($"Запись не добавлена, столбец 6 не прошел контроль");
                                logger.Error($"Запись N{countRow} не добавлена, столбец 6 не прошел контроль");
                            }
                        }
                        countRow++;
                    }
                    string str = $"{DateTime.Now} загружено записей: {countRow}, ошибок:{counterr}                                                                   ";
                    logger.Info(str);
                    Console.WriteLine(str);
                }
                else logger.Error($"Загрузка остановлена. Проверьте загружаемы данные.");

                #endregion
            }
            else logger.Info($"количество столбцов в строке:{length} - обработка не выполнялась");
            //myWriteLog.DoWriteLog($"количество столбцов в строке:{length} - обработка не выполнялась");
        }


        public bool CheckRecord(WorkbookWorksheetTableRow[] rows, int count)
        {
            bool result = true;
            int countRow = 1;
            int countError = 0;
            foreach (var row in rows)
            {
                var record = row.Cell;
                if (record.Count() != count)
                {
                    result = false;
                    countError++;
                    logger.Error($"В строке {countRow} ожидается {count} записей а получено {record.Count()}.");
                }
                countRow++;
            }
            if (countError > 0) logger.Error($"Общее количество ошибок по данным {countError} из {countRow}");
            return result;
        }


        public void SaveData2(Workbook wb, DateTime dmy, DateTime? myTime, mySettingProg setting)
        {

            //загрузка из файла
            var length = wb.Worksheet.Table.Row.Length;

            if (length > 0)
            {
                #region выполнить
                //удаляем рабочие контракты
                this.DeleteAllWorkContract();

                //перебор всех строк
                int countRow = 0;
                //
                //var sqlstr = $"INSERT INTO [dbo].[GTRM] (dateDocument, dateDownload, nameAllOTS, filialSign, acquiring, unn)";

                foreach (var row in wb.Worksheet.Table.Row)
                {
                    if (countRow > 0)
                    {
                        var cursor = Console.CursorTop;
                        var messprot = $"загрузка записей GTRM: {countRow * 100 / (length)}% текущая: {countRow} осталось:{length - countRow} из {length}";
                        Console.WriteLine(messprot);
                        Console.CursorTop = cursor;
                        if (setting.DetailLog) myWriteLog.DoWriteLog(messprot);
                        if (row.Cell[6].Data.Value != "Штрихкодирование" && row.Cell[6].Data.Value != "")
                        {
                            //myWriteLog.DoWriteLog($"количество записей в строке:{row.Cell.Count()}");
                            //
                            var record = row.Cell;
                            var contract = new GTRM()
                            {
                                dateDocument = dmy,
                                dateDownload = DateTime.Now,
                                nameAllOTS = record[0].Data.Value,
                                filialSign = Convert.ToInt16(record[1].Data.Value),
                                filialSupport = Convert.ToInt16((record[2].Data == null || record[2].Data.Value == null) ? record[1].Data.Value : record[2].Data.Value),
                                acquiring = Convert.ToByte(record[3].Data.Value),
                                unn = Convert.ToInt64(record[4].Data.Value),
                                numDogAcquiring = record[5].Data.Value,
                                typeBonusDog = record[6].Data.Value,
                                numBonusDog = record[7].Data.Value,
                                dateBonusDog = Convert.ToDateTime(record[8].Data.Value),
                                MCC = Convert.ToInt16(record[9].Data.Value),
                                MID = record[10].Data.Value,
                                field_098 = (record[11].Data == null) ? "" : record[11].Data.Value,
                                dateDownloadGTRM = (record[12].Data.Value == null) ? myTime : Convert.ToDateTime(record[12].Data.Value),
                                dateStartCredit = (record[13].Data.Value == null) ? myTime : Convert.ToDateTime(record[13].Data.Value),
                                //Дата регистрации ОТС в БПЦ по включению в партнерскую программу банка
                                dateFinishCredit = (record[14].Data.Value == null) ? myTime : Convert.ToDateTime(record[14].Data.Value),
                                //Дата внесения в ПК GTRM информации об исключении ОТС из участия в патнерской программе банка
                                dateDeleteInGTRM = (record[15].Data.Value == null) ? myTime : Convert.ToDateTime(record[15].Data.Value),
                                creditTime = Convert.ToInt16(record[16].Data.Value),
                                procentAcqASB = (record[17].Data.Value == null) ? 0 : Convert.ToDecimal(record[17].Data.Value.Replace(".", ",")),
                                procentRez = (record[18].Data.Value == null) ? 0 : Convert.ToDecimal(record[18].Data.Value.Replace(".", ",")),
                                procentNotRez = (record[19].Data.Value == null) ? 0 : Convert.ToDecimal(record[19].Data.Value.Replace(".", ",")),
                                procentASBwithBonus = (record[20].Data.Value == null) ? 0 : Convert.ToDecimal(record[20].Data.Value.Replace(".", ",")),
                                procentCashBack = Convert.ToDecimal(record[21].Data.Value.Replace(".", ",")),
                                procentNonAcq = Convert.ToDecimal(record[22].Data.Value.Replace(".", ",")),
                                nameOTS = (record[23].Data == null) ? "" : record[23].Data.Value,
                                typeProducts = (record[24].Data == null) ? "" : record[24].Data.Value,
                                rangeCodes = record[25].Data.Value,
                                tarif = (record[26].Data == null) ? "" : record[26].Data.Value,
                                region = (record[27].Data == null) ? "" : record[27].Data.Value,
                                district = (record[28].Data == null) ? "" : record[28].Data.Value,
                                cityType = (record[29].Data == null) ? "" : record[29].Data.Value,
                                cityName = (record[30].Data == null) ? "" : record[30].Data.Value,
                                streetType = (record[31].Data == null) ? "" : record[31].Data.Value,
                                streetName = (record[32].Data == null) ? "" : record[32].Data.Value,
                                houseNumber = (record[33].Data == null) ? "" : record[33].Data.Value,
                                category = (record[34].Data == null) ? "" : record[34].Data.Value,
                                siteOTS = (record[35].Data == null) ? "" : record[35].Data.Value,
                                email = (record[36].Data == null) ? "" : record[36].Data.Value,
                                linkDiscontProg = (record[37].Data == null) ? "" : record[37].Data.Value,
                                bankOTSAccount = (record[38].Data == null) ? "" : record[38].Data.Value,
                                curNumbAccountOTS = (record[39].Data == null) ? "" : record[39].Data.Value,
                                mfoBank = (record[40].Data == null) ? "" : record[40].Data.Value,
                                account = (record[41].Data == null) ? "" : record[41].Data.Value,
                                penalty = (record[42].Data == null || record[42].Data.Value == null) ? 0 : Convert.ToDecimal(record[42].Data.Value.Replace(".", ",")),
                                notes = (record[43].Data == null) ? "" : record[43].Data.Value,
                                prim = (record[44].Data == null) ? "" : record[44].Data.Value,
                                addressOts = (record[51].Data == null) ? "" : record[51].Data.Value,
                                //54 - 55 записей в строке
                                emailPartners = record.Count() == 54 ?
              record[53].Data == null ? "" : record[53].Data.Value : record.Count() == 55 ? record[54].Data == null ? "" : record[54].Data.Value
              : ""
                            };
                            //
                            if (setting.DetailLog) myWriteLog.DoWriteLog(myInformator.GetList(contract));
                            //
                            //var pContract= contract.GetType().GetProperties();
                            //
                            //var str = $"VALUES(";

                            //for (int i = 1; i < pContract.Count(); i++)
                            //{
                            //    //str = $"{str}{pContract[i].Name}{pContract[i].GetValue(contract, null)}";
                            //    str = $"{str},'{pContract[i].GetValue(contract, null)}'";
                            //    //var res = $"{pContract[i].Name}:{pContract[i].GetValue(contract, null)}";
                            //}
                            //str = $"{str})";
                            //
                            //foreach (var item in typeof(contract))
                            //{

                            //}
                            //
                            //проверка на дублирование
                            using (db = new PartnerPaymentEntities())
                            {
                                if (contract.dateFinishCredit != null && contract.dateDeleteInGTRM != null)
                                {
                                    var res = this.OnCheck(contract);
                                    if (!res)
                                    {
                                        //
                                        db.GTRM.Add(contract);
                                        //
                                        this.Save();
                                    }
                                }
                                else
                                {
                                    //
                                    db.GTRM.Add(contract);
                                    //
                                    this.Save();
                                }
                            }
                        }
                        else
                        {
                            myWriteLog.DoWriteLog($"Запись не добавлена, столбец 6 не прошел контроль");
                        }
                    }
                    countRow++;
                }
                myWriteLog.DoWriteLog($"***...загружено записей: {countRow}");
                #endregion
            }
            else myWriteLog.DoWriteLog($"количество столбцов в строке:{length} - обработка не выполнялась");
        }

    }
}
