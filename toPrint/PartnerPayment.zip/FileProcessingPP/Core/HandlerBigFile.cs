﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingPP.Core
{
    public class HandlerBigFile
    {
        private string dir { get; set; }
        private FileStream fs { get; set; }
        public long fsPosition { get; set; }
        private int arrayLength = 1;
        private byte[] buffer;
        private int byteRead { get; set; }
        public int fEOF { get; set; }
        //public event EventHandler Changed;
        public int CountRows { get; set; }
        private int countChar { get; set; }
        public int vCountChar { get; set; }


        public HandlerBigFile(FileStream _fs)
        {
            fs = _fs;
            buffer = new byte[arrayLength];
            fsPosition = 0;
            fEOF = 0;
            CountRows = 0;
        }

        public string GetStr(BinaryReader reader)
        {
            fs.Position = fsPosition;//текущая позиция в файле
            byteRead = reader.Read(buffer, 0, arrayLength);//читаем из файла заданный набор данных
            string strGTRM = "";
            while (byteRead > 0)//пока не закончится файл
            {
                if (buffer[0].ToString() == "13")//если есть символ перехода строки
                {
                    vCountChar = countChar;//текущее значение символов в строке
                    countChar = 0;//счетчик обнуляем
                    CountRows++;//счетчик записи
                    fsPosition = fs.Position;//текущая позиция в файле после чтения данных
                    //if (Changed != null) Changed(this, new EventArgs());//событие 
                    return strGTRM;
                }
                else
                {
                    countChar++;
                    strGTRM = strGTRM + System.Text.Encoding.Default.GetString(buffer);//читаем данные дальше
                }
                byteRead = reader.Read(buffer, 0, arrayLength);
            }
           fEOF = 1;

            return "";
        }
    }
}
