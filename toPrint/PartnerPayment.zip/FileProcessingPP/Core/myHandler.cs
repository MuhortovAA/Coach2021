﻿using NLog;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingPP.Core
{
    public static class myHandler
    {
        //
        private static Logger logger = LogManager.GetCurrentClassLogger();
        //
        public static DateTime GetDate (string str)
        {
            int indexstart = str.Length-6;
            string date = str.Substring(indexstart);
            logger.Error($"Строка для преобразования в дату \"{date.ToString()}\"");
            //string date = str.Remove(indexstart, 7);
            //var date = str.Remove(0, 15).Remove(6, 4);
            int dd = 0;
            try
            {
                dd = Convert.ToInt32(date.Remove(2, 4));

            }
            catch(Exception e)
            {
                logger.Error($"Ошибка преобразования даты из названия файла \"{date.ToString()}\": {e.Message}");
            }

            var mm = Convert.ToInt32(date.Trim().Remove(0, 2).Remove(2, 2));
            var yyyy = Convert.ToInt32("20" + date.Trim().Remove(0, 4));
            var dmy = new DateTime(yyyy, mm, dd);
            return dmy;

        }
        //
        public static decimal GetDecimal(string str)
        {
            decimal Result = 0;
            try
            {
                bool res = Decimal.TryParse(str, out Result);
            }
            catch (Exception e)
            {
                logger.Error($"Ошибка преобразования данных \"{str}\": {e.Message}");
            }


            return Result;
        }
    }
}
