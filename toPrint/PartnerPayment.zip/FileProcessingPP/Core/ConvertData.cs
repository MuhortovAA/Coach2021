﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingPP.Core
{
    public class ConvertData
    {
        public int CountNoError = 0;
        public bool fError { get; set; }

        public ConvertData()
        {

        }
        public CMSNew GetCMSNew(string[] data)
        {
            fError = true;

            if (data[3] == "BYN")
            {
                CountNoError++; // счетчик отсутствия ошибок
                fError = false;
                CMSNew dataCMS = new CMSNew();
                dataCMS.Card = data[0].Trim();
                dataCMS.TransDateTime = Convert.ToDateTime(data[1]);
                dataCMS.CMSDate = Convert.ToDateTime(data[2]).Date;
                dataCMS.TransVal = data[5];
                dataCMS.TransSum = Convert.ToDecimal(data[4]);
                dataCMS.AccountVal = data[5];
                dataCMS.AccountSum = Convert.ToDecimal(data[6]);
                dataCMS.TransType = Convert.ToInt32(data[7]);
                dataCMS.TransName = data[8];
                dataCMS.MID = data[9];
                dataCMS.TID = data[10];
                dataCMS.MCC = data[11];
                dataCMS.Field98 = data[12];
                dataCMS.POSCode = data[13];
                dataCMS.OTSName = data[14];
                dataCMS.EventArea = data[15];
                dataCMS.Filial = Convert.ToInt32(data[16]);
                dataCMS.CBU = (data[17] == "   ") ? 0 : int.Parse(data[17]);
                dataCMS.AccountInCMS = data[18];
                dataCMS.AccountInScCard = (data[19] == "") ? 0 : Convert.ToDecimal(data[19]);
                dataCMS.InternalNo = Convert.ToInt64(data[20]);
                dataCMS.FIO = data[21];
                return dataCMS;
            }
            else return new CMSNew();
        }

    }
}
