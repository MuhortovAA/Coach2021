﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows;



namespace FileProcessingPP.Core
{
    public static class myWriteLog
    {
        public static string Path_Log = "c:\test.log"; // путь к файлу протокола по умолчанию
        public static string MesssageStrF = DateTime.Now.ToString("dd-MM-yyyy") + " " + DateTime.Now.ToString("HH:mm:ss"); // строка протокола 
        private static bool _result; // результат записи в протокол
        public static bool result
        {
            get
            {
                return _result;
            }
        }

        public static void DoWriteLog (string MessageStr)  // процедура записи протокла, входящий параметр - сообщение.
        {
            try
            {
                StreamWriter OutFile = new StreamWriter(Path_Log, true, Encoding.Default);
                MesssageStrF = DateTime.Now.ToString("dd-MM-yyyy") + " " + DateTime.Now.ToString("HH:mm:ss");
                MessageStr = MesssageStrF + " " + MessageStr; // формируется строка записи в протокол
                //MessageBox.Show(MessageStr);
                OutFile.WriteLine("{0}", MessageStr);
                OutFile.Close();
                _result = true; //без ошибок
            }
            catch // исключение
            {
                    _result = false;// есть ошибка

                    ////MessageBox.Show("*** Ошибка записи в протокол!  " + " \n " + Path_Log + DateTime.Now.ToString("yyyy_MM") + ".log",
                    string str = String.Format("{0} {1}: *** Ошибка записи в протокол!  {2}", DateTime.Now.ToString("dd-MM-yyyy"), DateTime.Now.ToString("HH:mm:ss"), Path_Log );
                    //MessageBox.Show(str, "SyncAcc: Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                    //MessageBox.Show("*** Ошибка записи в протокол!  " + " \n " + Path_Log, "Ошибка " + DateTime.Now.ToString("dd-MM-yyyy") + " " + DateTime.Now.ToString("HH:mm:ss"));
            }
        }

        /// <summary>
        /// старт записи в протокол
        /// </summary>
        /// <param name="PathLog">путь к каталогу записи проткола например c:\test.log</param>
        public static void BeginLog(string sPathLog)
        {
            
            Path_Log = $"{sPathLog}{DateTime.Now.ToString("ddMMyyyy")}.log";
            DoWriteLog("***Старт программы*************************");
        }
    }
}
