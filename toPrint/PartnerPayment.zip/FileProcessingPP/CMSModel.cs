﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileProcessingPP
{
    public class CMSNewModel
    {
        public string Card { get; set; }
        public DateTime TransDateTime { get; set; }
        public DateTime CMSDate { get; set; }
        public string TransVal { get; set; }
        public decimal TransSum { get; set; }
        public string AccountVal { get; set; }
        public decimal AccountSum { get; set; }
        public int TransType { get; set; }
        public string TransName { get; set; }
        public string MID { get; set; }
        public string TID { get; set; }
        public string MCC { get; set; }
        public string Field98 { get; set; }
        public string POSCode { get; set; }
        public string OTSName { get; set; }
        public string EventArea { get; set; }
        public int Filial { get; set; }
        public Nullable<int> CBU { get; set; }
        public string AccountInCMS { get; set; }
        public Nullable<decimal> AccountInScCard { get; set; }
        public long InternalNo { get; set; }
        public string FIO { get; set; }
        public DateTime DateInProg { get; set; }
        //public static implicit operator CMSModel(CMS value)
        //{
        //    return new CMSModel
        //    {
        //        Id = value.Id,
        //        Card = value.Card,
        //        TransDateTime = value.TransDateTime,
        //        CMSDate = value.CMSDate,
        //        TransVal = value.TransVal,
        //        TransSum = value.TransSum,
        //        AccountVal = value.AccountVal,
        //        AccountSum = value.AccountSum,
        //        TransType = value.TransType,
        //        TransName = value.TransName,
        //        MID = value.MID,
        //        TID = value.TID,
        //        MCC = value.MCC,
        //        Field98 = value.Field98,
        //        POSCode = value.POSCode,
        //        OTSName = value.OTSName,
        //        EventArea = value.EventArea,
        //        Filial = value.Filial,
        //        CBU = value.CBU,
        //        AccountInCMS = value.AccountInCMS,
        //        AccountInScCard = value.AccountInScCard,
        //        InternalNo = value.InternalNo,
        //        FIO = value.FIO,
        //        DateInProg = value.DateInProg
        //    };
        //}
        //public static implicit operator CMS(CMSModel value)
        //{
        //    return new CMS
        //    {
        //        Id = value.Id,
        //        Card = value.Card,
        //        TransDateTime = value.TransDateTime,
        //        CMSDate = value.CMSDate,
        //        TransVal = value.TransVal,
        //        TransSum = value.TransSum,
        //        AccountVal = value.AccountVal,
        //        AccountSum = value.AccountSum,
        //        TransType = value.TransType,
        //        TransName = value.TransName,
        //        MID = value.MID,
        //        TID = value.TID,
        //        MCC = value.MCC,
        //        Field98 = value.Field98,
        //        POSCode = value.POSCode,
        //        OTSName = value.OTSName,
        //        EventArea = value.EventArea,
        //        Filial = value.Filial,
        //        CBU = value.CBU,
        //        AccountInCMS = value.AccountInCMS,
        //        AccountInScCard = value.AccountInScCard,
        //        InternalNo = value.InternalNo,
        //        FIO = value.FIO,
        //        DateInProg = value.DateInProg
        //    };
        //}
    }
}
